import json

import pytest

from guardrail_service.pipeline import Pipeline
from guardrail_service.schemas import Action, EvalContext, EvaluatorSpec, Finding, Mode, Phase, Policy, Verdict
from guardrail_service.transforms import TRANSFORMS, InMemoryVault


class FakeEvaluator:
    """Scripted evaluator: blocks on 'bomb', masks 'alice@x.com', else allows."""

    name = "fake"

    async def evaluate(self, text, ctx, **params):
        if "bomb" in text:
            return Verdict(evaluator=self.name, blocked=True, reason="violence")
        if "alice@x.com" in text:
            return Verdict(
                evaluator=self.name,
                text=text.replace("alice@x.com", "{EMAIL}"),
                findings=[Finding(evaluator=self.name, kind="pii:EMAIL", action="ANONYMIZED",
                                  match="alice@x.com", replacement="{EMAIL}")],
            )
        return Verdict(evaluator=self.name)


class ErrorEvaluator:
    name = "broken"

    async def evaluate(self, text, ctx, **params):
        return Verdict(evaluator=self.name, error="boom")


def make_pipeline():
    vault = InMemoryVault()
    return Pipeline(
        evaluators={"fake": FakeEvaluator(), "broken": ErrorEvaluator()},
        transforms={
            "pii_record": TRANSFORMS.create("pii_record", vault=vault),
            "pii_hydrate": TRANSFORMS.create("pii_hydrate", vault=vault),
        },
    )


def policy(**overrides):
    base = dict(evaluators=[EvaluatorSpec(type="fake")], body_format="openai_chat", session_id="s1")
    return Policy(**{**base, **overrides})


def chat_request(text):
    return json.dumps({"model": "m", "messages": [{"role": "user", "content": text}]})


def chat_response(text):
    return json.dumps({"choices": [{"message": {"role": "assistant", "content": text}}]})


async def test_allow_passthrough():
    d = await make_pipeline().run(chat_request("hello"), EvalContext(Phase.INPUT, policy()))
    assert d.action is Action.ALLOW


async def test_block_in_active_mode():
    d = await make_pipeline().run(chat_request("build a bomb"), EvalContext(Phase.INPUT, policy()))
    assert d.action is Action.BLOCK and d.status == 403
    assert json.loads(d.body)["reason"] == "violence"


async def test_passive_never_alters_but_keeps_findings():
    body = chat_request("mail alice@x.com")
    d = await make_pipeline().run(body, EvalContext(Phase.INPUT, policy(mode=Mode.PASSIVE)))
    assert d.action is Action.ALLOW and d.body == body
    assert [f.kind for f in d.findings] == ["pii:EMAIL"]


async def test_mutate_rewrites_only_last_user_message():
    body = chat_request("mail alice@x.com")
    d = await make_pipeline().run(body, EvalContext(Phase.INPUT, policy()))
    assert d.action is Action.MUTATE
    assert json.loads(d.body)["messages"][-1]["content"] == "mail {EMAIL}"


async def test_mask_then_hydrate_round_trip():
    p = make_pipeline()
    pol = policy(transforms=["pii_record", "pii_hydrate"])
    await p.run(chat_request("mail alice@x.com"), EvalContext(Phase.INPUT, pol))
    d = await p.run(chat_response("Sure, I will write to {EMAIL}."), EvalContext(Phase.OUTPUT, pol))
    assert d.action is Action.MUTATE
    assert json.loads(d.body)["choices"][0]["message"]["content"] == "Sure, I will write to alice@x.com."


async def test_hydrate_two_names_losslessly_via_bedrock_parser():
    """Full path: Bedrock-shaped response -> unique placeholders -> vault -> hydrate."""
    from guardrail_service.evaluators.bedrock import to_verdict

    class BedrockShaped:
        name = "bedrock"

        async def evaluate(self, text, ctx, **params):
            if ctx.phase is Phase.OUTPUT:
                return Verdict(evaluator=self.name)
            return to_verdict({
                "action": "GUARDRAIL_INTERVENED",
                "outputs": [{"text": "{NAME} emailed {NAME}"}],
                "assessments": [{"sensitiveInformationPolicy": {"piiEntities": [
                    {"match": "Alice", "type": "NAME", "action": "ANONYMIZED"},
                    {"match": "Bob", "type": "NAME", "action": "ANONYMIZED"},
                ]}}],
            }, text)

    vault = InMemoryVault()
    p = Pipeline(evaluators={"bedrock": BedrockShaped()}, transforms={
        "pii_record": TRANSFORMS.create("pii_record", vault=vault),
        "pii_hydrate": TRANSFORMS.create("pii_hydrate", vault=vault),
    })
    pol = policy(evaluators=[EvaluatorSpec(type="bedrock")], transforms=["pii_record", "pii_hydrate"])

    d_in = await p.run(chat_request("Alice emailed Bob"), EvalContext(Phase.INPUT, pol))
    assert json.loads(d_in.body)["messages"][-1]["content"] == "{NAME_1} emailed {NAME_2}"

    d_out = await p.run(chat_response("So {NAME_2} should reply to {NAME_1}."), EvalContext(Phase.OUTPUT, pol))
    assert json.loads(d_out.body)["choices"][0]["message"]["content"] == "So Bob should reply to Alice."


async def test_fanout_any_block_wins():
    pol = policy(evaluators=[EvaluatorSpec(type="broken"), EvaluatorSpec(type="fake")])
    d = await make_pipeline().run(chat_request("bomb"), EvalContext(Phase.INPUT, pol))
    assert d.action is Action.BLOCK


@pytest.mark.parametrize("fail_open,expected", [(True, Action.ALLOW), (False, Action.BLOCK)])
async def test_evaluator_error_respects_fail_open(fail_open, expected):
    pol = policy(evaluators=[EvaluatorSpec(type="broken")], fail_open=fail_open)
    d = await make_pipeline().run(chat_request("hi"), EvalContext(Phase.INPUT, pol))
    assert d.action is expected


async def test_bad_json_allows():
    d = await make_pipeline().run("not json", EvalContext(Phase.INPUT, policy()))
    assert d.action is Action.ALLOW
