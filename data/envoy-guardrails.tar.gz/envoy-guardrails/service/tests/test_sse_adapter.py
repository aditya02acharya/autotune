import json

from guardrail_service.content import ADAPTERS
from guardrail_service.schemas import Phase


def chunk(content=None, finish=None, **extra):
    delta = {"role": "assistant"} if content is None and finish is None else {}
    if content is not None:
        delta["content"] = content
    obj = {"id": "c1", "object": "chat.completion.chunk",
           "choices": [{"index": 0, "delta": delta, "finish_reason": finish}], **extra}
    return "data: " + json.dumps(obj)


def stream(*events, sep="\n\n"):
    return sep.join(events) + sep


def test_sse_roundtrip_preserves_framing():
    raw = stream(
        chunk(),
        chunk("Hello "),
        chunk("Bob"),
        chunk(".", finish="stop"),
        "data: " + json.dumps({"id": "c1", "choices": [], "usage": {"total_tokens": 9}}),
        "data: [DONE]",
    )
    adapter = ADAPTERS.create("openai_chat")
    doc = adapter.parse(raw)
    assert adapter.extract(doc, Phase.OUTPUT) == "Hello Bob."

    out = adapter.inject(doc, Phase.OUTPUT, "Hello {NAME_1}.")
    events = [e for e in out.split("\n\n") if e]
    assert len(events) == 6 and events[-1] == "data: [DONE]"
    payloads = [json.loads(e[5:]) for e in events[:-1]]
    contents = [p["choices"][0]["delta"].get("content") for p in payloads if p["choices"]]
    assert contents == [None, "Hello {NAME_1}.", "", ""]
    assert payloads[3]["choices"][0]["finish_reason"] == "stop"
    assert payloads[4]["usage"]["total_tokens"] == 9


def test_sse_crlf_and_comments():
    raw = stream(": keep-alive", chunk("hi"), "data: [DONE]", sep="\r\n\r\n")
    adapter = ADAPTERS.create("openai_chat")
    doc = adapter.parse(raw)
    assert adapter.extract(doc, Phase.OUTPUT) == "hi"
    assert adapter.inject(doc, Phase.OUTPUT, "hi") == raw


def test_non_sse_json_still_works():
    adapter = ADAPTERS.create("openai_chat")
    doc = adapter.parse(json.dumps({"choices": [{"message": {"content": "x"}}]}))
    assert adapter.extract(doc, Phase.OUTPUT) == "x"
