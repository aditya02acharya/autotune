"""Parse real-shaped ApplyGuardrail responses without touching AWS."""

from guardrail_service.evaluators.bedrock import to_verdict as parse


def intervened(entities, bedrock_text):
    return {
        "action": "GUARDRAIL_INTERVENED",
        "outputs": [{"text": bedrock_text}],
        "assessments": [{"sensitiveInformationPolicy": {"piiEntities": [
            {"match": m, "type": t, "action": "ANONYMIZED"} for m, t in entities
        ]}}],
    }


def test_anonymized_pii_gets_unique_placeholders():
    resp = intervened([("Bob", "NAME"), ("0123", "PHONE")], "call {NAME} on {PHONE}")
    v = parse(resp, "call Bob on 0123")
    assert not v.blocked and v.text == "call {NAME_1} on {PHONE_1}"
    assert {f.replacement for f in v.findings} == {"{NAME_1}", "{PHONE_1}"}
    assert {f.kind for f in v.findings} == {"sensitiveInformation:NAME", "sensitiveInformation:PHONE"}


def test_two_names_stay_distinct_and_repeat_consistently():
    resp = intervened([("Alice", "NAME"), ("Bob", "NAME"), ("Alice", "NAME")], "{NAME} told {NAME}. {NAME} left.")
    v = parse(resp, "Alice told Bob. Alice left.")
    assert v.text == "{NAME_1} told {NAME_2}. {NAME_1} left."
    assert [f.replacement for f in v.findings] == ["{NAME_1}", "{NAME_2}", "{NAME_1}"]


def test_nested_values_replace_longest_first():
    resp = intervened([("Ann Lee", "NAME"), ("Lee", "NAME")], "{NAME} and {NAME}")
    v = parse(resp, "Ann Lee and Lee")
    assert v.text == "{NAME_1} and {NAME_2}"


def test_falls_back_to_bedrock_text_when_match_missing():
    resp = intervened([("Bob", "NAME")], "call {NAME}")
    resp["assessments"][0]["sensitiveInformationPolicy"]["piiEntities"][0].pop("match")
    v = parse(resp, "call Bob")
    assert v.text == "call {NAME}"


def test_unique_placeholders_can_be_disabled():
    resp = intervened([("Bob", "NAME")], "call {NAME}")
    v = parse(resp, "call Bob", unique_placeholders=False)
    assert v.text == "call {NAME}" and v.findings[0].replacement == "{NAME}"


def test_blocked_topic_wins_over_mutation():
    resp = {
        "action": "GUARDRAIL_INTERVENED",
        "outputs": [{"text": "Sorry, I cannot help with that."}],
        "assessments": [{"topicPolicy": {"topics": [{"name": "finance", "type": "DENY", "action": "BLOCKED"}]}}],
    }
    v = parse(resp, "stock tips?")
    assert v.blocked and v.text is None


def test_no_intervention():
    v = parse({"action": "NONE", "outputs": [], "assessments": [{}]}, "hi")
    assert not v.blocked and v.text is None and v.findings == []
