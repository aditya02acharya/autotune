import json

from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import InMemoryMetricReader

from guardrail_service.evaluators.bedrock import to_verdict
from guardrail_service.pipeline import Pipeline
from guardrail_service.schemas import EvalContext, EvaluatorSpec, Mode, Phase, Policy, Verdict
from guardrail_service.telemetry import Telemetry

MULTI_FILTER_RESPONSE = {
    "action": "GUARDRAIL_INTERVENED",
    "outputs": [{"text": "Sorry"}],
    "usage": {"topicPolicyUnits": 1, "contentPolicyUnits": 1, "sensitiveInformationPolicyUnits": 1},
    "assessments": [{
        "topicPolicy": {"topics": [{"name": "finance", "type": "DENY", "action": "BLOCKED"}]},
        "contentPolicy": {"filters": [{"type": "HATE", "confidence": "LOW", "action": "NONE", "detected": True}]},
        "wordPolicy": {"customWords": [{"match": "acme", "action": "BLOCKED"}],
                       "managedWordLists": [{"match": "damn", "type": "PROFANITY", "action": "NONE", "detected": True}]},
        "sensitiveInformationPolicy": {"piiEntities": [{"match": "Bob", "type": "NAME", "action": "ANONYMIZED"}],
                                       "regexes": [{"name": "acct", "match": "AC-1", "regex": "AC-\\d", "action": "BLOCKED"}]},
        "contextualGroundingPolicy": {"filters": [{"type": "GROUNDING", "threshold": 0.7, "score": 0.2, "action": "BLOCKED"}]},
        "invocationMetrics": {"guardrailProcessingLatency": 143, "usage": {"topicPolicyUnits": 1},
                              "guardrailCoverage": {"textCharacters": {"guarded": 20, "total": 20}}},
    }],
}


def test_bedrock_reports_every_matched_filter():
    v = to_verdict(MULTI_FILTER_RESPONSE, "Bob damn acme AC-1 stock tips")
    assert v.blocked
    assert sorted(f.kind for f in v.findings) == sorted([
        "topic:finance", "content:HATE", "word:customWords", "word:PROFANITY",
        "sensitiveInformation:NAME", "sensitiveInformation:acct", "contextualGrounding:GROUNDING",
    ])
    assert v.metrics["processing_latency_ms"] == 143
    assert v.metrics["usage.topicPolicyUnits"] == 2       # top-level + invocationMetrics
    assert v.metrics["usage.contentPolicyUnits"] == 1


class CannedBedrock:
    name = "bedrock"

    async def evaluate(self, text, ctx, **params):
        return to_verdict(MULTI_FILTER_RESPONSE, text)


async def test_metrics_are_emitted_with_low_cardinality_attributes():
    reader = InMemoryMetricReader()
    tel = Telemetry(meter=MeterProvider(metric_readers=[reader]).get_meter("test"))
    p = Pipeline(evaluators={"bedrock": CannedBedrock()}, transforms={}, telemetry=tel)
    pol = Policy(evaluators=[EvaluatorSpec(type="bedrock")], mode=Mode.PASSIVE, tenant="t1")
    body = json.dumps({"messages": [{"role": "user", "content": "x"}]})

    await p.run(body, EvalContext(Phase.INPUT, pol, request_id="req-1"))

    points = {}
    for rm in reader.get_metrics_data().resource_metrics:
        for sm in rm.scope_metrics:
            for m in sm.metrics:
                points[m.name] = list(m.data.data_points)

    evals = points["guardrail.evaluations"]
    assert evals[0].value == 1
    assert dict(evals[0].attributes) == {"phase": "input", "mode": "passive", "tenant": "t1", "action": "allow"}

    finding_kinds = {dp.attributes["kind"] for dp in points["guardrail.findings"]}
    assert "topic:finance" in finding_kinds and "content:HATE" in finding_kinds
    assert all("request_id" not in dp.attributes for dp in points["guardrail.findings"])

    units = {dp.attributes["unit"]: dp.value for dp in points["guardrail.evaluator.units"]}
    assert units["topicPolicyUnits"] == 2
    assert points["guardrail.evaluator.upstream_latency"][0].sum == 143
