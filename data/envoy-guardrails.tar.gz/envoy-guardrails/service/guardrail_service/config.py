from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="GR_", env_file=".env", extra="ignore")

    aws_region: str = "eu-west-2"
    bedrock_timeout_s: float = 5.0
    http_evaluator_timeout_s: float = 5.0
    vault_redis_url: str | None = None   # None -> in-memory vault (single replica only)
    vault_ttl_s: int = 600
    max_body_bytes: int = 4 * 1024 * 1024
    log_level: str = "INFO"
    # Exporter endpoint, service name etc come from the standard OTEL_* env vars.
    otel_enabled: bool = False
