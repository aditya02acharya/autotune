"""Guardrail evaluation service behind an Envoy Lua filter."""
