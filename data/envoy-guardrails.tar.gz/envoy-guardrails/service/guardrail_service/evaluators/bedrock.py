"""AWS Bedrock Guardrails evaluator (ApplyGuardrail API)."""

from __future__ import annotations

import asyncio
import logging
from typing import Any

import boto3
from botocore.config import Config

from ..schemas import EvalContext, Finding, Phase, Verdict
from .base import EVALUATORS

log = logging.getLogger(__name__)

_SOURCE = {Phase.INPUT: "INPUT", Phase.OUTPUT: "OUTPUT"}


@EVALUATORS.register("bedrock")
class BedrockGuardrailEvaluator:
    """One instance per process; guardrail id/version arrive per call via policy.

    Policy params (EvaluatorSpec.params or the Policy shorthand):
        guardrail_id, guardrail_version
        unique_placeholders (default True): mask as {NAME_1}, {NAME_2} instead of
        Bedrock's per-type {NAME}, so hydration on the output phase is lossless.
    """

    name = "bedrock"

    def __init__(self, region: str, timeout_s: float = 5.0, max_attempts: int = 2) -> None:
        self._client = boto3.client(
            "bedrock-runtime",
            region_name=region,
            config=Config(
                read_timeout=timeout_s,
                connect_timeout=2,
                retries={"max_attempts": max_attempts, "mode": "standard"},
            ),
        )

    async def evaluate(self, text: str, ctx: EvalContext, **params: Any) -> Verdict:
        guardrail_id = params.get("guardrail_id") or ctx.policy.guardrail_id
        version = params.get("guardrail_version") or ctx.policy.guardrail_version
        if not guardrail_id:
            return Verdict(evaluator=self.name, error="no guardrail_id in policy")
        if not text:
            return Verdict(evaluator=self.name)

        try:
            resp = await asyncio.to_thread(
                self._client.apply_guardrail,
                guardrailIdentifier=guardrail_id,
                guardrailVersion=str(version),
                source=_SOURCE[ctx.phase],
                content=[{"text": {"text": text}}],
            )
        except Exception as exc:  # boto raises many types; the merger decides what to do
            log.warning("bedrock apply_guardrail failed", extra={"request_id": ctx.request_id, "err": str(exc)})
            return Verdict(evaluator=self.name, error=str(exc))

        return to_verdict(resp, text, unique_placeholders=params.get("unique_placeholders", True))


def to_verdict(resp: dict[str, Any], original: str, unique_placeholders: bool = True) -> Verdict:
    """Translate an ApplyGuardrail response into a Verdict. Pure, so it is unit testable.

    unique_placeholders=True: Bedrock's own masked text uses one placeholder per
    PII type ({NAME} for every name), which makes hydration lossy. Instead we
    rebuild the masked text from the assessment findings, giving each distinct
    value its own placeholder ({NAME_1}, {NAME_2}). Falls back to Bedrock's text
    when a finding lacks a `match`.
    """
    findings = [f for assessment in resp.get("assessments", []) for f in _walk_assessment(assessment)]
    blocked = any(f.action == "BLOCKED" for f in findings)

    text = None
    if resp.get("action") == "GUARDRAIL_INTERVENED" and not blocked:
        outputs = resp.get("outputs") or []
        bedrock_text = outputs[0].get("text") if outputs else None
        masked = _mask_unique(original, findings) if unique_placeholders else None
        if masked is None and bedrock_text and bedrock_text != original:
            masked = bedrock_text
            _attach_type_placeholders(findings, bedrock_text)
        if masked and masked != original:
            text = masked

    return Verdict(
        evaluator="bedrock",
        blocked=blocked,
        text=text,
        reason=resp.get("actionReason") or ("blocked" if blocked else None),
        findings=findings,
        metrics=_metrics_from(resp),
    )


def _metrics_from(resp: dict[str, Any]) -> dict[str, float]:
    """Flatten Bedrock usage and invocation metrics into exportable numbers."""
    out: dict[str, float] = {}
    for k, v in (resp.get("usage") or {}).items():
        if isinstance(v, (int, float)):
            out[f"usage.{k}"] = float(v)
    for assessment in resp.get("assessments", []):
        inv = assessment.get("invocationMetrics") or {}
        if "guardrailProcessingLatency" in inv:
            out["processing_latency_ms"] = float(inv["guardrailProcessingLatency"])
        for k, v in (inv.get("usage") or {}).items():
            if isinstance(v, (int, float)):
                out[f"usage.{k}"] = out.get(f"usage.{k}", 0.0) + float(v)
    return out


def _walk_assessment(assessment: dict[str, Any]) -> list[Finding]:
    """Flatten Bedrock's nested assessment into Findings without caring about
    which policy types exist: every list item that carries an `action` counts.

    Covers topicPolicy.topics, contentPolicy.filters, wordPolicy.customWords and
    managedWordLists, sensitiveInformationPolicy.piiEntities and regexes,
    contextualGroundingPolicy.filters, and any policy Bedrock adds later with
    the same shape. Filters in detect-only mode arrive as action NONE with
    detected=true and are kept as findings (they count for observability).
    """
    findings: list[Finding] = []
    for policy_name, policy in assessment.items():
        if not isinstance(policy, dict) or policy_name == "invocationMetrics":
            continue
        for section, items in policy.items():
            if not isinstance(items, list):
                continue
            for item in items:
                if not isinstance(item, dict) or "action" not in item:
                    continue
                # topics and regexes carry a user-chosen `name`; filters and PII carry a `type`
                kind = item.get("name") or item.get("type") or section
                findings.append(Finding(
                    evaluator="bedrock",
                    kind=f"{policy_name.removesuffix('Policy')}:{kind}",
                    action=item["action"],
                    match=item.get("match"),
                    detail={k: v for k, v in item.items() if k not in {"match", "action"}},
                ))
    return findings


def _pii_type(f: Finding) -> str:
    return f.kind.split(":", 1)[-1]


def _mask_unique(original: str, findings: list[Finding]) -> str | None:
    """Rebuild masked text from findings with one placeholder per distinct value.

    Returns None if any anonymised finding has no `match`, so the caller can fall
    back to Bedrock's own output. Longest matches are replaced first so a short
    value nested inside a longer one (a surname inside a full name) is safe.
    """
    anonymised = [f for f in findings if f.action == "ANONYMIZED"]
    if not anonymised:
        return None
    if any(not f.match for f in anonymised):
        return None

    placeholders: dict[tuple[str, str], str] = {}   # (type, value) -> placeholder
    counters: dict[str, int] = {}
    for f in anonymised:
        key = (_pii_type(f), f.match)
        if key not in placeholders:
            counters[key[0]] = counters.get(key[0], 0) + 1
            placeholders[key] = "{" + f"{key[0]}_{counters[key[0]]}" + "}"
        f.replacement = placeholders[key]

    masked = original
    for (_, value), placeholder in sorted(placeholders.items(), key=lambda kv: -len(kv[0][1])):
        masked = masked.replace(value, placeholder)
    return masked


def _attach_type_placeholders(findings: list[Finding], mutated: str) -> None:
    """Fallback bookkeeping for Bedrock's native {TYPE} placeholders (lossy)."""
    for f in findings:
        if f.action == "ANONYMIZED" and f.match:
            placeholder = "{" + _pii_type(f) + "}"
            if placeholder in mutated:
                f.replacement = placeholder
