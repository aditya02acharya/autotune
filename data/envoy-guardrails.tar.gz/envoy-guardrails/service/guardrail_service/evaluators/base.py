"""Evaluator protocol and registry.

An evaluator takes plain text plus context and returns a Verdict. It must not
raise: errors go into Verdict.error so the merger can apply the fail policy.
Evaluators are constructed once per process (clients are expensive) and must
be safe to call concurrently.
"""

from __future__ import annotations

from typing import Protocol

from ..registry import Registry
from ..schemas import EvalContext, Verdict


class Evaluator(Protocol):
    name: str

    async def evaluate(self, text: str, ctx: EvalContext) -> Verdict: ...


EVALUATORS: Registry[Evaluator] = Registry("evaluator")
