"""Generic HTTP evaluator for self-hosted classifiers (vLLM PII model, etc).

Any model behind a small shim that speaks this contract can be fanned out to:

    POST {url}
    {"text": "...", "phase": "input|output", "request_id": "..."}

    200 {"blocked": false, "text": "<optional mutated text>",
         "reason": "...", "findings": [{"kind": "pii:EMAIL", "action": "MASKED",
                                        "match": "...", "replacement": "..."}]}

Policy usage:
    evaluators:
      - type: http
        params: {name: "pii_vllm", url: "http://pii-shim:9000/classify"}
"""

from __future__ import annotations

import logging
from typing import Any

import httpx

from ..schemas import EvalContext, Finding, Verdict
from .base import EVALUATORS

log = logging.getLogger(__name__)


@EVALUATORS.register("http")
class HttpEvaluator:
    name = "http"

    def __init__(self, timeout_s: float = 5.0) -> None:
        self._client = httpx.AsyncClient(timeout=timeout_s)

    async def evaluate(self, text: str, ctx: EvalContext, **params: Any) -> Verdict:
        name = params.get("name", self.name)
        url = params.get("url")
        if not url:
            return Verdict(evaluator=name, error="http evaluator needs params.url")
        if not text:
            return Verdict(evaluator=name)

        try:
            resp = await self._client.post(url, json={
                "text": text, "phase": ctx.phase.value, "request_id": ctx.request_id,
                **params.get("extra", {}),
            })
            resp.raise_for_status()
            data = resp.json()
        except Exception as exc:
            log.warning("http evaluator %s failed: %s", name, exc)
            return Verdict(evaluator=name, error=str(exc))

        mutated = data.get("text")
        return Verdict(
            evaluator=name,
            blocked=bool(data.get("blocked")),
            text=mutated if mutated and mutated != text else None,
            reason=data.get("reason"),
            findings=[Finding(evaluator=name, **f) for f in data.get("findings", [])],
        )

    async def aclose(self) -> None:
        await self._client.aclose()
