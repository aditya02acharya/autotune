"""OpenTelemetry metrics and traces for the pipeline.

Configuration follows the standard OTel environment variables so nothing here
needs to be changed per environment:

    OTEL_EXPORTER_OTLP_ENDPOINT=http://otel-collector:4317
    OTEL_SERVICE_NAME=guardrail-service
    OTEL_RESOURCE_ATTRIBUTES=deployment.environment=prod,region=eu-west-2

Instruments (all carry phase, mode, tenant, evaluator where meaningful):

    guardrail.evaluations            counter    action=allow|block|mutate
    guardrail.pipeline.duration      histogram  ms, end-to-end inside the service
    guardrail.evaluator.duration     histogram  ms per evaluator, outcome=ok|error
    guardrail.evaluator.errors       counter
    guardrail.findings               counter    kind=pii:NAME|topic:finance|..., finding_action=BLOCKED|ANONYMIZED|NONE
    guardrail.evaluator.units        counter    unit=usage.topicPolicyUnits etc (Bedrock billing units)
    guardrail.evaluator.upstream_latency histogram ms reported by the provider itself

Attribute cardinality is kept low on purpose: never add request_id, session_id
or matched text as an attribute.
"""

from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from typing import Any

from opentelemetry import metrics, trace
from opentelemetry.metrics import Meter

from .schemas import Decision, EvalContext, Verdict

log = logging.getLogger(__name__)


def configure(enabled: bool) -> None:
    """Install SDK providers with OTLP exporters. Without this, the API calls
    below are no-ops, which is what tests and local runs want."""
    if not enabled:
        return
    from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    resource = Resource.create()  # picks up OTEL_SERVICE_NAME / OTEL_RESOURCE_ATTRIBUTES
    metrics.set_meter_provider(MeterProvider(
        resource=resource, metric_readers=[PeriodicExportingMetricReader(OTLPMetricExporter())],
    ))
    tracer_provider = TracerProvider(resource=resource)
    tracer_provider.add_span_processor(BatchSpanProcessor(OTLPSpanExporter()))
    trace.set_tracer_provider(tracer_provider)
    log.info("opentelemetry exporters configured")


class Telemetry:
    def __init__(self, meter: Meter | None = None) -> None:
        meter = meter or metrics.get_meter("guardrail_service")
        self._tracer = trace.get_tracer("guardrail_service")
        self.evaluations = meter.create_counter("guardrail.evaluations", unit="1")
        self.pipeline_duration = meter.create_histogram("guardrail.pipeline.duration", unit="ms")
        self.evaluator_duration = meter.create_histogram("guardrail.evaluator.duration", unit="ms")
        self.evaluator_errors = meter.create_counter("guardrail.evaluator.errors", unit="1")
        self.findings = meter.create_counter("guardrail.findings", unit="1")
        self.units = meter.create_counter("guardrail.evaluator.units", unit="1")
        self.upstream_latency = meter.create_histogram("guardrail.evaluator.upstream_latency", unit="ms")

    # -- spans -------------------------------------------------------------
    @contextmanager
    def span(self, name: str, **attrs: Any):
        with self._tracer.start_as_current_span(name) as s:
            for k, v in attrs.items():
                if v is not None:
                    s.set_attribute(k, v)
            yield s

    # -- metrics -----------------------------------------------------------
    def record_verdict(self, ctx: EvalContext, evaluator: str, verdict: Verdict, duration_ms: float) -> None:
        base = _base_attrs(ctx) | {"evaluator": evaluator}
        self.evaluator_duration.record(duration_ms, base | {"outcome": "error" if verdict.error else "ok"})
        if verdict.error:
            self.evaluator_errors.add(1, base)
        for f in verdict.findings:
            self.findings.add(1, base | {"kind": f.kind, "finding_action": f.action})
        for key, value in verdict.metrics.items():
            if key.startswith("usage."):
                self.units.add(value, base | {"unit": key.removeprefix("usage.")})
            elif key == "processing_latency_ms":
                self.upstream_latency.record(value, base)

    def record_decision(self, ctx: EvalContext, decision: Decision, duration_ms: float) -> None:
        attrs = _base_attrs(ctx) | {"action": decision.action.value}
        self.evaluations.add(1, attrs)
        self.pipeline_duration.record(duration_ms, attrs)


def _base_attrs(ctx: EvalContext) -> dict[str, Any]:
    attrs: dict[str, Any] = {"phase": ctx.phase.value, "mode": ctx.policy.mode.value}
    if ctx.policy.tenant:
        attrs["tenant"] = ctx.policy.tenant
    return attrs


class Stopwatch:
    def __init__(self) -> None:
        self._t0 = time.perf_counter()

    @property
    def ms(self) -> float:
        return (time.perf_counter() - self._t0) * 1000.0
