"""Wire types shared by the whole service.

Policy  : what the gateway told us to do (opaque to Lua, interpreted here).
Verdict : what one evaluator concluded.
Decision: what we tell Lua to do.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class Phase(StrEnum):
    INPUT = "input"
    OUTPUT = "output"


class Mode(StrEnum):
    ACTIVE = "active"      # block / mutate
    PASSIVE = "passive"    # observe only, never alter traffic


class Action(StrEnum):
    ALLOW = "allow"
    BLOCK = "block"
    MUTATE = "mutate"


class EvaluatorSpec(BaseModel):
    """One entry in policy.evaluators. `type` is a registry key."""

    type: str
    params: dict[str, Any] = Field(default_factory=dict)


class Policy(BaseModel):
    """Per-request instruction. Unknown keys are kept so new evaluators or
    transforms can read their own settings without touching this class."""

    model_config = ConfigDict(extra="allow")

    mode: Mode = Mode.ACTIVE
    body_format: str = "openai_chat"
    block_status: int = 403
    session_id: str | None = None
    tenant: str | None = None       # low-cardinality label for metrics

    # Shorthand for the common single-Bedrock case.
    guardrail_id: str | None = None
    guardrail_version: str = "DRAFT"

    # Explicit fan-out list. When set it replaces the shorthand above.
    evaluators: list[EvaluatorSpec] = Field(default_factory=list)
    transforms: list[str] = Field(default_factory=list)

    def resolved_evaluators(self) -> list[EvaluatorSpec]:
        if self.evaluators:
            return self.evaluators
        if self.guardrail_id:
            return [EvaluatorSpec(type="bedrock", params={
                "guardrail_id": self.guardrail_id,
                "guardrail_version": self.guardrail_version,
            })]
        return []


class Finding(BaseModel):
    """A single thing an evaluator noticed. `match` may contain sensitive text:
    never log it, log `kind` and `action` instead."""

    evaluator: str
    kind: str                       # e.g. "pii:EMAIL", "topic:finance", "content:HATE"
    action: str                     # evaluator-native action, e.g. BLOCKED / ANONYMIZED / NONE
    match: str | None = None        # original text span, if the evaluator exposes it
    replacement: str | None = None  # what it was replaced with, if anything
    detail: dict[str, Any] = Field(default_factory=dict)


class Verdict(BaseModel):
    evaluator: str
    blocked: bool = False
    text: str | None = None         # mutated text, None means unchanged
    reason: str | None = None
    findings: list[Finding] = Field(default_factory=list)
    error: str | None = None        # set when the evaluator failed; merger decides what that means
    # Evaluator-reported numbers worth exporting, e.g. {"usage.topicPolicyUnits": 1,
    # "processing_latency_ms": 143}. Telemetry turns these into OTel instruments.
    metrics: dict[str, float] = Field(default_factory=dict)


class Decision(BaseModel):
    action: Action
    body: str                       # full body to forward (mutate) or to return (block)
    status: int = 200
    reason: str = ""
    findings: list[Finding] = Field(default_factory=list)


@dataclass
class EvalContext:
    """Everything an evaluator or transform may need beyond the text itself."""

    phase: Phase
    policy: Policy
    request_id: str = ""
    extra: dict[str, Any] = field(default_factory=dict)

    @property
    def session_id(self) -> str:
        return self.policy.session_id or self.request_id
