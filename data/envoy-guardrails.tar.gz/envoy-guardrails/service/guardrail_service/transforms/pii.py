"""Mask on input, hydrate on output.

pii_record : input phase. Evaluators already replaced PII with placeholders
             (Bedrock ANONYMIZE, or an http evaluator). Store placeholder ->
             original in the vault keyed by session so the output phase can
             restore it. On the output phase it is a no-op.
pii_hydrate: output phase. Replace placeholders found in the model's answer
             with the originals stored for this session. No-op on input.

Limitation worth knowing: Bedrock uses one placeholder per PII *type*
({NAME}, {EMAIL}). Two names in one prompt both become {NAME}, so hydration
restores the last one seen. For loss-free hydration use an evaluator that
emits unique placeholders (e.g. {NAME_1}) via Finding.replacement.
"""

from __future__ import annotations

import logging

from ..schemas import EvalContext, Phase, Verdict
from .base import TRANSFORMS
from .vault import Vault

log = logging.getLogger(__name__)


@TRANSFORMS.register("pii_record")
class RecordMaskTransform:
    name = "pii_record"

    def __init__(self, vault: Vault) -> None:
        self._vault = vault

    async def apply(self, text: str, verdict: Verdict, ctx: EvalContext) -> str:
        if ctx.phase is not Phase.INPUT:
            return text
        mapping = {f.replacement: f.match for f in verdict.findings if f.replacement and f.match}
        if mapping:
            await self._vault.put(ctx.session_id, mapping)
            log.info("recorded %d masked entities", len(mapping), extra={"request_id": ctx.request_id})
        return text


@TRANSFORMS.register("pii_hydrate")
class HydrateTransform:
    name = "pii_hydrate"

    def __init__(self, vault: Vault) -> None:
        self._vault = vault

    async def apply(self, text: str, verdict: Verdict, ctx: EvalContext) -> str:
        if ctx.phase is not Phase.OUTPUT:
            return text
        mapping = await self._vault.get(ctx.session_id)
        for placeholder, original in mapping.items():
            text = text.replace(placeholder, original)
        return text
