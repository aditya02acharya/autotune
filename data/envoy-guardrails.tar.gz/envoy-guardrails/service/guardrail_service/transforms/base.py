"""Transforms run after the evaluators have merged, in the order listed in
policy.transforms. They may rewrite the text (e.g. hydrate placeholders on the
way out) or just record state (e.g. remember what was masked on the way in).
"""

from __future__ import annotations

from typing import Protocol

from ..registry import Registry
from ..schemas import EvalContext, Verdict


class Transform(Protocol):
    name: str

    async def apply(self, text: str, verdict: Verdict, ctx: EvalContext) -> str: ...


TRANSFORMS: Registry[Transform] = Registry("transform")
