"""Session vault: remembers placeholder -> original mappings between the input
and output phase of the same conversation turn.

The in-memory implementation is for a single process. Behind Envoy with
several service replicas, swap in RedisVault (same interface) so that the
output phase can land on any replica.
"""

from __future__ import annotations

import time
from typing import Protocol


class Vault(Protocol):
    async def put(self, session_id: str, mapping: dict[str, str]) -> None: ...
    async def get(self, session_id: str) -> dict[str, str]: ...


class InMemoryVault:
    def __init__(self, ttl_s: float = 600) -> None:
        self._ttl = ttl_s
        self._store: dict[str, tuple[float, dict[str, str]]] = {}

    async def put(self, session_id: str, mapping: dict[str, str]) -> None:
        self._evict()
        _, existing = self._store.get(session_id, (0, {}))
        self._store[session_id] = (time.monotonic() + self._ttl, {**existing, **mapping})

    async def get(self, session_id: str) -> dict[str, str]:
        self._evict()
        return dict(self._store.get(session_id, (0, {}))[1])

    def _evict(self) -> None:
        now = time.monotonic()
        for key in [k for k, (exp, _) in self._store.items() if exp < now]:
            del self._store[key]


class RedisVault:
    """Drop-in for multi-replica deployments. Requires `redis` (asyncio client)."""

    def __init__(self, url: str, ttl_s: int = 600, prefix: str = "gr:vault:") -> None:
        import redis.asyncio as redis  # optional dependency

        self._r = redis.from_url(url, decode_responses=True)
        self._ttl = ttl_s
        self._prefix = prefix

    async def put(self, session_id: str, mapping: dict[str, str]) -> None:
        if not mapping:
            return
        key = self._prefix + session_id
        async with self._r.pipeline() as pipe:
            pipe.hset(key, mapping=mapping)
            pipe.expire(key, self._ttl)
            await pipe.execute()

    async def get(self, session_id: str) -> dict[str, str]:
        return await self._r.hgetall(self._prefix + session_id)
