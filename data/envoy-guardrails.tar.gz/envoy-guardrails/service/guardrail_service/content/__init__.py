from .base import ADAPTERS, ContentAdapter, Document
from . import adapters as _adapters  # noqa: F401  registers built-ins

__all__ = ["ADAPTERS", "ContentAdapter", "Document"]
