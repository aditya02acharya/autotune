"""Content adapters know the shape of a body format.

They answer two questions:
  extract(doc, phase) -> which text should be evaluated for this phase
  inject(doc, text)   -> put mutated text back and re-serialise

Everything downstream (evaluators, transforms) only ever sees plain text.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol

from ..registry import Registry
from ..schemas import Phase


@dataclass
class Document:
    raw: str                 # body exactly as received
    data: Any = None         # parsed form, adapter specific (dict for JSON formats)


class ContentAdapter(Protocol):
    name: str

    def parse(self, raw: str) -> Document: ...
    def extract(self, doc: Document, phase: Phase) -> str: ...
    def inject(self, doc: Document, phase: Phase, text: str) -> str: ...


ADAPTERS: Registry[ContentAdapter] = Registry("content adapter")
