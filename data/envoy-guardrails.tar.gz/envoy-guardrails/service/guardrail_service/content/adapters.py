"""Built-in content adapters: raw text and OpenAI chat completions."""

from __future__ import annotations

import json
from typing import Any

from ..schemas import Phase
from .base import ADAPTERS, Document


@ADAPTERS.register("raw")
class RawAdapter:
    """Whole body is the text. Useful for plain completion endpoints and tests."""

    name = "raw"

    def parse(self, raw: str) -> Document:
        return Document(raw=raw)

    def extract(self, doc: Document, phase: Phase) -> str:
        return doc.raw

    def inject(self, doc: Document, phase: Phase, text: str) -> str:
        return text


@ADAPTERS.register("openai_chat")
class OpenAIChatAdapter:
    """OpenAI-compatible /v1/chat/completions (works for vLLM, Bedrock proxies, etc).

    input  phase: the last user message
    output phase: choices[0].message.content, or for a buffered SSE stream the
                  concatenation of choices[0].delta.content across chunks
    """

    name = "openai_chat"

    def parse(self, raw: str) -> Document:
        if _looks_like_sse(raw):
            return Document(raw=raw, data=SseStream.parse(raw))
        return Document(raw=raw, data=json.loads(raw) if raw else {})

    def extract(self, doc: Document, phase: Phase) -> str:
        if isinstance(doc.data, SseStream):
            return doc.data.text()
        holder = self._target(doc.data, phase)
        return _content_to_text(holder.get("content")) if holder else ""

    def inject(self, doc: Document, phase: Phase, text: str) -> str:
        if isinstance(doc.data, SseStream):
            return doc.data.with_text(text)
        holder = self._target(doc.data, phase)
        if holder is not None:
            holder["content"] = _text_to_content(holder.get("content"), text)
        return json.dumps(doc.data, ensure_ascii=False)

    @staticmethod
    def _target(data: dict[str, Any], phase: Phase) -> dict[str, Any] | None:
        if phase is Phase.INPUT:
            for msg in reversed(data.get("messages", [])):
                if msg.get("role") == "user":
                    return msg
            return None
        choices = data.get("choices") or []
        return choices[0].get("message") if choices else None


def _looks_like_sse(raw: str) -> bool:
    return raw.lstrip().startswith(("data:", "event:", ":"))


class SseStream:
    """A buffered OpenAI chat-completions SSE body.

    Events are kept verbatim except the JSON chunks that carry
    choices[0].delta.content. On rewrite, the full new text goes into the
    first content chunk and the remaining content chunks are emptied, so
    ids, finish_reason, usage and [DONE] are all preserved.
    """

    def __init__(self, events: list[str], chunks: dict[int, dict[str, Any]], sep: str) -> None:
        self.events = events           # raw event blocks, in order
        self.chunks = chunks           # index -> parsed JSON for content-bearing events
        self.sep = sep                 # "\r\n\r\n" or "\n\n", whatever the upstream used

    @classmethod
    def parse(cls, raw: str) -> "SseStream":
        sep = "\r\n\r\n" if "\r\n\r\n" in raw else "\n\n"
        events = raw.split(sep)
        chunks: dict[int, dict[str, Any]] = {}
        for i, event in enumerate(events):
            payload = _sse_data(event)
            if payload is None or payload.strip() == "[DONE]":
                continue
            try:
                obj = json.loads(payload)
            except ValueError:
                continue
            if _delta_content(obj) is not None:
                chunks[i] = obj
        return cls(events, chunks, sep)

    def text(self) -> str:
        return "".join(_delta_content(self.chunks[i]) or "" for i in sorted(self.chunks))

    def with_text(self, text: str) -> str:
        events = list(self.events)
        first = True
        for i in sorted(self.chunks):
            obj = self.chunks[i]
            obj["choices"][0]["delta"]["content"] = text if first else ""
            first = False
            events[i] = "data: " + json.dumps(obj, ensure_ascii=False)
        return self.sep.join(events)


def _sse_data(event: str) -> str | None:
    """Join the data: lines of one event; None if the event carries no data."""
    lines = [ln[5:].lstrip() for ln in event.splitlines() if ln.startswith("data:")]
    return "\n".join(lines) if lines else None


def _delta_content(obj: dict[str, Any]) -> str | None:
    choices = obj.get("choices") or []
    if not choices:
        return None
    return (choices[0].get("delta") or {}).get("content")


def _content_to_text(content: Any) -> str:
    """OpenAI content is either a string or a list of typed parts."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(p.get("text", "") for p in content if p.get("type") == "text")
    return ""


def _text_to_content(original: Any, text: str) -> Any:
    """Write text back in the same shape it came in. Multi-part content is
    collapsed to a single text part; non-text parts (images) are kept."""
    if isinstance(original, list):
        others = [p for p in original if p.get("type") != "text"]
        return [{"type": "text", "text": text}, *others]
    return text
