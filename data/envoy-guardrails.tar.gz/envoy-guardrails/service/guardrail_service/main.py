"""FastAPI entry point. Thin: parse headers, run pipeline, answer in headers."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Header, Request, Response
from opentelemetry.instrumentation.fastapi import FastAPIInstrumentor
from pydantic import ValidationError

from . import telemetry
from .config import Settings
from .evaluators import EVALUATORS
from .pipeline import Pipeline
from .schemas import Action, Decision, EvalContext, Phase, Policy
from .transforms import TRANSFORMS, InMemoryVault, RedisVault

log = logging.getLogger("guardrail_service")


def build_pipeline(settings: Settings) -> Pipeline:
    """Composition root. Add a line here when you add an evaluator or transform
    that needs process-level resources; everything else is discovered by name."""
    vault = RedisVault(settings.vault_redis_url, settings.vault_ttl_s) if settings.vault_redis_url \
        else InMemoryVault(settings.vault_ttl_s)

    evaluators = {
        "bedrock": EVALUATORS.create("bedrock", region=settings.aws_region, timeout_s=settings.bedrock_timeout_s),
        "http": EVALUATORS.create("http", timeout_s=settings.http_evaluator_timeout_s),
    }
    transforms = {
        "pii_record": TRANSFORMS.create("pii_record", vault=vault),
        "pii_hydrate": TRANSFORMS.create("pii_hydrate", vault=vault),
    }
    return Pipeline(evaluators=evaluators, transforms=transforms)


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = Settings()
    logging.basicConfig(level=settings.log_level, format="%(asctime)s %(levelname)s %(name)s %(message)s")
    telemetry.configure(settings.otel_enabled)
    app.state.settings = settings
    app.state.pipeline = build_pipeline(settings)
    yield


app = FastAPI(title="guardrail-service", lifespan=lifespan)
# Joins the trace Envoy started (traceparent is forwarded by the Lua filter).
FastAPIInstrumentor.instrument_app(app, excluded_urls="healthz")


@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/v1/evaluate")
async def evaluate(
    request: Request,
    x_gr_phase: str = Header(...),
    x_gr_policy: str = Header(...),
    x_request_id: str = Header(default=""),
) -> Response:
    settings: Settings = request.app.state.settings
    raw = await request.body()
    if len(raw) > settings.max_body_bytes:
        return _error(413, "body too large")

    try:
        policy = Policy.model_validate_json(x_gr_policy)
        phase = Phase(x_gr_phase)
    except (ValidationError, ValueError) as exc:
        return _error(400, f"bad instruction: {exc}")

    ctx = EvalContext(phase=phase, policy=policy, request_id=x_request_id)
    decision: Decision = await request.app.state.pipeline.run(raw.decode("utf-8", errors="replace"), ctx)
    return _reply(decision)


def _reply(d: Decision) -> Response:
    kinds = sorted({f.kind for f in d.findings})
    headers = {
        "x-gr-action": d.action.value,
        "x-gr-status": str(d.status),
        "x-gr-reason": d.reason[:200].replace("\n", " "),
        # Kinds only, never matched text. Lua copies this into dynamic metadata
        # so Envoy access logs show what fired even in passive mode.
        "x-gr-findings": ",".join(kinds)[:512],
    }
    # Lua only reads the body for block/mutate; keep allow responses tiny.
    body = d.body if d.action is not Action.ALLOW else ""
    return Response(content=body, media_type="application/octet-stream", headers=headers)


def _error(status: int, reason: str) -> Response:
    return Response(content=reason, status_code=status, media_type="text/plain")
