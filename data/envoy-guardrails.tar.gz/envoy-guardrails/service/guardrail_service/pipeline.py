"""The pipeline: adapt -> fan out evaluators -> merge -> transform -> decide.

Pipeline is stateless per request; all heavy clients live inside the
evaluator / transform instances it was constructed with.
"""

from __future__ import annotations

import asyncio
import json
import logging
from collections.abc import Mapping
from typing import Protocol

from .content import ADAPTERS, ContentAdapter
from .evaluators import Evaluator
from .schemas import Action, Decision, EvalContext, EvaluatorSpec, Mode, Verdict
from .telemetry import Stopwatch, Telemetry
from .transforms import Transform

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Merge strategy: how several verdicts become one
# ---------------------------------------------------------------------------
class VerdictMerger(Protocol):
    def merge(self, verdicts: list[Verdict], fail_open: bool) -> Verdict: ...


class AnyBlockMerger:
    """Block if any evaluator blocks. Mutations are applied in evaluator order
    (later ones see earlier output only if chained; here each evaluated the same
    original text, so we take the first mutation and keep all findings)."""

    def merge(self, verdicts: list[Verdict], fail_open: bool) -> Verdict:
        merged = Verdict(evaluator="merged")
        for v in verdicts:
            merged.findings.extend(v.findings)
            if v.error:
                if not fail_open:
                    merged.blocked = True
                    merged.reason = merged.reason or f"{v.evaluator} unavailable"
                continue
            if v.blocked:
                merged.blocked = True
                merged.reason = merged.reason or v.reason or f"blocked by {v.evaluator}"
            if v.text is not None and merged.text is None:
                merged.text = v.text
        return merged


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------
class Pipeline:
    def __init__(
        self,
        evaluators: Mapping[str, Evaluator],
        transforms: Mapping[str, Transform],
        merger: VerdictMerger | None = None,
        telemetry: Telemetry | None = None,
    ) -> None:
        self._evaluators = evaluators
        self._transforms = transforms
        self._merger = merger or AnyBlockMerger()
        self._tel = telemetry or Telemetry()

    async def run(self, body: str, ctx: EvalContext) -> Decision:
        clock = Stopwatch()
        with self._tel.span("guardrail.pipeline", phase=ctx.phase.value, mode=ctx.policy.mode.value,
                            tenant=ctx.policy.tenant) as span:
            decision = await self._run(body, ctx)
            span.set_attribute("guardrail.action", decision.action.value)
            span.set_attribute("guardrail.findings", len(decision.findings))
        self._tel.record_decision(ctx, decision, clock.ms)
        return decision

    async def _run(self, body: str, ctx: EvalContext) -> Decision:
        policy = ctx.policy
        adapter: ContentAdapter = ADAPTERS.create(policy.body_format)

        try:
            doc = adapter.parse(body)
        except ValueError as exc:
            log.warning("unparseable body (%s), allowing", exc, extra={"request_id": ctx.request_id})
            return Decision(action=Action.ALLOW, body=body, reason="unparseable body")

        text = adapter.extract(doc, ctx.phase)
        verdicts = await self._fan_out(text, ctx, policy.resolved_evaluators())
        merged = self._merger.merge(verdicts, fail_open=_fail_open(policy))

        new_text = merged.text if merged.text is not None else text
        for name in policy.transforms:
            new_text = await self._transforms[name].apply(new_text, merged, ctx)

        return self._decide(adapter, doc, ctx, text, new_text, merged)

    async def _fan_out(self, text: str, ctx: EvalContext, specs: list[EvaluatorSpec]) -> list[Verdict]:
        return list(await asyncio.gather(*(self._timed(text, ctx, s) for s in specs)))

    async def _timed(self, text: str, ctx: EvalContext, spec: EvaluatorSpec) -> Verdict:
        label = spec.params.get("name", spec.type)
        clock = Stopwatch()
        with self._tel.span("guardrail.evaluator", evaluator=label) as span:
            verdict = await self._evaluators[spec.type].evaluate(text, ctx, **spec.params)
            span.set_attribute("guardrail.blocked", verdict.blocked)
            if verdict.error:
                span.set_attribute("error", True)
        self._tel.record_verdict(ctx, label, verdict, clock.ms)
        return verdict

    # The one place that encodes "what does mode mean". Keep it tiny.
    @staticmethod
    def _decide(adapter, doc, ctx: EvalContext, text: str, new_text: str, merged: Verdict) -> Decision:
        kinds = sorted({f.kind for f in merged.findings})
        log.info(
            "evaluated",
            extra={"request_id": ctx.request_id, "phase": ctx.phase.value, "mode": ctx.policy.mode.value,
                   "blocked": merged.blocked, "mutated": new_text != text, "findings": kinds},
        )

        if ctx.policy.mode is Mode.PASSIVE:
            return Decision(action=Action.ALLOW, body=doc.raw, reason="passive", findings=merged.findings)

        if merged.blocked:
            body = json.dumps({"error": "blocked_by_guardrail", "reason": merged.reason or "", "phase": ctx.phase.value})
            return Decision(action=Action.BLOCK, body=body, status=ctx.policy.block_status,
                            reason=merged.reason or "blocked", findings=merged.findings)

        if new_text != text:
            return Decision(action=Action.MUTATE, body=adapter.inject(doc, ctx.phase, new_text),
                            reason="mutated", findings=merged.findings)

        return Decision(action=Action.ALLOW, body=doc.raw, findings=merged.findings)


def _fail_open(policy) -> bool:
    # fail_open is also read by Lua for transport errors; here it governs evaluator errors.
    return bool(getattr(policy, "fail_open", True))
