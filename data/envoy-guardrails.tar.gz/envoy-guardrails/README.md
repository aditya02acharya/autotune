# Envoy guardrails: Lua filter + Python evaluation service

Metadata-driven guardrails for an LLM gateway. Envoy's Lua filter ships request
and response bodies to a small FastAPI service, which fans them out to one or
more evaluators (AWS Bedrock Guardrails today, vLLM classifiers tomorrow) and
answers with a single instruction: **allow**, **block**, or **mutate**.

```
client ──► Envoy ─(x-gr-phase=input, x-gr-policy=json, raw body)─► guardrail-service
             │                                                        │ adapter.extract
             │                                                        │ fan-out evaluators (asyncio.gather)
             │                                                        │ merge verdicts
             │                                                        │ transforms (mask/hydrate)
             │ ◄──(x-gr-action, x-gr-status, x-gr-reason, body)───── │ decide
             ▼
         LLM upstream ──► Envoy ─(x-gr-phase=output ...)─► guardrail-service ─► client
```

The Lua filter is deliberately dumb: it resolves the policy from metadata,
forwards bodies, and executes the verdict. All reasoning lives in Python.

## Layout

```
envoy/
  envoy.yaml                 listener, lua filter, clusters, a static per-route default policy
  lua/guardrails.lua         the filter (no external Lua deps)
service/
  guardrail_service/
    main.py                  FastAPI: /v1/evaluate, /healthz, composition root (build_pipeline)
    pipeline.py              adapt -> fan out -> merge -> transform -> decide
    telemetry.py             OTel metrics and spans (no-op unless GR_OTEL_ENABLED)
    schemas.py               Policy, Verdict, Finding, Decision, EvalContext
    registry.py              generic name -> class registry
    content/                 body-format adapters (raw, openai_chat)
    evaluators/              bedrock (ApplyGuardrail), http (generic shim for vLLM etc)
    transforms/              pii_record / pii_hydrate + vault (in-memory, Redis)
  tests/                     pipeline and Bedrock parsing tests, no AWS needed
docker-compose.yaml
```

## The policy (dynamic metadata)

Set per request by whatever runs before the Lua filter (ext_authz / OPA emitting
dynamic metadata in the `guardrails` namespace). The route-level
`envoy.filters.http.lua` metadata in `envoy.yaml` is the fallback default, so
the demo works without ext_authz.

```yaml
enabled: true            # Lua: master switch
input: true              # Lua: evaluate request body
output: true             # Lua: buffer the full response (SSE included) and evaluate it;
                         #      false = stream through untouched
fail_open: true          # Lua and service: what to do when evaluation itself fails
block_status: 403

mode: active             # active (block/mutate) | passive (Lua fires the call async and
                         # never waits; service still evaluates fully for metrics)
tenant: "acme"           # low-cardinality label on every metric and span
body_format: openai_chat # service: which content adapter (raw | openai_chat)
session_id: "conv-123"   # service: key for mask/hydrate vault; defaults to x-request-id

# Single Bedrock guardrail shorthand ...
guardrail_id: "abc123"
guardrail_version: "1"

# ... or an explicit fan-out list (replaces the shorthand when present)
evaluators:
  - type: bedrock
    params: { guardrail_id: "abc123", guardrail_version: "1" }
  - type: http
    params: { name: pii_vllm, url: "http://pii-shim:9000/classify" }

transforms: [pii_record, pii_hydrate]
```

Unknown keys are preserved on `Policy` (`extra="allow"`), so a new evaluator
can read its own settings without schema changes.

## Decision rules (pipeline.py, `_decide`)

| mode    | any evaluator blocked | text changed | result |
|---------|-----------------------|--------------|--------|
| passive | any                   | any          | Lua: `httpCall(async=true)`, traffic never waits. Service: full evaluation, allow, findings exported as metrics |
| active  | yes                   |              | block with `block_status`, JSON error body |
| active  | no                    | yes          | mutate, adapter re-injects text into the original body |
| active  | no                    | no           | allow |

Evaluator errors: `fail_open: true` ignores that evaluator; `false` turns the
error into a block. Transport failures between Lua and the service follow the
same flag in Lua.

## Extending

**New evaluator** (e.g. a vLLM safety model with its own protocol):

```python
# evaluators/my_model.py
@EVALUATORS.register("my_model")
class MyModelEvaluator:
    name = "my_model"
    def __init__(self, base_url: str): ...
    async def evaluate(self, text, ctx, **params) -> Verdict: ...
```

Import it in `evaluators/__init__.py`, instantiate it in `build_pipeline`, and
reference it from `policy.evaluators`. For most self-hosted classifiers you do
not even need this: put a thin shim in front of the model that speaks the
`http` evaluator contract (see `evaluators/http.py`).

**New body format**: register a `ContentAdapter` in `content/adapters.py`
(e.g. `anthropic_messages`, `openai_responses`) and set `body_format`.

**New transform**: register a `Transform`; it receives the merged verdict and
the current text. Order is `policy.transforms` order.

**Different merge policy** (e.g. weighted, quorum): implement `VerdictMerger`
and pass it to `Pipeline`.

## Mask on input, hydrate on output

Already wired, behind `transforms`. On the input phase, evaluators that
anonymise (Bedrock with PII action ANONYMIZE, or an http evaluator that emits
`replacement`) produce findings with `match` and `replacement`; `pii_record`
stores `{placeholder: original}` in the vault under `session_id`. On the output
phase `pii_hydrate` substitutes them back.

Bedrock's own masked text uses one placeholder per PII type (`{NAME}` for every
name), which would make hydration lossy. The Bedrock evaluator therefore
ignores Bedrock's masked text and rebuilds it from the assessment findings,
which list every entity with its `match` and `type`: each distinct value gets
`{NAME_1}`, `{NAME_2}`, and repeats of the same value reuse the same
placeholder. The model sees consistent references and hydration is exact.
Set `params.unique_placeholders: false` on the evaluator to get Bedrock's
native `{NAME}` form back.

**How the mapping survives from request to response.** Envoy only carries
dynamic metadata between the two phases, and the mapping is never put there.
The Lua filter saves the stream's `x-request-id` in metadata at request time
and sends it on both service calls; the service keys the vault on
`policy.session_id` if the tenant supplies one, else that request id. So the
correlation key goes through Envoy, the PII stays in the service. Returning
the mapping to Lua in a header would put raw PII in Envoy memory, in reach of
access-log formatters, and would hit header size limits on large prompts.

Caveats:

- The rebuild is a longest-first string substitution of the matched values, so
  a value that is a substring of unrelated text could in theory over-mask.
  Bedrock does not return offsets, so this is the best available signal.
- The in-memory vault is single-replica only. With more than one service
  replica the output phase can land on a different pod, so set
  `GR_VAULT_REDIS_URL` (same `Vault` interface, `RedisVault`). TTL
  `GR_VAULT_TTL_S` should exceed the longest generation you allow.
- Hydration needs the output phase to be `active`; in passive mode the
  service never rewrites the body.

## Observability

The service exports OpenTelemetry metrics and traces over OTLP when
`GR_OTEL_ENABLED=true`; endpoint, service name and resource attributes come
from the standard `OTEL_*` env vars. Envoy traces with its OpenTelemetry
tracer and the Lua filter forwards `traceparent`, so a request shows as
`envoy-gateway -> guardrail.pipeline -> guardrail.evaluator` in one trace.

| instrument | type | attributes |
|---|---|---|
| `guardrail.evaluations` | counter | phase, mode, tenant, action |
| `guardrail.pipeline.duration` | histogram (ms) | phase, mode, tenant, action |
| `guardrail.evaluator.duration` | histogram (ms) | + evaluator, outcome |
| `guardrail.evaluator.errors` | counter | + evaluator |
| `guardrail.findings` | counter | + evaluator, kind (`topic:finance`, `pii:NAME`, `content:HATE`...), finding_action (`BLOCKED`, `ANONYMIZED`, `NONE`) |
| `guardrail.evaluator.units` | counter | + evaluator, unit (Bedrock billing units: `topicPolicyUnits`...) |
| `guardrail.evaluator.upstream_latency` | histogram (ms) | + evaluator (Bedrock's own `guardrailProcessingLatency`) |

Every Bedrock filter that matched becomes its own finding, including filters
in detect-only mode (`action=NONE`, `detected=true`), so passive mode gives a
complete picture of what *would* fire before switching a tenant to active.
Attribute cardinality is deliberately low: no request ids, session ids or
matched text.

On the Envoy side the Lua filter writes the verdict to dynamic metadata
(`guardrails.lua:{input,output}_{action,reason,findings}`); `envoy.yaml`
shows an access log that prints them. `docker-compose.yaml` runs an OTel
collector exposing Prometheus metrics on `:8889/metrics`.

## Running

```bash
cd service && pip install -e ".[dev]" && pytest          # unit tests, no AWS
docker compose up --build                                 # Envoy :10000, service :8080
curl localhost:10000/v1/chat/completions -H 'content-type: application/json' \
  -d '{"model":"x","messages":[{"role":"user","content":"my email is alice@example.com"}]}'
```

Service config is environment-driven with prefix `GR_` (see `config.py`).

## Known limits

- **Output evaluation buffers.** With `output: true` the Lua filter holds the
  whole response, SSE included, until the upstream finishes, then evaluates
  it. The client sees the first byte only after the full generation, so
  time-to-first-token is lost on guarded routes; the route timeout bounds the
  wait. The `openai_chat` adapter understands buffered SSE: it joins the
  `delta.content` chunks for evaluation and, on mutate, writes the new text
  into the first content chunk and empties the rest, keeping ids,
  `finish_reason`, `usage` and `[DONE]` as they were. A block replaces the
  stream with a JSON error and the `block_status` code.
- Compressed bodies (`content-encoding`) are skipped; put the decompressor
  filter before the Lua filter if upstreams gzip.
- Buffered body size is bounded by `per_connection_buffer_limit_bytes` on the
  cluster and `GR_MAX_BODY_BYTES` on the service.
- Findings can contain the matched PII text. The service logs `kind` and
  `action` only; keep it that way if you add logging.
