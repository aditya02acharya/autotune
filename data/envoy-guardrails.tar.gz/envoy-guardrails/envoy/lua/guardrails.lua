-- guardrails.lua
--
-- Envoy Lua filter that forwards request and response bodies to the guardrail
-- service and executes whatever the service decides: allow, block or mutate.
--
-- The filter holds no policy logic. Everything is driven by metadata:
--   1. dynamic metadata, namespace "guardrails"  (set per request by ext_authz / OPA / header_to_metadata)
--   2. route metadata, namespace "envoy.filters.http.lua", key "guardrails"  (static per-route default)
--
-- Keys the Lua filter itself understands (all optional):
--   enabled        bool   master switch                                   default true
--   input          bool   evaluate request body                           default true
--   output         bool   buffer the full response (SSE included) and      default false
--                         evaluate it. false = stream through untouched
--   fail_open      bool   on service error: true=forward, false=block     default true
--   block_status   number status used when the filter must block locally  default 403
--   mode           string active | passive                                default active
--                         passive = fire-and-forget: the body is sent to the
--                         service asynchronously and traffic is never held or
--                         altered. The service still evaluates fully for metrics.
--
-- Every other key (guardrail_id, guardrail_version, evaluators, transforms,
-- session_id, body_format, tenant, ...) is opaque to Lua and forwarded verbatim as
-- JSON in the x-gr-policy header for the Python service to interpret.
--
-- Observability: the verdict is written to dynamic metadata namespace
-- "guardrails.lua" (keys <phase>_action, <phase>_reason, <phase>_findings) so it
-- can appear in access logs via %DYNAMIC_METADATA(guardrails.lua:input_action)%.
-- traceparent/tracestate from the client request are forwarded to the service so
-- its spans join the gateway trace.
--
-- Wire contract with the service:
--   POST /v1/evaluate
--     headers: x-gr-phase (input|output), x-gr-policy (json), x-request-id
--     body:    raw upstream body, unchanged
--   response:
--     x-gr-action: allow | block | mutate
--     x-gr-status: HTTP status to use when action=block
--     x-gr-reason: short human readable reason
--     body:        replacement body (for block and mutate)

local GR = {
  dyn_namespace   = "guardrails",
  route_key       = "guardrails",
  state_namespace = "guardrails.lua",
  cluster         = "guardrail_service",
  path            = "/v1/evaluate",
  authority       = "guardrails",
  timeout_ms      = 5000,
}

----------------------------------------------------------------------------
-- Minimal JSON encoder (tables, arrays, strings, numbers, booleans).
-- Decoding is never needed on the Lua side: the service speaks via headers.
----------------------------------------------------------------------------
local encode

local function is_array(t)
  local n = 0
  for _ in pairs(t) do n = n + 1 end
  return n > 0 and n == #t
end

local function encode_string(s)
  s = s:gsub('[%c"\\]', function(c)
    local map = { ['"'] = '\\"', ['\\'] = '\\\\', ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t' }
    return map[c] or string.format("\\u%04x", c:byte())
  end)
  return '"' .. s .. '"'
end

encode = function(v)
  local t = type(v)
  if t == "nil" then return "null" end
  if t == "boolean" then return tostring(v) end
  if t == "number" then return tostring(v) end
  if t == "string" then return encode_string(v) end
  if t == "table" then
    local parts = {}
    if is_array(v) then
      for _, item in ipairs(v) do parts[#parts + 1] = encode(item) end
      return "[" .. table.concat(parts, ",") .. "]"
    end
    for k, item in pairs(v) do
      parts[#parts + 1] = encode_string(tostring(k)) .. ":" .. encode(item)
    end
    return "{" .. table.concat(parts, ",") .. "}"
  end
  return "null"
end

----------------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------------
local function flag(policy, key, default)
  local v = policy[key]
  if v == nil then return default end
  if type(v) == "string" then return v == "true" or v == "1" end
  return v and true or false
end

local function read_body(handle)
  local body = handle:body(true)
  local len = body:length()
  if len == 0 then return body, "" end
  return body, body:getBytes(0, len)
end

local function set_body(handle, body, new_bytes)
  body:setBytes(new_bytes)
  local headers = handle:headers()
  headers:replace("content-length", tostring(#new_bytes))
end

-- Resolve the policy: dynamic metadata wins, route metadata is the default.
local function resolve_policy(handle)
  local dyn = handle:streamInfo():dynamicMetadata():get(GR.dyn_namespace)
  if dyn ~= nil and next(dyn) ~= nil then return dyn end
  local route = handle:metadata():get(GR.route_key)
  if route ~= nil then return route end
  return nil
end

local function is_passive(policy)
  return tostring(policy.mode or "active") == "passive"
end

-- Persist per-stream state so envoy_on_response does not re-resolve.
local function save_state(handle, policy, policy_json, request_id)
  local md = handle:streamInfo():dynamicMetadata()
  local req = handle:headers()
  md:set(GR.state_namespace, "policy", policy)
  md:set(GR.state_namespace, "policy_json", policy_json)
  md:set(GR.state_namespace, "request_id", request_id)
  md:set(GR.state_namespace, "traceparent", req:get("traceparent") or "")
  md:set(GR.state_namespace, "tracestate", req:get("tracestate") or "")
end

local function load_state(handle)
  return handle:streamInfo():dynamicMetadata():get(GR.state_namespace)
end

local function record_verdict(handle, phase, action, reason, findings)
  local md = handle:streamInfo():dynamicMetadata()
  md:set(GR.state_namespace, phase .. "_action", action)
  md:set(GR.state_namespace, phase .. "_reason", reason or "")
  md:set(GR.state_namespace, phase .. "_findings", findings or "")
end

----------------------------------------------------------------------------
-- Service call and decision execution
----------------------------------------------------------------------------
local function service_headers(phase, state, body_str)
  local h = {
    [":method"]      = "POST",
    [":path"]        = GR.path,
    [":authority"]   = GR.authority,
    ["content-type"] = "application/octet-stream",
    ["x-gr-phase"]   = phase,
    ["x-gr-policy"]  = state.policy_json,
    ["x-request-id"] = state.request_id or "",
  }
  if state.traceparent and state.traceparent ~= "" then h["traceparent"] = state.traceparent end
  if state.tracestate and state.tracestate ~= "" then h["tracestate"] = state.tracestate end
  return h
end

local function call_service(handle, phase, state, body_str, async)
  local ok, headers, resp_body = pcall(handle.httpCall, handle, GR.cluster,
    service_headers(phase, state, body_str), body_str, GR.timeout_ms, async)

  if not ok then
    handle:logErr("guardrails: httpCall failed: " .. tostring(headers))
    return nil, nil
  end
  return headers, resp_body
end

local function block_request(handle, status, body)
  handle:respond({ [":status"] = tostring(status), ["content-type"] = "application/json" }, body)
end

local function block_response(handle, body_obj, status, body)
  local headers = handle:headers()
  headers:replace(":status", tostring(status))
  headers:replace("content-type", "application/json")
  set_body(handle, body_obj, body)
end

local function on_service_error(handle, phase, policy, body_obj)
  if flag(policy, "fail_open", true) then
    handle:logWarn("guardrails: " .. phase .. " evaluation failed, failing open")
    return
  end
  local status = tonumber(policy.block_status) or 403
  local msg = '{"error":"guardrail_unavailable"}'
  handle:logWarn("guardrails: " .. phase .. " evaluation failed, failing closed")
  if phase == "input" then block_request(handle, status, msg) else block_response(handle, body_obj, status, msg) end
end

-- Shared logic for both phases. Returns nothing; side effects on handle.
local function evaluate(handle, phase, state)
  local policy = state.policy
  if handle:headers():get("content-encoding") ~= nil then
    handle:logInfo("guardrails: skipping " .. phase .. " (compressed body)")
    record_verdict(handle, phase, "skipped", "compressed", "")
    return
  end

  local body_obj, body_str = read_body(handle)

  if is_passive(policy) then
    -- Fire and forget: Envoy does not wait for the response.
    call_service(handle, phase, state, body_str, true)
    record_verdict(handle, phase, "passive", "", "")
    return
  end

  local headers, resp_body = call_service(handle, phase, state, body_str, false)

  if headers == nil or headers[":status"] ~= "200" then
    record_verdict(handle, phase, "error", "service_unavailable", "")
    on_service_error(handle, phase, policy, body_obj)
    return
  end

  local action = headers["x-gr-action"] or "allow"
  local reason = headers["x-gr-reason"] or ""
  record_verdict(handle, phase, action, reason, headers["x-gr-findings"])
  handle:logInfo(string.format("guardrails: %s action=%s reason=%s", phase, action, reason))

  if action == "block" then
    local status = tonumber(headers["x-gr-status"]) or tonumber(policy.block_status) or 403
    if phase == "input" then block_request(handle, status, resp_body)
    else block_response(handle, body_obj, status, resp_body) end
  elseif action == "mutate" then
    set_body(handle, body_obj, resp_body)
  end
  -- "allow": nothing to do, body continues as is
end

----------------------------------------------------------------------------
-- Envoy entry points
----------------------------------------------------------------------------
function envoy_on_request(handle)
  local policy = resolve_policy(handle)
  if policy == nil or not flag(policy, "enabled", true) then return end

  local request_id = handle:headers():get("x-request-id") or ""
  save_state(handle, policy, encode(policy), request_id)

  if flag(policy, "input", true) then
    evaluate(handle, "input", load_state(handle))
  end
end

function envoy_on_response(handle)
  local state = load_state(handle)
  if state == nil or state.policy == nil then return end

  if not flag(state.policy, "output", false) then return end

  -- handle:body() buffers the full response, including an SSE stream, until
  -- the upstream finishes. The route timeout bounds how long that can take.
  -- In passive mode the buffering still happens (the body must exist to be
  -- sent) but the client is never blocked on the evaluation result.
  evaluate(handle, "output", state)
end
