# local full-duplex voicebot

Phone-call-style voice chat on one machine: streaming ASR, filler-aware
endpointing, barge-in with instant playback flush, streaming Claude with
tool calling, sentence-chunked TTS.

## Stack (fits in <2GB of an 8GB GPU)

| stage | model / lib | runs on |
|---|---|---|
| VAD | Silero VAD | CPU |
| ASR | faster-whisper `small` int8 | GPU |
| LLM | Claude (`anthropic` SDK, streaming + tools) | API |
| TTS | Kokoro-82M | GPU/CPU |
| edge | `websockets` (binary PCM + JSON control) | — |

## Run

```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...   # already in your env per setup
python -m voicebot.server             # terminal 1
python client.py                      # terminal 2 — then just talk
```

## Apple Silicon (M1/M2/M3/M4)

Only the two model stages are platform-specific; `voicebot/backend.py` detects
the chip and the rest is unchanged. On Apple Silicon, ASR runs on the GPU/ANE
via **mlx-whisper** (Metal), and TTS runs through **kokoro-onnx** (ONNX Runtime,
NEON SIMD) — several times faster than Kokoro-on-PyTorch for an 82M model, and
it avoids Apple's MPS entirely (whose vocoder op-fallbacks are slower than CPU).

```bash
brew install ffmpeg espeak-ng portaudio    # espeak-ng for Kokoro g2p
python3 -m venv .venv && source .venv/bin/activate   # native arm64 Python
pip install -r requirements-mac.txt

# one-time: fetch the Kokoro ONNX model + voices into the working dir
BASE=https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0
curl -L -O $BASE/kokoro-v1.0.onnx
curl -L -O $BASE/voices-v1.0.bin

export ANTHROPIC_API_KEY=sk-ant-...
python -m voicebot.server
python client.py
```

The factories pick the Apple-native engines automatically when their libs are
present (`make_asr()` → mlx-whisper, `make_tts()` → kokoro-onnx) and fall back to
faster-whisper / Kokoro-PyTorch otherwise — no code change. Paths to the ONNX
files are in `config.py` (`kokoro_onnx_model`, `kokoro_onnx_voices`).

## Why WebSockets, not gRPC (here)

Single box ⇒ the pipeline stages share a process and pass numpy arrays
through asyncio — zero serialization. The only socket is the client edge,
where WebSockets give framing/backpressure for free and stay
browser-compatible. gRPC earns its keep when stages move to separate
machines: `orchestrator.py` is transport-agnostic (two async callbacks),
so the migration is "wrap each stage in a grpc.aio bidirectional-streaming
servicer" with no logic changes.

## Latency budget (targets)

- mic frame → VAD decision: <1ms
- endpoint commit: 0.7s silence (1.6s after fillers like "um", "to...")
- commit → first audio (TTFA): ~600–900ms locally
  (final ASR pass ~150ms + Claude first sentence ~400ms + Kokoro ~200ms)
- barge-in → silence: one frame (32ms) + flush

Knobs live in `voicebot/config.py`.
