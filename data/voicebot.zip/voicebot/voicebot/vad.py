"""Frame-level voice activity detection. CPU, ~µs per 32ms frame."""
import numpy as np
import torch
from silero_vad import load_silero_vad

from .config import CFG


class StreamingVAD:
    def __init__(self) -> None:
        self._model = load_silero_vad()  # tiny; lives on CPU

    def is_speech(self, frame_i16: np.ndarray) -> bool:
        """frame_i16: int16 mono, exactly CFG.frame_samples long."""
        f32 = torch.from_numpy(frame_i16.astype(np.float32) / 32768.0)
        return self._model(f32, CFG.in_rate).item() >= CFG.vad_threshold

    def reset(self) -> None:
        """Clear recurrent state between utterances."""
        self._model.reset_states()
