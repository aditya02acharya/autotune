"""Streaming Claude responses with tool calling.

Reads ANTHROPIC_API_KEY from the environment (SDK default). The whole
generator is cancellable: dropping it mid-stream aborts the HTTP stream,
which is how barge-in kills generation.
"""
import json
from datetime import datetime
from typing import AsyncIterator

from anthropic import AsyncAnthropic

from .config import CFG

TOOLS = [{
    "name": "get_local_time",
    "description": "Get the current local date and time.",
    "input_schema": {"type": "object", "properties": {}},
}]


def _run_tool(name: str, args: dict) -> str:
    if name == "get_local_time":
        return datetime.now().strftime("%A %d %B %Y, %H:%M")
    return f"unknown tool {name}"


class LLM:
    def __init__(self) -> None:
        self._client = AsyncAnthropic()

    async def stream_reply(self, history: list[dict]) -> AsyncIterator[str]:
        """Yield text deltas; transparently resolves tool calls between turns."""
        messages = list(history)
        while True:
            async with self._client.messages.stream(
                model=CFG.llm_model,
                max_tokens=CFG.llm_max_tokens,
                system=CFG.system_prompt,
                tools=TOOLS,
                messages=messages,
            ) as stream:
                async for text in stream.text_stream:
                    yield text
                final = await stream.get_final_message()

            if final.stop_reason != "tool_use":
                return
            # Execute tools, append results, loop for the follow-up turn.
            results = [{
                "type": "tool_result",
                "tool_use_id": block.id,
                "content": _run_tool(block.name, block.input or {}),
            } for block in final.content if block.type == "tool_use"]
            messages += [
                {"role": "assistant", "content": final.content},
                {"role": "user", "content": results},
            ]
