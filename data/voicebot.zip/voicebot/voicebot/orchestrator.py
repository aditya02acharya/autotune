"""Turn-taking orchestrator: the full-duplex state machine.

States:  LISTENING → (endpoint) → RESPONDING → LISTENING
Barge-in: speech detected while RESPONDING ⇒ cancel the response task,
tell the client to flush its playback buffer, start a fresh user turn.

Transport-agnostic: talks to the outside world only via two async
callbacks (send_audio, send_event), so the WebSocket edge — or a future
gRPC servicer — is a thin shell around this class.
"""
import asyncio
import contextlib
import time
from enum import Enum, auto
from typing import Awaitable, Callable

import numpy as np

from .asr import make_asr
from .config import CFG
from .endpoint import Endpointer
from .llm import LLM
from .pacing import PacedSender
from .tts import SentenceChunker, make_tts, sanitize_for_speech
from .vad import StreamingVAD

SendAudio = Callable[[bytes], Awaitable[None]]
SendEvent = Callable[[dict], Awaitable[None]]


class State(Enum):
    LISTENING = auto()
    RESPONDING = auto()


class Orchestrator:
    def __init__(self, send_audio: SendAudio, send_event: SendEvent) -> None:
        self.vad = StreamingVAD()
        self.asr = make_asr()
        self.endpoint = Endpointer()
        self.llm = LLM()
        self.tts = make_tts()
        self.send_audio, self.send_event = send_audio, send_event

        self.state = State.LISTENING
        self.history: list[dict] = []
        self._utterance: list[np.ndarray] = []
        self._partial = ""
        self._last_partial_t = 0.0
        self._response_task: asyncio.Task | None = None

    # ── input path: one 32ms frame at a time ──────────────────────────────
    async def on_frame(self, frame_i16: np.ndarray) -> None:
        speech = self.vad.is_speech(frame_i16)

        if self.state is State.RESPONDING:
            if speech:                      # ← barge-in
                await self._interrupt()
            else:
                return                      # bot speaking, user silent

        if speech or self._utterance:
            self._utterance.append(frame_i16)

        if speech and self._due_partial():
            asyncio.create_task(self._refresh_partial())

        if self._utterance and self.endpoint.feed(speech, self._partial):
            await self._commit_turn()

    # ── speculative-ish partial transcription while the user talks ────────
    def _due_partial(self) -> bool:
        return time.monotonic() - self._last_partial_t >= CFG.asr_partial_interval_s

    async def _refresh_partial(self) -> None:
        self._last_partial_t = time.monotonic()
        audio = np.concatenate(self._utterance)
        self._partial = await self.asr.transcribe(audio)
        await self.send_event({"type": "partial", "text": self._partial})

    # ── turn commit → respond ──────────────────────────────────────────────
    async def _commit_turn(self) -> None:
        audio = np.concatenate(self._utterance)
        self._reset_input()
        text = await self.asr.transcribe(audio)   # final, committed pass
        if not text:
            return
        await self.send_event({"type": "final", "text": text})
        self.history.append({"role": "user", "content": text})
        self.state = State.RESPONDING
        self._response_task = asyncio.create_task(self._respond())

    async def _respond(self) -> None:
        chunker, spoken = SentenceChunker(), []
        pacer = PacedSender(self.send_audio, CFG.out_rate, CFG.tts_lead_s)
        try:
            async for delta in self.llm.stream_reply(self.history):
                for sentence in chunker.push(delta):
                    await self._speak(sentence, spoken, pacer)
            for sentence in chunker.flush():
                await self._speak(sentence, spoken, pacer)
        finally:
            # On barge-in, record only what the user actually heard.
            if spoken:
                self.history.append({"role": "assistant",
                                     "content": " ".join(spoken)})
            self.state = State.LISTENING
            await self.send_event({"type": "state", "value": "listening"})

    async def _speak(self, sentence: str, spoken: list[str],
                     pacer: PacedSender) -> None:
        speakable = sanitize_for_speech(sentence)   # strip markdown before TTS
        if speakable:
            async for pcm in self.tts.speak(speakable):
                await pacer.send(pcm)
        spoken.append(sentence)                     # history keeps the original
        await self.send_event({"type": "say", "text": sentence})

    # ── barge-in ───────────────────────────────────────────────────────────
    async def _interrupt(self) -> None:
        if self._response_task and not self._response_task.done():
            self._response_task.cancel()
            with contextlib.suppress(asyncio.CancelledError):
                await self._response_task
        await self.send_event({"type": "flush"})   # client drops queued audio
        self.state = State.LISTENING
        self._reset_input()

    def _reset_input(self) -> None:
        self._utterance.clear()
        self._partial = ""
        self.endpoint.reset()
        self.vad.reset()
