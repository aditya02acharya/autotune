"""Streaming-ish ASR with a per-platform backend.

Whisper isn't natively streaming; the local pattern is cheap re-transcription
of the rolling buffer, with the final pass on endpoint as the committed text.
Both backends share that interface and the GPU-serializing lock; the only
difference is the engine underneath. Heavy imports are lazy so each platform
installs only the deps it needs.
"""
import asyncio
from typing import Protocol

import numpy as np

from .backend import asr_backend
from .config import CFG


class ASR(Protocol):
    async def transcribe(self, audio_i16: np.ndarray) -> str: ...


class _FasterWhisperASR:
    """CTranslate2 backend — CUDA int8 on NVIDIA, int8 on CPU elsewhere."""
    def __init__(self) -> None:
        from faster_whisper import WhisperModel
        try:
            self._model = WhisperModel(CFG.asr_model, device="cuda",
                                       compute_type="int8_float16")
        except Exception:  # no CUDA (incl. Apple Silicon) → CPU int8
            self._model = WhisperModel(CFG.asr_model, device="cpu",
                                       compute_type="int8")
        self._busy = asyncio.Lock()

    def _transcribe(self, audio_i16: np.ndarray) -> str:
        f32 = audio_i16.astype(np.float32) / 32768.0
        segments, _ = self._model.transcribe(
            f32, language="en", beam_size=1, vad_filter=False,
            condition_on_previous_text=False)
        return " ".join(s.text.strip() for s in segments).strip()

    async def transcribe(self, audio_i16: np.ndarray) -> str:
        async with self._busy:
            return await asyncio.to_thread(self._transcribe, audio_i16)


class _MLXWhisperASR:
    """Apple Silicon backend — runs Whisper on the GPU/ANE via Apple's MLX."""
    def __init__(self) -> None:
        import mlx_whisper
        self._mlx = mlx_whisper
        self._repo = CFG.asr_mlx_repo
        self._busy = asyncio.Lock()

    def _transcribe(self, audio_i16: np.ndarray) -> str:
        f32 = audio_i16.astype(np.float32) / 32768.0
        out = self._mlx.transcribe(
            f32, path_or_hf_repo=self._repo, language="en",
            condition_on_previous_text=False)
        return out["text"].strip()

    async def transcribe(self, audio_i16: np.ndarray) -> str:
        async with self._busy:
            return await asyncio.to_thread(self._transcribe, audio_i16)


def make_asr() -> ASR:
    """Pick the right ASR engine for this machine."""
    return _MLXWhisperASR() if asr_backend() == "mlx" else _FasterWhisperASR()
