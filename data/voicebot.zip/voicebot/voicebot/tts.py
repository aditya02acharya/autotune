"""Streaming TTS with a per-platform Kokoro backend.

Synthesize a sentence at a time, then yield small PCM frames so the paced
sender can keep the client buffer shallow (low barge-in latency). Two backends
share that chunking via _ChunkedTTS; they differ only in the engine:

- Apple Silicon → kokoro-onnx (ONNX Runtime, NEON SIMD): much faster than
  PyTorch-on-CPU for an 82M model, and avoids MPS op-fallback thrash.
- CUDA / other  → kokoro (PyTorch) on the detected device.

sanitize_for_speech strips markdown so the synth never voices '*', '#', or URLs.
"""
import asyncio
import re
from typing import AsyncIterator, Protocol

import numpy as np

from .config import CFG

_SENTENCE_END = re.compile(r"(?<=[.!?…])\s+")

# ── markdown → speakable text ─────────────────────────────────────────────
_STRIP = [
    (re.compile(r"```.*?```", re.DOTALL), " "),   # fenced code
    (re.compile(r"`([^`]+)`"), r"\1"),            # inline code
    (re.compile(r"\*\*([^*]+)\*\*"), r"\1"),      # bold
    (re.compile(r"\*([^*]+)\*"), r"\1"),          # italic
    (re.compile(r"^#{1,6}\s+", re.M), ""),        # headings
    (re.compile(r"^\s*[-*•]\s+", re.M), ""),      # bullet markers
    (re.compile(r"https?://\S+"), ""),            # raw URLs
    (re.compile(r"\s+"), " "),                    # collapse whitespace
]


def sanitize_for_speech(text: str) -> str:
    for pat, repl in _STRIP:
        text = pat.sub(repl, text)
    return text.strip()


class SentenceChunker:
    """Accumulate LLM deltas; emit complete sentences as soon as they close."""
    def __init__(self) -> None:
        self._buf = ""

    def push(self, delta: str) -> list[str]:
        self._buf += delta
        *done, self._buf = _SENTENCE_END.split(self._buf)
        return [s.strip() for s in done if s.strip()]

    def flush(self) -> list[str]:
        tail, self._buf = self._buf.strip(), ""
        return [tail] if tail else []


# ── TTS backends ──────────────────────────────────────────────────────────
class TTS(Protocol):
    def speak(self, text: str) -> AsyncIterator[bytes]: ...


def _f32_to_pcm16(x: np.ndarray) -> bytes:
    return (np.clip(x, -1, 1) * 32767).astype(np.int16).tobytes()


class _ChunkedTTS:
    """Shared logic: synth a sentence under the GPU lock, then yield small
    frames OUTSIDE the lock so pacing one sentence never blocks ASR."""
    def __init__(self) -> None:
        self._busy = asyncio.Lock()

    def _synth(self, text: str) -> bytes:           # int16 PCM @ CFG.out_rate
        raise NotImplementedError

    async def speak(self, text: str) -> AsyncIterator[bytes]:
        async with self._busy:
            pcm = await asyncio.to_thread(self._synth, text)
        step = int(CFG.tts_chunk_ms / 1000 * CFG.out_rate) * 2  # bytes, int16
        for i in range(0, len(pcm), step):
            yield pcm[i:i + step]


class _KokoroTorchTTS(_ChunkedTTS):
    def __init__(self, voice: str = "af_heart") -> None:
        super().__init__()
        from kokoro import KPipeline
        from .backend import torch_device
        dev = torch_device()
        try:
            self._pipe = KPipeline(lang_code="a", device=dev)
        except TypeError:
            self._pipe = KPipeline(lang_code="a")
        self._voice = voice

    def _synth(self, text: str) -> bytes:
        parts = [audio for _, _, audio in self._pipe(text, voice=self._voice)]
        pcm = np.concatenate(parts) if parts else np.zeros(0, dtype=np.float32)
        return _f32_to_pcm16(pcm)


class _KokoroOnnxTTS(_ChunkedTTS):
    def __init__(self, voice: str = "af_heart") -> None:
        super().__init__()
        from kokoro_onnx import Kokoro
        self._k = Kokoro(CFG.kokoro_onnx_model, CFG.kokoro_onnx_voices)
        self._voice = voice

    def _synth(self, text: str) -> bytes:
        samples, sr = self._k.create(text, voice=self._voice, speed=1.0,
                                     lang="en-us")   # 24kHz float32
        return _f32_to_pcm16(np.asarray(samples, dtype=np.float32))


def make_tts() -> TTS:
    from .backend import tts_backend
    return _KokoroOnnxTTS() if tts_backend() == "onnx" else _KokoroTorchTTS()
