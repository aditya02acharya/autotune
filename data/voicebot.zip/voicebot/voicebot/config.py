"""All tunables in one place. Latency knobs are marked."""
from dataclasses import dataclass, field


@dataclass(frozen=True)
class Config:
    # Audio formats
    in_rate: int = 16_000           # mic sample rate (Silero/Whisper native)
    out_rate: int = 24_000          # Kokoro output rate
    frame_samples: int = 512        # 32ms @ 16kHz — Silero's required chunk size

    # VAD / endpointing  [latency knobs]
    vad_threshold: float = 0.5
    endpoint_silence_s: float = 0.7      # silence to commit a complete-looking turn
    endpoint_silence_long_s: float = 1.6 # silence after a filler / dangling clause
    min_utterance_s: float = 0.25        # ignore blips shorter than this

    # ASR
    asr_model: str = "small"             # ~1GB int8 on GPU (faster-whisper)
    asr_mlx_repo: str = "mlx-community/whisper-small-mlx"  # Apple Silicon
    asr_partial_interval_s: float = 0.6  # re-transcribe cadence while user speaks

    # LLM
    llm_model: str = "claude-sonnet-4-6"
    llm_max_tokens: int = 1024
    system_prompt: str = (
        "You are a voice assistant. Keep replies short and conversational — "
        "one to three sentences. No markdown, no lists."
    )

    # TTS  [latency knobs]
    tts_chunk_ms: int = 40          # audio frame size sent to client
    tts_lead_s: float = 0.15        # max audio buffered ahead on the client
    #   ↑ also the worst-case stop latency on barge-in
    # Apple Silicon ONNX path — download from the kokoro-onnx v1.0 release:
    kokoro_onnx_model: str = "kokoro-v1.0.onnx"
    kokoro_onnx_voices: str = "voices-v1.0.bin"

    # Words that signal "I'm not done talking" → wait longer before responding
    fillers: frozenset = field(default_factory=lambda: frozenset(
        {"um", "uh", "umm", "uhh", "er", "hmm", "like", "so", "and", "but",
         "because", "to", "the", "a", "of", "or"}
    ))

    host: str = "localhost"
    port: int = 8765


CFG = Config()
