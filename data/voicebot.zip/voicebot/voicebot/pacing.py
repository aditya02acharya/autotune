"""Paced audio sender.

The server can push audio far faster than it plays. If it dumps the whole
reply into the client buffer, cancelling generation can't recall it — the bot
keeps talking. This sends at ~playback rate, keeping at most `lead_s` buffered
ahead, so a cancellation stops the voice within ~lead_s.

clock/sleep are injectable so the pacing logic is unit-testable without real time.
"""
import asyncio
import time
from typing import Awaitable, Callable

Send = Callable[[bytes], Awaitable[None]]


class PacedSender:
    def __init__(self, send: Send, rate: int, lead_s: float = 0.15, *,
                 clock: Callable[[], float] = time.monotonic,
                 sleep: Callable[[float], Awaitable[None]] = asyncio.sleep) -> None:
        self._send = send
        self._rate = rate          # samples/sec, int16 mono ⇒ 2 bytes/sample
        self._lead = lead_s
        self._clock = clock
        self._sleep = sleep
        self._t0: float | None = None
        self._sent_s = 0.0         # seconds of audio handed to the client

    async def send(self, pcm: bytes) -> None:
        if self._t0 is None:
            self._t0 = self._clock()
        await self._send(pcm)
        self._sent_s += len(pcm) / 2 / self._rate
        # How far ahead of real-time playback are we? Sleep off the excess.
        ahead = self._sent_s - (self._clock() - self._t0)
        if ahead > self._lead:
            await self._sleep(ahead - self._lead)   # ← cancellation point
