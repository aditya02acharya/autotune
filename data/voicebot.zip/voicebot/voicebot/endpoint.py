"""Decides 'the user has finished their turn'.

Silence alone is not enough: a pause after "book a flight to..." is not an
endpoint. Heuristic here: require longer silence when the partial transcript
ends in a filler/dangling word. (A learned semantic endpointer slots in by
replacing `_required_silence`.)
"""
from .config import CFG

FRAME_S = CFG.frame_samples / CFG.in_rate


class Endpointer:
    def __init__(self) -> None:
        self.silence_frames = 0
        self.speech_frames = 0

    def reset(self) -> None:
        self.silence_frames = 0
        self.speech_frames = 0

    def _required_silence(self, partial: str) -> float:
        words = partial.lower().rstrip(".!?,").split()
        if not words:
            return CFG.endpoint_silence_long_s
        dangling = words[-1] in CFG.fillers or partial.rstrip().endswith(("...", ","))
        return CFG.endpoint_silence_long_s if dangling else CFG.endpoint_silence_s

    def feed(self, is_speech: bool, partial: str) -> bool:
        """Call once per frame during a user turn. True ⇒ commit the turn."""
        if is_speech:
            self.speech_frames += 1
            self.silence_frames = 0
            return False
        self.silence_frames += 1
        long_enough = self.speech_frames * FRAME_S >= CFG.min_utterance_s
        return (long_enough and
                self.silence_frames * FRAME_S >= self._required_silence(partial))
