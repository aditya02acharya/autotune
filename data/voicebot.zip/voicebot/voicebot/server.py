"""WebSocket edge. Binary frames in = 16kHz mic PCM; binary out = 24kHz TTS
PCM; JSON text frames = control events. Swap this file for a grpc.aio
servicer with two streaming RPCs and nothing else changes.
"""
import asyncio
import json

import numpy as np
import websockets

from .config import CFG
from .orchestrator import Orchestrator


async def _session(ws) -> None:
    print(f"client connected: {ws.remote_address}")
    orch = Orchestrator(
        send_audio=ws.send,
        send_event=lambda e: ws.send(json.dumps(e)),
    )
    buf = np.zeros(0, dtype=np.int16)
    async for msg in ws:
        if not isinstance(msg, bytes):
            continue
        buf = np.concatenate([buf, np.frombuffer(msg, dtype=np.int16)])
        while len(buf) >= CFG.frame_samples:           # re-frame to 512 samples
            frame, buf = buf[:CFG.frame_samples], buf[CFG.frame_samples:]
            await orch.on_frame(frame)


async def main() -> None:
    async with websockets.serve(_session, CFG.host, CFG.port, max_size=2**22):
        print(f"voicebot listening on ws://{CFG.host}:{CFG.port}")
        await asyncio.Future()


if __name__ == "__main__":
    asyncio.run(main())
