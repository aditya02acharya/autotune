"""Platform detection. One place decides which model backend fits the hardware,
so the rest of the code stays platform-agnostic.

- Apple Silicon  → mlx-whisper (Metal/ANE) for ASR, Kokoro on CPU for TTS.
- NVIDIA / Linux → faster-whisper (CUDA int8) for ASR, Kokoro on CUDA.
- Anything else  → faster-whisper (CPU), Kokoro on CPU.

Kokoro deliberately avoids Apple's MPS: its vocoder hits ops MPS doesn't
implement, forcing per-op CPU fallbacks whose round-trips are slower than
just running the 82M model on CPU.
"""
import importlib.util
import platform


def is_apple_silicon() -> bool:
    return platform.system() == "Darwin" and platform.machine() == "arm64"


def _have(module: str) -> bool:
    return importlib.util.find_spec(module) is not None


def asr_backend() -> str:
    """'mlx' on Apple Silicon when mlx-whisper is installed, else 'faster'."""
    if is_apple_silicon() and _have("mlx_whisper"):
        return "mlx"
    return "faster"


def torch_device() -> str:
    """Device for Silero VAD and Kokoro (PyTorch). Never 'mps' (see docstring)."""
    try:
        import torch
        if torch.cuda.is_available():
            return "cuda"
    except Exception:
        pass
    return "cpu"


def tts_backend() -> str:
    """'onnx' on Apple Silicon when kokoro-onnx is installed (NEON SIMD, no MPS
    thrash), else 'torch' (Kokoro on CUDA/CPU)."""
    if is_apple_silicon() and _have("kokoro_onnx"):
        return "onnx"
    return "torch"
