"""Terminal voice client. Mic → server, server audio → speakers.
The playback buffer is flushable: on a 'flush' event (barge-in) any queued
bot speech is dropped instantly — that's what makes interruption feel real.
"""
import asyncio
import json
import threading

import numpy as np
import sounddevice as sd
import websockets

from voicebot.config import CFG


class FlushablePlayer:
    """Pull-based output stream over a lockable byte buffer.

    `gen` is bumped on every flush; audio fed with an older gen is dropped, so
    any chunk that was in flight when the user barged in can't sneak through.
    """
    def __init__(self) -> None:
        self._buf = bytearray()
        self._lock = threading.Lock()
        self._gen = 0
        self._stream = sd.RawOutputStream(
            samplerate=CFG.out_rate, channels=1, dtype="int16",
            callback=self._cb)
        self._stream.start()

    def _cb(self, out, frames, *_):
        n = frames * 2  # int16 → 2 bytes/sample
        with self._lock:
            chunk = bytes(self._buf[:n])
            del self._buf[:n]
        out[:len(chunk)] = chunk
        out[len(chunk):] = b"\x00" * (n - len(chunk))

    @property
    def gen(self) -> int:
        return self._gen

    def feed(self, pcm: bytes, gen: int) -> None:
        with self._lock:
            if gen == self._gen:          # ignore audio from a cancelled turn
                self._buf += pcm

    def flush(self) -> None:
        with self._lock:
            self._buf.clear()
            self._gen += 1


async def main() -> None:
    uri = f"ws://{CFG.host}:{CFG.port}"
    async with websockets.connect(uri, max_size=2**22) as ws:
        player = FlushablePlayer()
        loop = asyncio.get_running_loop()

        def mic_cb(indata, *_):
            loop.call_soon_threadsafe(
                asyncio.ensure_future, ws.send(bytes(indata)))

        mic = sd.RawInputStream(
            samplerate=CFG.in_rate, channels=1, dtype="int16",
            blocksize=CFG.frame_samples, callback=mic_cb)
        mic.start()
        print("🎤 connected — speak (Ctrl+C to quit)")

        async for msg in ws:
            if isinstance(msg, bytes):
                player.feed(msg, player.gen)
                continue
            ev = json.loads(msg)
            match ev["type"]:
                case "partial":
                    print(f"\r… {ev['text']}", end="", flush=True)
                case "final":
                    print(f"\rYOU: {ev['text']}")
                case "say":
                    print(f"BOT: {ev['text']}")
                case "flush":
                    player.flush()
                    print("⏹  (interrupted)")


if __name__ == "__main__":
    asyncio.run(main())
