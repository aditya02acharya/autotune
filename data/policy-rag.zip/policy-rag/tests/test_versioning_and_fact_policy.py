"""Dual-identity diff classifications and table-fact thresholds."""
from policy_rag.config import Config
from policy_rag.ingest import ExtractedDocument, build_units, ingest
from policy_rag.models import UnitType
from policy_rag.tables import RawTableFragment
from policy_rag.versioning import UnitRecord, diff_versions

R = lambda text, titles=(), utype="clause", h=None: UnitRecord(
    text_hash=h or text, unit_type=utype, section_titles=tuple(titles),
    text=text)

OBLIGATION = ("All credit exposures above the delegated limit require "
              "written approval from the regional credit committee before "
              "funds are released to the counterparty.")


def test_moved_and_changed_is_traced_not_delete_plus_add():
    old = {"s4.2": R(OBLIGATION, titles=("Approvals",))}
    new = {"s7.1": R(OBLIGATION.replace("regional", "group")
                     + " Exceptions must be logged.",
                     titles=("Governance",))}
    plan = diff_versions(old, new)
    assert plan.moved_and_changed == {"s4.2": "s7.1"}
    assert not plan.added and not plan.removed


def test_renumbered_vs_moved_distinguished_by_parent_titles():
    old = {"a": R(OBLIGATION, titles=("Approvals",)),
           "b": R("Records are archived securely offsite.", titles=("Records",))}
    new = {"a2": R(OBLIGATION, titles=("Approvals",)),       # renumbered
           "b2": R("Records are archived securely offsite.",
                   titles=("Appendix",))}                     # moved
    plan = diff_versions(old, new)
    assert plan.renumbered == {"a": "a2"}
    assert plan.moved == {"b": "b2"}


def test_split_one_clause_into_two():
    a = "Approval requires committee sign off and a documented rationale."
    b = "All exceptions must be escalated to the chief risk officer promptly."
    old = {"big": R(a + " " + b)}
    new = {"p1": R(a), "p2": R(b)}
    plan = diff_versions(old, new)
    assert plan.split == {"big": ["p1", "p2"]}
    assert not plan.removed and not plan.added


def test_merged_two_clauses_into_one():
    a = "Approval requires committee sign off and a documented rationale."
    b = "All exceptions must be escalated to the chief risk officer promptly."
    old = {"p1": R(a), "p2": R(b)}
    new = {"big": R(a + " " + b)}
    plan = diff_versions(old, new)
    assert plan.merged == {"big": ["p1", "p2"]}


def test_unrelated_units_stay_added_and_removed():
    plan = diff_versions(
        {"x": R("Vendor onboarding requires sanctions screening checks.")},
        {"y": R("Quarterly liquidity stress testing covers all entities.")})
    assert plan.removed == ["x"] and plan.added == ["y"]
    assert not plan.moved_and_changed


def _doc_with_table(rows, version="v1", fh="h1"):
    return ExtractedDocument(
        doc_slug="d", doc_title="Doc", version_label=version,
        file_bytes_hash=fh,
        pages=[["1 Limits", "Limits are in Table 1."]],
        tables=[(["1"], "Table 1", [RawTableFragment(page=1, rows=rows)])])


SMALL = [["Tier", "Limit (GBP)"], ["Retail", "500,000"], ["Corp", "750,000"]]


def test_small_high_confidence_table_gets_embedded_facts():
    cfg = Config()
    units, *_ , skips = build_units(_doc_with_table(SMALL), cfg)
    facts = [u for u in units if u.unit_type == UnitType.TABLE_FACT]
    assert facts and all(f.force_embed for f in facts)
    assert skips["table:1:1"] is None


def test_oversized_table_skips_facts_with_reason_but_keeps_rows():
    cfg = Config()
    cfg.facts.max_fact_cells = 1   # force the threshold
    units, *_, skips = build_units(_doc_with_table(SMALL), cfg)
    assert not [u for u in units if u.unit_type == UnitType.TABLE_FACT]
    assert [u for u in units if u.unit_type == UnitType.TABLE_ROW]
    assert skips["table:1:1"].startswith("too_large:")
    res = ingest(_doc_with_table(SMALL), cfg)
    assert res.metrics["fact_generation_skipped"]["table:1:1"]


def test_low_confidence_table_skips_facts_with_reason():
    cfg = Config()
    cfg.facts.min_fact_confidence = 1.01   # nothing qualifies
    units, *_, skips = build_units(_doc_with_table(SMALL), cfg)
    assert not [u for u in units if u.unit_type == UnitType.TABLE_FACT]
    assert skips["table:1:1"].startswith("low_confidence:")


def test_ordinal_collision_is_not_misclassified_as_rewording():
    """A clause moves out of §1; an unrelated new sentence inherits its
    ordinal slot. Structural same-key matching must not claim the old
    clause was 'reworded' into the newcomer — lineage must trace the move."""
    rmp = ("Exposure data follows the Records Management Policy and must be "
           "reconciled with vendor inventories.")
    old = {"s1.o2": R(rmp, titles=("Retention",))}
    new = {"s1.o2": R("Retention runs from account closure for every "
                      "product line.", titles=("Retention",)),
           "s3.o1": R(rmp + " Reconciliation is quarterly.",
                      titles=("Third Parties",))}
    plan = diff_versions(old, new)
    assert plan.wording_changed == []                  # collision rejected
    assert plan.moved_and_changed == {"s1.o2": "s3.o1"}
    assert plan.added == ["s1.o2"]                     # slot's new occupant


def test_partial_split_traces_migrated_content_and_keeps_slot():
    """One block keeps its key with half its content; the other half moves
    into a new unit elsewhere. wording_changed AND content_migrated."""
    seven = "Customer records retention period is seven years from closure."
    rmp = ("Exposure data follows the Records Management Policy framework "
           "for archival handling purposes.")
    old = {"s1": R(seven + " " + rmp, titles=("Retention",))}
    new = {"s1": R(seven + " This applies to every product line.",
                   titles=("Retention",)),
           "s3": R(rmp + " Reconciliation is quarterly.",
                   titles=("Third Parties",))}
    plan = diff_versions(old, new)
    assert plan.wording_changed == ["s1"]
    assert plan.migrated == {"s1": ["s3"]}
    assert plan.added == ["s3"]                  # still inserted as new
    assert ("s1", "s3", "content_migrated") in plan.lineage_pairs()
