import json

from policy_rag.config import Config
from policy_rag.contextualize import build_context_header
from policy_rag.ingest import ExtractedDocument, build_units, ingest
from policy_rag.models import Provenance, UnitType
from policy_rag.tables import RawTableFragment
from policy_rag.versioning import UnitRecord, diff_versions

PAGES_V1 = [[
    "1 Introduction",
    "This policy sets out the credit approval framework.",
    "",
    "4 Approvals",
    "4.2 Exception Handling",
    "Exceptions to standard credit limits must be approved by the Regional "
    "Credit Committee before customer notification.",
    "",
    "Queries to credit.policy@bank.example only.",
]]

TABLE = (["4", "4.2"], "Table 2: Limits", [RawTableFragment(page=1, rows=[
    ["Segment", "Limit (GBP)"], ["Retail", "250,000"], ["Corporate", "2,000,000"],
])])


def make_doc(pages=None, version="v1", file_hash="hash-1"):
    return ExtractedDocument("credit-risk", "Credit Risk Approval Policy",
                             version, file_hash, pages or PAGES_V1, [TABLE])


def test_units_are_contextualized_and_understandable_in_isolation():
    units, *_ = build_units(make_doc(), Config())
    clause = next(u for u in units
                  if "Regional Credit Committee" in u.source_text
                  and u.unit_type == UnitType.CLAUSE)
    assert "Credit Risk Approval Policy v1" in clause.retrieval_text
    assert "4.2 Exception Handling" in clause.retrieval_text
    assert clause.provenance.page_start == 1
    assert clause.parent_key  # linked to its section heading


def test_table_units_at_all_grains_with_context():
    units, conf, *_ = build_units(make_doc(), Config())
    rows = [u for u in units if u.unit_type == UnitType.TABLE_ROW]
    facts = [u for u in units if u.unit_type == UnitType.TABLE_FACT]
    assert len(rows) == 2 and len(facts) == 2
    fact = next(f for f in facts if f.table.row_header_path == ["Retail"])
    assert fact.table.col_header_path == ["Limit"]
    assert fact.table.unit_of_measure == "GBP"
    assert fact.table.cell_value == "250,000"
    assert "Table 2: Limits" in fact.retrieval_text


def test_pii_flagged_and_masked_in_retrieval_text():
    units, *_ = build_units(make_doc(), Config())
    pii_unit = next(u for u in units if "credit.policy" in u.source_text)
    assert pii_unit.contains_pii and "email" in pii_unit.pii_types
    assert "credit.policy@bank.example" not in pii_unit.retrieval_text
    assert "[EMAIL_1]" in pii_unit.retrieval_text
    assert pii_unit.embedding_source == "masked"


def test_no_empty_units_and_gates_pass_on_clean_doc():
    result = ingest(make_doc(), Config())
    assert result.status == "succeeded"
    assert result.metrics["empty_units"] == 0
    assert result.metrics["whitespace_only_units"] == 0
    assert all(u.source_text.strip() for u in result.units)


def test_metrics_shape(tmp_path):
    result = ingest(make_doc(), Config())
    m = result.metrics
    for k in ("pages", "units_total", "unit_size_p50", "unit_size_p95",
              "table_fact_units", "llm_calls", "quarantined_units",
              "duplicate_units", "orphaned_units"):
        assert k in m
    json.dumps(m)  # serializable


def test_oversized_blocks_split_at_sentence_boundaries():
    long_para = ". ".join(f"Clause sentence number {i} applies" for i in range(80))
    doc = make_doc(pages=[["1 Scope", long_para + "."]])
    units, *_ = build_units(doc, Config())
    clauses = [u for u in units if u.unit_type == UnitType.CLAUSE]
    assert len(clauses) > 1
    assert all(len(c.source_text) <= Config().gates.max_unit_chars
               for c in clauses)


def rec(text, utype="clause", titles=(), h=None):
    return UnitRecord(text_hash=h or text, unit_type=utype,
                      section_titles=tuple(titles), text=text)


def units_to_records(units):
    return {u.unit_key: UnitRecord(text_hash=u.text_hash,
                                   unit_type=u.unit_type.value,
                                   section_titles=tuple(u.provenance.section_titles),
                                   text=u.source_text)
            for u in units}


def test_version_diff_unchanged_changed_added_removed_renumbered():
    old = {"k1": rec("alpha beta gamma"), "k2": rec("delta epsilon zeta"),
           "k3": rec("unique removed clause about archival"),
           "k_old_num": rec("limits apply quarterly", titles=("Limits",))}
    new = {"k1": rec("alpha beta gamma"),
           "k2": rec("delta epsilon zeta REVISED", h="changed"),
           "k4": rec("entirely new onboarding requirements text"),
           "k_new_num": rec("limits apply quarterly", titles=("Limits",))}
    plan = diff_versions(old, new)
    assert set(plan.carry_forward) == {"k1"}
    assert plan.wording_changed == ["k2"]
    assert plan.renumbered == {"k_old_num": "k_new_num"}  # same parent titles
    assert set(plan.added) == {"k4"} and set(plan.removed) == {"k3"}


def test_unchanged_reingestion_is_noop_at_unit_level():
    cfg = Config()
    u1, *_ = build_units(make_doc(), cfg)
    u2, *_ = build_units(make_doc(version="v2", file_hash="hash-2"), cfg)
    # same content, new version -> every unit carries forward
    plan = diff_versions(units_to_records(u1), units_to_records(u2))
    assert plan.is_noop and len(plan.carry_forward) == len(u1)


def test_changed_clause_creates_new_unit_version_only():
    cfg = Config()
    changed_pages = [list(PAGES_V1[0])]
    changed_pages[0][5] = changed_pages[0][5].replace(
        "Regional Credit Committee", "Group Credit Committee")
    u1, *_ = build_units(make_doc(), cfg)
    u2, *_ = build_units(make_doc(pages=changed_pages, version="v2",
                                 file_hash="hash-2"), cfg)
    plan = diff_versions(units_to_records(u1), units_to_records(u2))
    assert len(plan.wording_changed) == 1
    assert not plan.added and not plan.removed


def test_context_header_builder():
    p = Provenance(doc_slug="credit-risk", doc_title="Credit Risk Approval Policy",
                   version_label="v3.1", source_file_hash="h",
                   page_start=7, page_end=7, section_path=["4", "4.2"],
                   section_titles=["Approvals", "Exception Handling"])
    assert build_context_header(p) == (
        "Credit Risk Approval Policy v3.1 › 4 Approvals › 4.2 Exception Handling")


def test_doc_summary_emitted_and_version_invariant():
    cfg = Config()
    u1, *_ = build_units(make_doc(), cfg)
    u2, *_ = build_units(make_doc(version="v9", file_hash="hash-9"), cfg)
    s1 = [u for u in u1 if u.unit_type == UnitType.DOC_SUMMARY]
    s2 = [u for u in u2 if u.unit_type == UnitType.DOC_SUMMARY]
    assert len(s1) == 1 and len(s2) == 1
    assert "Credit Risk Approval Policy" in s1[0].source_text
    # version lives in the context header, never in the hashed source text
    assert s1[0].text_hash == s2[0].text_hash
    assert "v9" in s2[0].retrieval_text
