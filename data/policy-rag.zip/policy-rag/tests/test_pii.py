import logging

import pytest

from policy_rag.config import Config, PIIPolicy
from policy_rag.llm import ElevationRequired, GuardedLLMClient, PIISafeLogger
from policy_rag.pii import apply_pii_policy, detect_pii

SAMPLE = ("Contact jane.doe@bank.example or 020 7946 0958. "
          "NI: AB 12 34 56 C. Employee EMP-12345. "
          "Card 4539 1488 0343 6467.")  # Luhn-valid


def test_detection_types_and_placeholders():
    findings = detect_pii(SAMPLE)
    types = {f.pii_type for f in findings}
    assert {"email", "phone", "uk_nino", "employee_id", "card_number"} <= types
    # stable per-value placeholders
    email = next(f for f in findings if f.pii_type == "email")
    assert email.placeholder == "[EMAIL_1]"


def test_luhn_rejects_invalid_card_numbers():
    findings = detect_pii("Reference number 1234 5678 9012 3456 applies.")
    assert not any(f.pii_type == "card_number" for f in findings)


def test_masking_and_drop_and_preserve():
    policy = PIIPolicy()
    policy.actions["employee_id"] = "drop"
    policy.actions["uk_nino"] = "preserve"
    findings = detect_pii(SAMPLE)
    masked, applied = apply_pii_policy(SAMPLE, findings, policy)
    assert "jane.doe@bank.example" not in masked and "[EMAIL_1]" in masked
    assert "EMP-12345" not in masked and "[EMPLOYEE_ID_1]" not in masked  # dropped
    assert "AB 12 34 56 C" in masked                                      # preserved
    assert "email" in applied and "uk_nino" not in applied


class EchoBackend:
    def __init__(self):
        self.last_prompt = None

    def complete(self, prompt, system=None):
        self.last_prompt = prompt
        return "ok"


def test_guarded_llm_masks_and_audits():
    cfg = Config()
    backend = EchoBackend()
    client = GuardedLLMClient(cfg, backend)
    client.complete(SAMPLE, purpose="answer_synthesis")
    assert "jane.doe@bank.example" not in backend.last_prompt
    rec = client.calls[0]
    assert rec.pii_present and rec.input_kind == "masked"
    assert rec.prompt_stored is False and rec.prompt_text is None
    assert rec.cost_estimate > 0 and rec.token_estimate > 0


def test_guarded_llm_refuses_when_meaning_requires_raw_pii():
    client = GuardedLLMClient(Config(), EchoBackend())
    with pytest.raises(ElevationRequired):
        client.complete(SAMPLE, purpose="verify_identity",
                        pii_required_for_meaning=True)


def test_guarded_llm_allows_raw_when_configured():
    cfg = Config()
    cfg.pii.allow_raw_pii_to_llm = True
    backend = EchoBackend()
    GuardedLLMClient(cfg, backend).complete(SAMPLE, purpose="x")
    assert "jane.doe@bank.example" in backend.last_prompt


def test_pii_safe_logger_drops_text_by_default(caplog):
    logger = PIISafeLogger(Config())
    with caplog.at_level(logging.INFO, logger="policy_rag"):
        logger.event("unit_ingested", unit_key="abc", n_chars=120,
                     text="Contact jane.doe@bank.example")
    assert "jane.doe@bank.example" not in caplog.text
    assert "abc" in caplog.text
