from policy_rag.answer import GroundedAnswer, synthesize
from policy_rag.config import Config, QualityGates
from policy_rag.llm import GuardedLLMClient
from policy_rag.models import EvidenceUnit, Provenance, UnitStatus, UnitType
from policy_rag.quality import run_gates


def unit(text, utype=UnitType.CLAUSE, key="k", page=1, **kw):
    u = EvidenceUnit(unit_type=utype, source_text=text,
                     provenance=Provenance(doc_slug="d", doc_title="Doc", version_label="v1",
                                           source_file_hash="h", page_start=page,
                                           page_end=page, section_path=["1"],
                                           section_titles=["Scope"]),
                     ordinal=0, unit_key=key, **kw)
    u.finalize_hashes()
    return u


def test_empty_unit_is_hard_failure():
    res = run_gates([unit("   \n  ")], QualityGates())
    assert not res.ok
    assert res.hard_failures[0]["reason"] == "empty_or_whitespace_unit"


def test_duplicate_key_is_hard_failure():
    res = run_gates([unit("a", key="same"), unit("b", key="same")],
                    QualityGates())
    assert any(f["reason"] == "duplicate_unit_key" for f in res.hard_failures)


def test_broken_parent_link_is_hard_failure():
    u = unit("child", key="c")
    u.parent_key = "missing-parent"
    res = run_gates([u], QualityGates())
    assert any(f["reason"] == "broken_parent_link" for f in res.hard_failures)


def test_noise_and_whitespace_quarantined_not_fatal():
    noisy = unit("|||| ____ .... ---- ||||", key="n")
    res = run_gates([noisy], QualityGates())
    assert res.ok
    assert noisy.status == UnitStatus.QUARANTINED
    assert res.quarantined[0]["reason"] == "layout_noise"


def test_missing_page_provenance_quarantined():
    u = unit("Valid clause text here.", key="p")
    u.provenance.page_start = None
    res = run_gates([u], QualityGates())
    assert any(q["reason"] == "missing_page_provenance" for q in res.quarantined)


def test_low_confidence_table_quarantined():
    from policy_rag.models import TableContext
    u = unit("Retail | Limit: 500", utype=UnitType.TABLE_ROW, key="t",
             table=TableContext(table_key="tk", row_idx=0, row_header_path=["Retail"]))
    res = run_gates([u], QualityGates(), table_confidence={"tk": 0.2})
    assert any(q["reason"] == "low_confidence_table_parse"
               for q in res.quarantined)


# ---------- grounded answering ----------

class ScriptedBackend:
    def __init__(self, reply):
        self.reply = reply

    def complete(self, prompt, system=None):
        return self.reply


def hits(*ids):
    return [{"unit_id": i, "unit_type": "clause", "retrieval_text": f"text {i}",
             "context_header": f"Doc › §{i}", "page_start": 1, "page_end": 1,
             "status": "active", "contains_pii": False} for i in ids]


def test_answer_cites_retrieved_units():
    llm = GuardedLLMClient(Config(), ScriptedBackend(
        "Limits require committee approval [[aaaa1111]] [[bbbb2222]]."))
    ans = synthesize("who approves?", hits("aaaa1111", "bbbb2222"), llm)
    assert ans.citations == ["aaaa1111", "bbbb2222"]
    assert ans.confidence == "high" and ans.used_llm


def test_uncited_or_hallucinated_citation_rejected():
    llm = GuardedLLMClient(Config(), ScriptedBackend(
        "It is approved by the CFO [[ffff9999]]."))   # not in retrieved set
    ans = synthesize("who approves?", hits("aaaa1111"), llm)
    assert ans.confidence == "insufficient"
    assert "citation_validation_failed" in ans.limitations


def test_no_evidence_yields_honest_refusal_without_llm():
    llm = GuardedLLMClient(Config(), ScriptedBackend("should not be called"))
    ans = synthesize("what is the lunar policy?", [], llm)
    assert ans.confidence == "insufficient" and not ans.used_llm
    assert not llm.calls   # the LLM was never invoked
