"""Orchestrator loop mechanics, tested with a scripted LLM backend so the
agent-as-a-tool path is verified deterministically (no network)."""
import json

from policy_rag.config import Config
from policy_rag.llm import GuardedLLMClient
from policy_rag.orchestrator import (build_registry, compact, harvest_units,
                                     run_research)

UNIT = {"unit_id": "11111111-1111-1111-1111-111111111111",
        "unit_type": "clause", "retrieval_text": "Retention is 7 years.",
        "context_header": "DP v2 › 1", "page_start": 1, "page_end": 1,
        "status": "active"}


class FakeStorage:
    def __init__(self):
        self.calls = []

    def __getattr__(self, name):
        def method(*a, **kw):
            self.calls.append((name, a, kw))
            if name == "hybrid_search":
                return [dict(UNIT)]
            if name == "list_documents":
                return [{"slug": "dp", "title": "Data Protection"}]
            return []
        return method


class ScriptedBackend:
    """Pops canned completions; records prompts for assertions."""
    def __init__(self, replies):
        self.replies = list(replies)
        self.prompts = []

    def complete(self, prompt, system=None):
        self.prompts.append((prompt, system))
        return self.replies.pop(0)


def make_llm(replies):
    return GuardedLLMClient(Config(), ScriptedBackend(replies))


def test_loop_executes_actions_harvests_and_synthesizes_with_citation():
    uid = UNIT["unit_id"]
    storage = FakeStorage()
    llm = make_llm([
        json.dumps({"action": "documents"}),
        json.dumps({"action": "search", "args": {"query": "retention"}}),
        json.dumps({"action": "finish"}),
        f"Records are retained for 7 years [[{uid}]].",  # synthesis
    ])
    res = run_research("How long are records kept?", storage, llm, max_steps=5)
    assert [t.get("action") for t in res.trajectory] == \
        ["documents", "search", "finish"]
    assert res.n_evidence_units == 1
    assert res.answer.citations == [uid]
    assert res.answer.confidence != "insufficient"
    assert ("hybrid_search", ("retention", 8),
            {"unit_types": None, "section_prefix": None}) in storage.calls


def test_step_cap_forces_synthesis_from_gathered_evidence():
    uid = UNIT["unit_id"]
    storage = FakeStorage()
    llm = make_llm([
        json.dumps({"action": "search", "args": {"query": "retention"}}),
        json.dumps({"action": "search", "args": {"query": "retention period"}}),
        f"Retention is 7 years [[{uid}]].",
    ])
    res = run_research("retention?", storage, llm, max_steps=2)
    assert len([t for t in res.trajectory if t.get("action") == "search"]) == 2
    assert res.answer.citations == [uid]


def test_malformed_json_and_unknown_action_are_recoverable():
    uid = UNIT["unit_id"]
    storage = FakeStorage()
    llm = make_llm([
        "I think I should search first!",                  # no JSON
        json.dumps({"action": "summon_lawyer"}),           # unknown
        json.dumps({"action": "search", "args": {"query": "retention"}}),
        json.dumps({"action": "finish"}),
        f"7 years [[{uid}]].",
    ])
    res = run_research("retention?", storage, llm, max_steps=5)
    errors = [t for t in res.trajectory if "error" in t]
    assert {e["error"] for e in errors} == {"unparseable_action",
                                            "unknown_action"}
    assert res.answer.citations == [uid]


def test_no_evidence_means_insufficient_without_synthesis_llm_call():
    storage = FakeStorage()
    llm = make_llm([json.dumps({"action": "finish"})])  # nothing gathered
    res = run_research("anything?", storage, llm, max_steps=3)
    assert res.answer.confidence == "insufficient"
    assert not llm.backend.replies  # no extra completion consumed


def test_bad_args_become_observation_not_crash():
    storage = FakeStorage()

    def boom(**kw):
        raise TypeError("missing required argument: 'doc_slug'")
    reg = build_registry(storage)
    llm = make_llm([
        json.dumps({"action": "overview", "args": {"wrong": 1}}),
        json.dumps({"action": "finish"}),
    ])
    res = run_research("?", storage, llm, max_steps=3)
    assert any("error" in t and t.get("action") == "overview"
               for t in res.trajectory)


def test_harvest_finds_units_in_nested_structures():
    pool = {}
    harvest_units({"unit": UNIT, "neighbors": [UNIT],
                   "links": [{"foo": [UNIT]}]}, pool)
    assert list(pool) == [UNIT["unit_id"]]


def test_compact_truncates_text_lists_and_strips_embeddings():
    obj = {"retrieval_text": "x" * 500, "embedding": [0.0] * 768,
           "rows": list(range(20))}
    c = compact(obj)
    assert len(c["retrieval_text"]) == 241 and "embedding" not in c
    assert c["rows"][-1] == "... (12 more)"
