"""Provenance contract: no unit leaves the system without its source
document, version, section, and pages — and answers resolve citations."""
import json

from policy_rag.answer import source_of
from policy_rag.config import Config
from policy_rag.llm import GuardedLLMClient
from policy_rag.orchestrator import harvest_units, run_research

ROW = {"unit_id": "22222222-2222-2222-2222-222222222222",
       "unit_type": "clause",
       "retrieval_text": "Retention is 7 years.",
       "context_header": "DP v2.0 › 1",
       "doc_slug": "data-protection", "doc_title": "Data Protection Policy",
       "version_label": "v2.0", "section_path": ["1"],
       "page_start": 3, "page_end": 3, "status": "active"}


def test_source_of_is_complete_and_structured():
    src = source_of(ROW)
    assert src == {"unit_id": ROW["unit_id"], "doc_slug": "data-protection",
                   "doc_title": "Data Protection Policy", "version": "v2.0",
                   "section_path": ["1"], "page_start": 3, "page_end": 3}


def test_harvest_carries_document_provenance_into_pool():
    pool = {}
    harvest_units({"nested": [ROW]}, pool)
    entry = pool[ROW["unit_id"]]
    assert entry["doc_slug"] == "data-protection"
    assert entry["doc_title"] == "Data Protection Policy"
    assert entry["version_label"] == "v2.0"
    assert entry["section_path"] == ["1"]


class _Backend:
    def __init__(self, replies): self.replies = list(replies)
    def complete(self, prompt, system=None): return self.replies.pop(0)


class _Storage:
    def __getattr__(self, name):
        return lambda *a, **kw: ([dict(ROW)] if name == "hybrid_search" else [])


def test_grounded_answer_resolves_citations_to_sources():
    uid = ROW["unit_id"]
    llm = GuardedLLMClient(Config(), _Backend([
        json.dumps({"action": "search", "args": {"query": "retention"}}),
        json.dumps({"action": "finish"}),
        f"Retention is 7 years [[{uid}]].",
    ]))
    res = run_research("retention?", _Storage(), llm, max_steps=3)
    assert res.answer.citations == [uid]
    assert len(res.answer.sources) == 1
    src = res.answer.sources[0]
    assert (src["doc_slug"], src["version"], src["page_start"]) == \
        ("data-protection", "v2.0", 3)
    # the synthesis prompt itself names the source document, not just an id
    synth_prompt = llm.backend.__dict__  # backend consumed all replies
    assert not llm.backend.replies


def test_evidence_formatting_names_source_document():
    from policy_rag.answer import format_evidence
    block = format_evidence([ROW])
    assert "Data Protection Policy" in block and "v2.0" in block
    assert "section 1" in block and "pages 3–3" in block
