"""Reference + Topic faces: cross-document linking and clustering."""
from policy_rag.embeddings import HashEmbedder
from policy_rag.linking import (build_definition_index, conflict_candidates,
                                extract_quantities, link_doc_references,
                                link_term_usages)
from policy_rag.models import EvidenceUnit, Provenance, UnitType
from policy_rag.topics import build_topics, same_topic_edges


def unit(text, doc="doc-a", utype=UnitType.CLAUSE, key=None, term=None):
    u = EvidenceUnit(
        unit_type=utype, source_text=text, ordinal=0,
        unit_key=key or f"{doc}:{abs(hash(text))}",
        provenance=Provenance(doc_slug=doc, doc_title=doc.replace("-", " ").title(),
                              version_label="v1", source_file_hash="h",
                              page_start=1, page_end=1),
        term=term)
    u.retrieval_text = text
    u.finalize_hashes()
    return u


def test_term_usage_links_cross_doc_only_and_capped():
    d = unit("Exposure means total amount at risk.", doc="credit-risk",
             utype=UnitType.DEFINITION, term="Exposure", key="def-exposure")
    uses = [unit(f"Exposure must be reported in case {i}.", doc="liquidity-policy")
            for i in range(5)]
    same_doc = unit("Exposure is capped.", doc="credit-risk")
    links = link_term_usages(uses + [same_doc, d],
                             build_definition_index([d]))
    assert all(l.link_type == "uses_term" for l in links)
    assert all(l.dst_unit_key == "def-exposure" for l in links)
    assert len(links) == 3  # capped per (term, doc); same-doc use excluded


def test_definition_index_skips_generic_terms():
    g = unit("Data means any information.", utype=UnitType.DEFINITION,
             term="Data")
    assert build_definition_index([g]) == {}


def test_doc_reference_links_by_title_and_code():
    src = unit("Retention follows the Records Management Policy and POL-042.",
               doc="data-protection")
    links = link_doc_references(
        [src],
        doc_titles={"records-management": "Records Management Policy",
                    "vendor-risk": "Vendor Risk Policy"},
        doc_codes={"POL-042": "vendor-risk"},
        summary_key_by_doc={"records-management": "sum-rm",
                            "vendor-risk": "sum-vr"})
    by_dst = {l.dst_unit_key: l for l in links}
    assert set(by_dst) == {"sum-rm", "sum-vr"}
    assert "Records Management Policy" in by_dst["sum-rm"].evidence


def test_quantity_extraction_normalizes_units():
    q = extract_quantities("retain for 7 years, then 30 days; fee £1,500.50")
    assert (7.0, "year") in q and (30.0, "day") in q and (1500.5, "gbp") in q


def test_conflict_candidates_flag_divergent_quantities_across_docs():
    a = unit("Records shall be retained for 7 years.", doc="data-protection")
    b = unit("Customer records are retained for 5 years.",
             doc="records-management")
    c = unit("Retention applies to all records.", doc="records-management")
    links = conflict_candidates([a, b, c])
    assert len(links) == 1
    l = links[0]
    assert l.link_type == "potentially_conflicting"
    assert "7" in l.evidence and "5" in l.evidence and "year" in l.evidence


def test_no_conflict_within_same_document():
    a = unit("Retain for 7 years.", doc="d1")
    b = unit("Retain for 5 years.", doc="d1")
    assert conflict_candidates([a, b]) == []


def test_topics_cluster_cross_doc_and_label_deterministically():
    retention = [
        unit("Records retention period is seven years for customer data.",
             doc="data-protection"),
        unit("Retention of customer records lasts seven years minimum.",
             doc="records-management"),
        unit("Customer records retention schedule spans seven years.",
             doc="vendor-risk"),
    ]
    access = [
        unit("Access control requires multi factor authentication login.",
             doc="data-protection"),
        unit("Authentication access control mandates multi factor login.",
             doc="it-security"),
    ]
    topics = build_topics(retention + access, HashEmbedder(128),
                          distance_threshold=0.8, min_members=2)
    assert len(topics) == 2
    assert all(t.n_documents >= 2 for t in topics)
    assert all(t.summary_method == "medoid" for t in topics)  # zero LLM calls
    labels = " ".join(t.label for t in topics)
    assert "retention" in labels and ("access" in labels or
                                      "authentication" in labels)


def test_topic_summary_regeneration_gate_is_member_hash():
    members = [unit("Retention is seven years.", doc=f"d{i}") for i in range(3)]
    t1 = build_topics(members, HashEmbedder(64), distance_threshold=0.9)
    t2 = build_topics(list(reversed(members)), HashEmbedder(64),
                      distance_threshold=0.9)
    assert t1 and t2 and t1[0].member_hash == t2[0].member_hash  # order-free


def test_same_topic_edges_capped():
    members = [unit(f"Retention clause number {i} is seven years.",
                    doc=f"d{i % 2}") for i in range(12)]
    topics = build_topics(members, HashEmbedder(64), distance_threshold=0.9)
    assert topics
    edges = same_topic_edges(topics[0], sim_floor=0.0, max_edges=10)
    assert len(edges) == 10


def test_same_unit_different_subject_is_not_a_conflict():
    a = unit("Customers have 7 days to appeal a decision.", doc="d1")
    b = unit("The bank has 5 days to acknowledge receipt of a complaint.",
             doc="d2")
    assert conflict_candidates([a, b]) == []


def test_conflict_evidence_names_the_shared_context():
    a = unit("Customer records retention period is 7 years.", doc="d1")
    b = unit("Retention of customer records is 5 years.", doc="d2")
    links = conflict_candidates([a, b])
    assert len(links) == 1
    assert "re:" in links[0].evidence and "retention" in links[0].evidence


def test_large_corpus_uses_minibatch_kmeans_path():
    import time
    units_big = [unit(f"clause about {topic} obligations item {i} with "
                      f"{topic} controls and {topic} review",
                      doc=f"doc-{i % 50}")
                 for i, topic in enumerate(
                     ["retention", "access", "vendor", "liquidity",
                      "screening", "reporting", "encryption", "training"] * 400)]
    t0 = time.time()
    topics = build_topics(units_big, HashEmbedder(64))
    elapsed = time.time() - t0
    assert len(units_big) == 3200 and topics      # kmeans branch engaged
    assert elapsed < 30
    assert all(t.n_documents >= 2 for t in topics)
