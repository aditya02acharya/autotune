from policy_rag.tables import (RawTableFragment, derive_col_paths,
                               derive_row_paths, detect_header_rows,
                               extract_unit, iter_facts, parse_table,
                               resolve_grid, split_notes, stitch_fragments)

# Multi-level column header (merged 'Limit' spans two columns -> None),
# grouped rows ('Retail' fills down), units in headers, trailing note.
COMPLEX = [
    ["Segment", "Product",  "Limit (GBP)", None,        "Approval"],
    [None,      None,       "Standard",    "Maximum",   None],
    ["Retail",  "Secured",  "500,000",     "750,000",   "Branch Manager"],
    [None,      "Unsecured","250,000",     "400,000",   "Regional Credit Committee"],
    ["Corporate","Secured", "2,000,000",   "5,000,000", "CRO"],
    ["* Maximum limits exclude bridging loans.", None, None, None, None],
]


def make_table():
    return parse_table([RawTableFragment(page=4, rows=COMPLEX)],
                       table_key="table:2.1:1", section_path=["2", "2.1"],
                       caption="Table 1: Credit approval limits")


def test_multi_level_column_header_paths():
    t = make_table()
    assert t.n_header_rows == 2 and t.n_header_cols == 2
    assert t.col_paths[0] == ["Limit (GBP)", "Standard"]
    assert t.col_paths[1] == ["Limit (GBP)", "Maximum"]
    assert t.col_paths[2] == ["Approval"]          # vertical repetition collapsed


def test_grouped_rows_fill_down():
    t = make_table()
    assert t.row_paths[1] == ["Retail", "Unsecured"]   # 'Retail' inherited
    assert t.row_paths[2] == ["Corporate", "Secured"]


def test_unit_extraction_from_header():
    assert extract_unit("Limit (GBP)") == ("Limit", "GBP")
    assert extract_unit("Approval") == ("Approval", None)


def test_facts_carry_paths_values_and_units():
    t = make_table()
    facts = list(iter_facts(t))
    target = [f for f in facts
              if f[2] == ["Retail", "Unsecured"] and "Maximum" in f[3]]
    assert len(target) == 1
    _, _, row_path, col_path, value, unit = target[0]
    assert col_path == ["Limit", "Maximum"] and value == "400,000" and unit == "GBP"


def test_notes_split_from_body():
    body, notes = split_notes(COMPLEX)
    assert notes == ["* Maximum limits exclude bridging loans."]
    assert len(body) == 5


def test_pivot_invariance_of_facts():
    """A transposed table yields the same (path -> value) associations."""
    simple = [["Metric", "Retail", "Corporate"],
              ["Limit", "500", "2000"],
              ["Tenor", "5y", "10y"]]
    pivoted = [["Segment", "Limit", "Tenor"],
               ["Retail", "500", "5y"],
               ["Corporate", "2000", "10y"]]

    def fact_set(rows):
        t = parse_table([RawTableFragment(page=1, rows=rows)], "k", [])
        return {(frozenset(f[2] + f[3]), f[4]) for f in iter_facts(t)}

    assert fact_set(simple) == fact_set(pivoted)


def test_multipage_stitching_drops_repeated_headers():
    page1 = RawTableFragment(page=4, rows=[
        ["Segment", "Limit"], ["Retail", "500"], ["Corporate", "2000"]])
    page2 = RawTableFragment(page=5, rows=[
        ["Segment", "Limit"],            # repeated header
        ["SME", "800"], ["Sovereign", "9000"]])
    rows, n_pages = stitch_fragments([page1, page2])
    assert n_pages == 2
    t = parse_table([RawTableFragment(page=4, rows=rows[:1] + rows[1:])],
                    "k", [])
    # one header row total; four data rows; no duplicate 'Segment' row
    assert sum(1 for r in rows if r[0] == "Segment") == 1
    assert [r[0] for r in rows[1:]] == ["Retail", "Corporate", "SME", "Sovereign"]


def test_headerless_table_low_confidence_positional_columns():
    rows = [["500", "750"], ["250", "400"]]
    t = parse_table([RawTableFragment(page=1, rows=rows)], "k", [])
    assert t.n_header_rows == 0
    assert t.col_paths[0][0].startswith("col_")
    assert t.confidence < 0.7


def test_merged_cells_resolved_addressable():
    grid = resolve_grid([["A", None, "B"], [None, "x", None]])
    assert grid == [["A", "", "B"], ["", "x", ""]]
    assert all(len(r) == 3 for r in grid)
