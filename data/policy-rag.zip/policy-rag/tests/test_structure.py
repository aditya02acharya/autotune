from policy_rag.structure import extract_section_refs, parse_blocks

PAGES = [
    [
        "1 Introduction",
        "This policy sets out the credit approval framework.",
        "",
        "2 Approvals",
        "2.1 Standard Limits",
        "Standard limits apply to all retail products.",
        "",
        '"Exception" means any deviation from a standard credit limit.',
        "",
        "Exceptions are governed by:",
        "- the Regional Credit Committee",
        "- the Chief Risk Officer, where limits exceed thresholds in section 4.1",
    ],
    [
        "2.2 Exception Handling",
        "Exceptions to standard credit limits must be approved by the",
        "Regional Credit Committee before customer notification.",
        "",
        "Appendix A: Glossary",
        "Additional terms are defined here.",
    ],
]


def test_section_hierarchy_paths():
    blocks = parse_blocks(PAGES)
    by_text = {b.text: b for b in blocks}
    clause = by_text["Standard limits apply to all retail products."]
    assert clause.section_path == ["2", "2.1"]
    assert clause.section_titles == ["Approvals", "Standard Limits"]


def test_definition_extraction():
    blocks = parse_blocks(PAGES)
    defs = [b for b in blocks if b.kind == "definition"]
    assert len(defs) == 1 and defs[0].term == "Exception"


def test_list_block_keeps_stem_and_bullets_together():
    blocks = parse_blocks(PAGES)
    lists = [b for b in blocks if b.kind == "list_block"]
    assert len(lists) == 1
    assert "governed by" in lists[0].text          # lead-in preserved
    assert "Regional Credit Committee" in lists[0].text


def test_paragraph_continues_across_page_break():
    blocks = parse_blocks(PAGES)
    target = [b for b in blocks if "customer notification" in b.text]
    assert len(target) == 1
    assert target[0].section_path == ["2", "2.2"]
    assert target[0].page_start == 2


def test_appendix_detection():
    blocks = parse_blocks(PAGES)
    app = [b for b in blocks if b.kind == "appendix_item"]
    assert app and app[0].section_path == ["Appendix A"]


def test_cross_reference_extraction():
    refs = extract_section_refs(
        "thresholds in section 4.1 and under §2.2 apply")
    assert refs == ["4.1", "2.2"]


def test_toc_pages_skipped():
    toc = [["Contents", "1 Introduction .......... 2",
            "2 Approvals ............. 3", "2.1 Standard Limits ..... 3",
            "Appendix A .............. 5"]]
    blocks = parse_blocks(toc + PAGES)
    assert not any("........" in b.text for b in blocks)
