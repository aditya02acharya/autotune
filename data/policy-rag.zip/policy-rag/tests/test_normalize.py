from policy_rag.normalize import (collapse_whitespace, dehyphenate,
                                  is_meaningful, normalize_text,
                                  strip_page_furniture)


def test_collapse_whitespace_caps_newlines_and_spaces():
    out = collapse_whitespace("a    b\t\tc\n\n\n\n\nd")
    assert out == "a b c\n\nd"


def test_dehyphenation_joins_linebreak_hyphens():
    assert dehyphenate("customer noti-\nfication") == "customer notification"
    # real hyphens not at line breaks survive
    assert dehyphenate("risk-based approach") == "risk-based approach"


def test_normalize_fixes_ligatures():
    assert normalize_text("o\ufb03cer") == "officer"


def test_meaningfulness_rejects_empty_whitespace_and_noise():
    assert not is_meaningful("")
    assert not is_meaningful("   \n\n  \t ")
    assert not is_meaningful("___ ... --- | | |")          # layout noise
    assert is_meaningful("Exceptions must be approved.")


def test_repeated_headers_and_page_numbers_stripped():
    pages = [
        ["Credit Risk Policy — Confidential", "Real content A", "Page 1 of 3"],
        ["Credit Risk Policy — Confidential", "Real content B", "Page 2 of 3"],
        ["Credit Risk Policy — Confidential", "Real content C", "3"],
    ]
    cleaned = strip_page_furniture(pages)
    flat = [ln for p in cleaned for ln in p]
    assert flat == ["Real content A", "Real content B", "Real content C"]
