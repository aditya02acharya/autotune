# Policy RAG System — Design

A production RAG system for policy documents on PostgreSQL + pgvector, with
structure-aware atomic units, table semantics, versioning, PII handling, and
conservative LLM usage.

---

## 1. Problem analysis

### 1.1 Why naive chunking fails here

The query taxonomy is the design driver. Users ask for *structural* things:
a specific clause, a section, a table cell, a definition, a diff between
versions. Fixed-size chunks:

- cut across clause boundaries, so "section 4.2" has no addressable object;
- destroy table semantics (a 512-token window through a pivoted table is noise);
- have no stable identity, so version diffing degenerates to fuzzy text diff;
- lose context ("Must be approved by the committee." — which committee? which
  policy? under what conditions?).

So the system is **structure-first**: parse the document into its own semantic
units, and make those units the retrieval, citation, and versioning currency.

### 1.2 Edge cases that shape the design

| Edge case | Consequence for design |
|---|---|
| TOC may or may not exist | Section detection must work from numbering/heading heuristics, with TOC used only as a cross-check |
| Multi-page tables with repeated headers | Table stitching by header signature; header-row dedup |
| Multi-level / missing headers | Header *forest* model + confidence score; low confidence → quarantine, optional LLM assist |
| Pivoted tables | Orientation-neutral fact model `(row_path, col_path, value)` |
| Merged cells | Grid resolution: expand spans before header/path derivation |
| Grouped rows (blank inherit cells) | Fill-down on row-header columns |
| Cross-references ("see §3.1") | Preserved verbatim in unit text + extracted into `refs` metadata |
| Repeated page headers/footers | Detected as lines repeating across ≥60% of pages; stripped |
| Hyphenation at line breaks | Dehyphenation in normalization |
| Footnotes | Own unit type, linked to anchor unit |
| PII inside clauses | Unit-level PII flags; masked retrieval text; raw text in controlled column |
| Re-ingestion of unchanged doc | File-hash short circuit; unit-level structural-key diff |

---

## 2. The atomic unit: Evidence Unit (EU)

An **Evidence Unit** is a typed, contextualized, provenance-bearing node.

```
EvidenceUnit
├─ identity
│   ├─ unit_id            surrogate key (uuid)
│   ├─ unit_key           STRUCTURAL identity, stable across versions:
│   │                     sha256(doc_id | unit_type | section_path | table_key | ordinal)
│   ├─ text_hash          sha256(normalized source_text) — change detection
│   └─ unit_type          clause | definition | list_block | heading |
│                         table | table_region | table_row | table_fact |
│                         table_notes | footnote | appendix_item | doc_summary
├─ content
│   ├─ source_text        exact normalized wording (controlled access)
│   ├─ retrieval_text     context header + body (what gets embedded/indexed;
│   │                     PII-masked per policy)
│   └─ context_header     deterministic breadcrumb, e.g.
│                         "Credit Risk Approval Policy v3.1 › 4. Approvals ›
│                          4.2 Exception Handling"
├─ provenance
│   ├─ doc_id, doc_version_id, source_file_hash
│   ├─ page_start, page_end
│   ├─ section_path       ["4", "4.2"] + titles
│   ├─ table_id, row_idx, col_idx (table units)
│   └─ ordinal            reading order within version
├─ hierarchy
│   ├─ parent_unit_id     (clause → section heading → doc; fact → row → table)
│   └─ prev/next via ordinal
├─ table semantics (table units only)
│   ├─ row_header_path    ["Retail", "Unsecured"]
│   ├─ col_header_path    ["Limit", "GBP"]
│   ├─ value, unit_of_measure, notes_ref
├─ pii
│   ├─ contains_pii, pii_types[], masking_applied
├─ lifecycle
│   ├─ status: active | superseded | quarantined
│   ├─ parser_version, ingestion_run_id, created_at, superseded_at
└─ embedding (pgvector) over retrieval_text — for embeddable types
```

**Independently understandable** is achieved deterministically, not with an
LLM: `retrieval_text = context_header + "\n" + body`, where for table rows the
body is a serialization like
`"Retail › Unsecured | Limit (GBP): 250,000 | Approval: Regional Credit Committee | note: excludes bridging loans"`.
This is contextual retrieval without per-chunk LLM calls.

**Granularity policy** (small enough / large enough):

- Prose: one clause/paragraph per unit; sibling bullets stay together as one
  `list_block` with their lead-in sentence (bullets without their stem are
  meaningless). Oversized blocks (> ~1,800 chars) split at sentence boundaries
  *within* the unit as sub-units sharing the same `unit_key` prefix.
- Definitions: one term per unit.
- Tables: stored at multiple grains simultaneously — `table` (whole, with
  caption/notes), `table_row` (one per logical row), `table_fact` (one per
  data cell, generated when the table has resolvable header paths). Facts are
  cheap rows in Postgres, not embedded by default (rows are embedded; facts are
  retrieved via SQL by header-path match or via their parent row).

---

## 3. PostgreSQL / pgvector data model

See `schema.sql`. Summary:

- `documents` — logical document (slug, title, classification).
- `document_versions` — one per ingested file version: `source_file_hash`,
  declared version label, effective date, `is_current`.
- `ingestion_runs` — run metadata, parser version, metrics JSONB, status.
- `evidence_units` — the EU table. Columns for everything in §2;
  `embedding vector(D)`; `tsv tsvector` generated column for FTS;
  GIN index on `tsv`, GIN trgm index on `source_text` for exact-ish term lookup,
  HNSW index on `embedding`, B-tree on `(doc_version_id, ordinal)`,
  `(unit_key, status)`, GIN on `section_path`.
- `tables_meta` — one row per logical (stitched) table: caption, page range,
  shape, header structure JSONB, parse confidence, notes.
- `unit_links` — typed edges: `footnote_of`, `references_section`,
  `continues` (multi-page), `defines_term_used_in`.
- `llm_calls` — audit log: purpose, model, token/cost estimates,
  `pii_present`, `prompt_stored` (off by default).
- `pii_findings` — per-unit findings: type, masked placeholder, char span
  (span into `source_text`, never the raw value itself).
- `access_audit` — who retrieved which PII-bearing units, when, why.

FTS + trigram + pgvector covers keyword, fuzzy-exact, and semantic retrieval
with zero extra infrastructure.

---

## 4. Ingestion pipeline

```
PDF ─▶ 1 extract      pdfplumber: words+lines+tables per page, with bboxes
     ─▶ 2 de-noise    strip repeated headers/footers, page numbers,
                      dehyphenate, fix ligatures, collapse whitespace
     ─▶ 3 structure   heading detection (numbering regex + layout cues)
                      → section tree; TOC (if present) as cross-check;
                      classify blocks: paragraph / list / definition /
                      footnote / appendix
     ─▶ 4 tables      grid extraction → merged-cell resolution →
                      multi-page stitching → header forest → row/col paths →
                      facts; confidence score
     ─▶ 5 PII         detect, classify, record findings; produce masked text
     ─▶ 6 unitize     build EUs; context headers; retrieval_text;
                      hashes; hierarchy links
     ─▶ 7 QC gates    validate; reject/quarantine; compute metrics
     ─▶ 8 diff        structural-key diff vs current version (see §6)
     ─▶ 9 embed       only NEW/CHANGED embeddable units, masked text per policy
     ─▶ 10 persist    transactional write; flip version pointers; store metrics
```

Steps 1–8 are fully deterministic. The only optional LLM touchpoint in
ingestion is step 4 for tables whose header confidence < threshold — and even
then the default is *quarantine for human review*; LLM header inference is an
opt-in mode that sends only the (masked) header region, never the data body.

---

## 5. Table-ingestion strategy

1. **Grid resolution.** Expand merged cells (value copied into each covered
   cell, with `is_merged_copy` flag) so every (row, col) is addressable.
2. **Multi-page stitching.** A table fragment on page *n+1* is a continuation
   of one on page *n* when column count matches and either (a) its first row(s)
   equal the previous header signature (repeated header → dropped), or (b) it
   has no header-like leading row and column x-positions align. Stitched
   fragments share one `table_id`; page range recorded.
3. **Header detection.** Leading rows are header candidates when they are
   non-numeric-dominant, short-celled, and/or span-heavy. Multi-row headers →
   per-column **header path** by forward-filling spans then joining levels
   top-down (`["Limit","GBP"]`). Leading columns are row-header candidates by
   the symmetric test; grouped rows use fill-down. If no header row is
   detected, columns get positional labels (`col_1…`) and confidence drops.
4. **Fact derivation.** For each data cell with resolvable paths:
   `(row_header_path, col_header_path, raw value, parsed unit, parsed
   condition text)`. Units are pulled from header text (`(GBP)`, `%`, `days`)
   or cell suffixes. Pivot-invariant by construction.
5. **Notes & caveats.** Rows/blocks below the grid matching note markers
   (`*`, `†`, `Note:`, superscripts) become a `table_notes` unit linked to the
   table; cell-level markers link facts → notes.
6. **Confidence & quarantine.** Score from: header detection certainty, ragged
   rows, empty ratio, stitching ambiguity. Below threshold → table EUs created
   with `status=quarantined` (not retrievable) and counted in metrics.

---

### 5b. Table-fact generation policy

Cell-level facts are powerful but unbounded: a 60×40 table is 2,400 fact
units. Explicit thresholds (`TableFactPolicy`): rows are ALWAYS stored and
embedded; empty cells never produce facts; facts are skipped when parse
confidence < 0.7 (header paths unreliable → facts would be wrong, not just
costly) or when rows×cols exceeds `max_fact_cells` (default 400). Skips are
recorded as `fact_skip_reason` on `tables_meta` and in run metrics — a
silent absence of facts is itself a bug. Facts are unembedded by default
(FTS/trgm still finds them; captions and rows carry the semantic load);
small (≤80 cells), high-confidence (≥0.85) tables opt their facts into
embedding for cell-level semantic retrieval.

## 6. Versioning & incremental updates

- A new file's `source_file_hash` equal to the current version → **no-op**
  (run recorded, nothing rewritten).
- Otherwise create a new `document_version` and diff EUs against the current
  version by `unit_key`:
  - same `unit_key` + same `text_hash` → **carry forward**: the existing row's
    `doc_version_id` membership is extended via a `version_membership` link
    (no rewrite, embedding reused);
  - same `unit_key`, different `text_hash` → old row `superseded`, new row
    inserted (new embedding);
  - new `unit_key` → inserted;
  - missing `unit_key` → `superseded` with `superseded_at`.
- Retrieval defaults to `status='active'` on the current version; historical
  retrieval filters by `doc_version_id`; **version diff** is a SQL join on
  `unit_key` across two versions, classified added/removed/changed, with
  changed pairs optionally word-diffed for display.
- Ordinal drift (a clause moves) does not break identity as long as section
  path holds; section renumbering *does* change keys, which is correct — a
  renumbered clause is a different citable object — and the diff surfaces it
  as remove+add with a similarity hint (`text_hash` match across keys).

---

### 6b. Dual identity: structural key + lineage matching

The structural `unit_key` alone is brittle — and worse than brittle: when a
clause moves out of a section, its ordinal slot is often reused by different
content, so pure key-matching *misattributes* edits ("clause X was reworded"
when in fact X moved and a newcomer took its slot). Diffing therefore uses
two identities:

- **structural**: unit_key + text_hash (where it sits, exact content)
- **lineage**: content similarity (64-bit SimHash candidate pairing + token
  Jaccard/containment) + nearby structure (unit_type, parent heading
  titles). Computed at diff time from text — per-document residual sets
  after exact matching are small, so no stored column is needed.

Classification (resolution order matters: same-key matches with dissimilar
content are *rejected* as ordinal collisions and deferred to lineage;
split/merge containment resolves before the greedy fuzzy 1-1 matcher):

| class | meaning |
|---|---|
| unchanged | carried forward, no rewrite/re-embed |
| wording_changed | same key, similar content, new hash |
| renumbered | identical content, new key, same parent heading titles |
| moved | identical content, new key, different parent |
| moved_and_changed | similar content + structure under a new key |
| split / merged | containment: one→many / many→one |
| content_migrated | partial split: a unit kept its slot but part of its content moved into an added unit |
| added / removed | the honest residue |

Every traced pair is persisted as a `lineage_of` edge (new unit →
superseded predecessor, evidence = classification), so "what happened to
clause 4.2 across versions" is a graph walk. `compare_versions` returns the
full classified diff with human-readable locations.

## 7. PII & sensitive-data strategy

- **Detection** (deterministic first): regex + checksum validators (Luhn for
  card-like numbers, UK NI format, IBAN mod-97, email, phone, DOB patterns,
  configurable employee/customer-ID patterns). An optional NER hook (e.g.
  Presidio) plugs in behind the same interface for names/addresses.
- **Storage split**: `source_text` (raw, controlled) vs `retrieval_text`
  (masked per policy). Findings store *type + span + placeholder*, never the
  raw value in a second place.
- **Masking**: stable typed placeholders per document (`[EMAIL_1]`,
  `[ACCOUNT_3]`) so coreference within a unit survives masking.
- **Embeddings**: generated from masked text by default;
  `embedding_source ∈ {raw, masked, redacted}` recorded per unit. Config can
  whitelist PII types that may remain (e.g. role titles).
- **Logs**: structured logging emits IDs, hashes, counts only. A
  `log_text_debug=true` flag (off by default) is required for any text in logs.
- **LLM calls**: every call goes through `GuardedLLMClient`, which (a) applies
  the masking policy, (b) refuses or marks `requires_elevation` if masking
  would gut the content and policy forbids raw PII, (c) writes an `llm_calls`
  audit row (purpose, model, token & cost estimate, `pii_present`), (d) does
  not store the prompt unless explicitly enabled.
- **Retrieval-time access control**: every search accepts a caller principal;
  units with `contains_pii` are filtered or returned masked unless the
  principal has the `pii_read` scope; access is written to `access_audit`.
- **Answers**: synthesis runs over masked evidence unless the caller is
  authorized *and* the question requires the raw value.

---

## 8. Retrieval strategy

All strategies operate on EUs and are composable:

| Strategy | Mechanism |
|---|---|
| Semantic | pgvector cosine over `retrieval_text` embeddings |
| Keyword | Postgres FTS (`websearch_to_tsquery`) over `tsv` |
| Exact term / clause | `pg_trgm` similarity + exact `section_path` / term match |
| Hybrid | Reciprocal Rank Fusion of semantic + FTS in one SQL CTE |
| Section lookup | `section_path` prefix match, ordered by `ordinal` |
| Definition lookup | `unit_type='definition' AND term ~* query` |
| Table-aware | filter `unit_type IN (table, table_row, table_fact)`; facts queried by header-path containment (`row_path @> ...`) |
| Row / cell | direct SQL on table coordinates or header paths |
| Doc-level summary | structure walk: headings + first clause per section + doc_summary units |
| Cross-document | same hybrid query fanned across doc filters, grouped by doc in results |
| Version diff | `unit_key` join across versions (§6) |
| Metadata-filtered | any of the above + filters (doc, version, section prefix, type, date, PII, status) |

**Neighbor expansion**: any hit can be expanded via ordinal ±k and
parent/child links, so precision-first retrieval never strands the agent
without context.

**Grounding discipline**: the answerer receives *only* retrieved EUs with
their IDs; the synthesis prompt requires citing `unit_id`s; an answer with
zero citations or citations not in the retrieved set is rejected and the
system returns "insufficient evidence" with what *was* found. Staleness,
quarantine, and version flags propagate into the answer's limitations field.

---

## 8b. The corpus as a faceted cube

A requirements gap in the original design, surfaced by review: cross-document
retrieval existed only as a *doc filter* on search — the degenerate form.
Policy corpora are linked: documents cite each other, share defined terms,
treat the same topics, and sometimes disagree.

The model: evidence units are immutable cell contents, and the corpus is
indexed along independent **faces** — orthogonal projections over the same
units that share nothing but unit identity. Each face is independently
navigable; a query enters through any face and pivots through the others.
No face duplicates text: faces are edge tables and summary layers.

| Face | What it indexes | Implementation |
|---|---|---|
| **Structure** | doc › section › unit hierarchy | section_path, parent links, outline (§5) |
| **Time** | versions, diffs, carry-forward | unit_key diffing, version_membership (§6) |
| **Topic** | cross-document themes | `topics` + `topic_membership` (below) |
| **Reference** | typed edges between units | `unit_links`, extended cross-doc (below) |
| **Obligation** | who must do what, by when | *deferred* — designed for, not built |

**Topic face (RAPTOR, adapted).** Full RAPTOR builds a recursive LLM-summary
tree over chunks. Within a document that mostly rediscovers, at LLM cost, the
human-authored section hierarchy we already ingest — and per-node
summarisation violates the conservative-LLM constraint. What survives is the
layer that exists nowhere in the documents: *cross-document* topics.
One flat agglomerative clustering (cosine, distance-threshold so corpus
growth adds topics rather than diluting them) over active embeddable units;
single-document topics are dropped (the Structure face covers them). Topic
summaries are **extractive medoids by default — zero LLM calls**; optional
guarded-LLM summaries are gated on `member_hash` (sha256 of sorted member
keys) so a summary regenerates only when membership actually changes, making
LLM cost O(changed topics) per refresh, every call audited.

**Reference face (cross-document edges).** Deterministic linkers — no LLM
judgement is baked into the graph:

| link_type | Derivation |
|---|---|
| `uses_term` | unit in doc B contains a term defined in doc A (lexical, longest-term-first, generic-term stoplist, capped per term×doc) |
| `references_document` | explicit title ("see the Records Management Policy") or code (POL-123) mention; edge targets the cited doc's summary unit |
| `same_topic` | topic co-membership above a similarity floor, edge-capped |
| `potentially_conflicting` | same topic, **different documents**, divergent quantities with the same unit of measure AND overlapping local context — "7 days to appeal" vs "5 days to acknowledge" share a unit but not a subject and are NOT flagged; the quantity expression and measure words are excised from context so same-unit can't satisfy its own test. Evidence names the shared context ("re: retention, records") so reviewers see why the pair fired. **Flagged for human review, never adjudicated** |

Faces are rebuilt by `storage.rebuild_corpus_faces()` after ingestion runs —
a corpus-level batch step, separate from per-document ingestion, idempotent.

---

## 9. MCP tools: three, layered

The surface previously exposed a tool per face per grain (sixteen tools);
tool *selection* had become the consumer's hardest problem. The fix is
layering, not deletion — every primitive survives as an internal **action**:

| Tool | LLM? | Purpose |
|---|---|---|
| `research_policy(question, max_steps)` | yes | **agent-as-a-tool**: a guarded LLM orchestrates the action registry in a bounded loop, then synthesizes a citation-enforced answer; returns answer + full trajectory |
| `find_evidence(query, mode, filters, expand_top)` | no | deterministic search; `expand_top=N` attaches full context for the N best hits |
| `navigate(action, params)` | no | one dispatcher over all deterministic primitives |

`navigate` actions (the former tools): `documents`, `overview`, `section`,
`expand`, `table`, `fact`, `topics`, `topic_members`, `related`,
`conflicts`, `versions`, `search`. Unknown action or bad params return the
catalog/usage instead of erroring — self-describing for agent callers.

**Orchestrator contract** (`orchestrator.py`):
- ≤ `max_steps` + 1 LLM calls per question; every call through
  `GuardedLLMClient` (PII-guarded, audited) with `purpose=
  'research_orchestration'` — the conservative-LLM budget is per-question
  and explicit.
- Per step the LLM emits one JSON action; results are harvested into an
  evidence pool (anything with `unit_id` + `retrieval_text`, however
  nested) and compacted (text truncated, embeddings stripped) before
  re-entering context.
- Malformed JSON / unknown actions / bad args become recoverable error
  observations, never crashes; the step cap forces synthesis from whatever
  evidence exists; zero evidence short-circuits to "insufficient" *without*
  an LLM call.
- Final synthesis reuses §11's citation enforcement — the orchestrator
  cannot launder unsupported claims — and the **complete trajectory**
  (actions, args, compacted observations) is returned to the caller.
  Orchestration must not hide the hard parts of the task.

**Provenance contract (enforced, not aspirational).** All unit-returning
SQL reads from the `evidence_units_v` view, which joins documents and
versions — a unit physically cannot leave storage without `doc_slug`,
`doc_title`, `version_label` (current; `version_introduced` also exposed for
carried-forward units), `section_path`, and pages. MCP hits carry a
structured `source` block; `GroundedAnswer` includes `sources`: every
citation resolved to {unit_id, doc, title, version, section, pages} so
answers are self-contained — consumers never need follow-up `trace_citation`
calls to know what an answer rests on. Evidence shown to the synthesis LLM
is labelled with document + version + section, not just unit ids. Pinned by
tests/test_provenance.py and a live per-path audit.

---

## 10. API contracts

Service endpoints (FastAPI-shaped; MCP tools mirror these):

- `POST /ingest` `{file, doc_slug, version_label?, effective_date?}` →
  `{run_id, status, metrics, quarantined: [...]}`
- `POST /search` → `{hits: [EvidenceHit], strategy_trace}`
- `POST /answer` `{question, filters?, principal}` →
  `{answer, citations: [unit_id], confidence, limitations,
    used_llm, pii_accessed, versions_used, retrieval_trace}`
- `GET /documents`, `GET /documents/{doc}/versions`
- `GET /units/{unit_id}` (provenance + lineage)
- `GET /runs/{run_id}/metrics`

`EvidenceHit = {unit_id, unit_type, retrieval_text, context_header,
provenance{doc, version, pages, section_path, table?}, score, status,
contains_pii}`.

---

## 11–12. Quality metrics, gates, failure behaviour

Metrics (persisted per run, JSONB + flat columns): all counts and size
percentiles listed in the spec — pages, units by type, min/max/avg/p50/p95
sizes, empty/whitespace/noise counts, provenance-missing counts, table
context-missing counts, duplicates, orphans, failed checks, low-confidence
table parses, LLM call count and cost.

**Hard-fail gates** (run aborts, nothing persisted): any empty or
whitespace-only unit, unit missing doc/version identity, broken parent link,
missing embedding for an active embeddable unit, duplicate `unit_key` within
a version.

**Quarantine gates** (unit persisted as `quarantined`, excluded from
retrieval, surfaced in run report): layout-noise units, excessive-whitespace
units, table rows missing row/col context, low-confidence table parses,
units missing page provenance without justification, suspected
repeated-header duplicates.

A run report lists every gate violation with unit identifiers so a human can
review, fix the parser or the document, and re-ingest.

---

## 13. Test plan

See `tests/`. Pure-logic tests (run anywhere): normalization, whitespace and
empty-unit prevention, dehyphenation, header/footer stripping, section
hierarchy, clause/list/definition extraction, table grid resolution,
multi-row headers, row grouping fill-down, pivot-fact invariance, multi-page
stitching + repeated-header dedup, note linkage, context-header construction,
PII detection/masking/log-safety, guarded-LLM policy, quality gates, version
diff (unchanged / changed / added / deleted / renumbered). DB-integration
tests (require Postgres, marked `@pytest.mark.db`): persistence, hybrid
search SQL, RRF ordering, version pointer flips, access-control filters,
citation tracing.

---

## 15. Example retrieval flows

**A. "What's the approval threshold for unsecured retail lending?"**
1. `search_evidence(q, mode=hybrid, filters={types:[table_row, clause]})`
2. Top hit: table_row in *Credit Risk Approval Policy v3.1 §4.1, Table 2*.
3. `get_table_fact(table_id, row_path=["Retail","Unsecured"], col_path=["Limit","GBP"])` → value 250,000, note †: "excludes bridging loans".
4. Answer cites the fact unit + note unit, includes units (GBP) and caveat.

**B. "What changed in the Data Retention Policy between v2 and v3?"**
1. `compare_versions("data-retention", "v2", "v3")` → 2 changed, 1 added.
2. `get_neighbors` on changed units for display context.
3. Answer lists each change with section path and both versions' wording, cites both unit versions.

**C. "Do the Credit Policy and the Lending Standards conflict on exception sign-off?"**
1. `search_evidence(q, filters={docs:[a,b]})` → per-doc evidence.
2. `get_definition("exception", doc=each)` to check term alignment.
3. Answer attributes each claim to its document; states the conflict (Committee vs CRO) explicitly; notes doc B has no comparable clause for sub-threshold cases.

## 16. Example ingestion metrics

See `examples/example_metrics.json`.

## 17. Production-readiness checklist

- [ ] Postgres ≥15 with pgvector ≥0.7, pg_trgm; HNSW params tuned to corpus size
- [ ] Migrations under version control (schema.sql → Alembic)
- [ ] Embedding model pinned + dimension recorded; re-embed plan on model change (per-unit `embedding_model` column)
- [ ] Parser version bump policy: bump → optional full re-unitize behind diff
- [ ] Quality-gate thresholds reviewed against a golden corpus; CI runs golden-corpus ingestion and asserts metrics
- [ ] PII config reviewed by data-protection owner; `allow_raw_pii_to_llm=false` in prod
- [ ] LLM budget alerts on `llm_calls` cost aggregates
- [ ] Structured logs (no text), traces around ingest stages and retrieval
- [ ] Access-control principals integrated with IdP; `access_audit` retention set
- [ ] Backups + PITR; `source_text` column under column-level encryption if required
- [ ] Load test: hybrid search p95 latency target with HNSW `ef_search` tuned
- [ ] Quarantine review workflow (UI or report) staffed
