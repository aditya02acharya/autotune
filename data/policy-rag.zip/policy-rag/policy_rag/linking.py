"""Cross-document linking: the Reference face of the corpus.

Evidence units are the single source of truth; this module derives typed
edges *between* them across document boundaries. Every linker here is
deterministic (lexical / numeric) — no LLM judgement is embedded in the
graph. The one judgement-shaped output, `potentially_conflicting`, is
explicitly a *candidate for human review*: same topic, different documents,
diverging quantities. The system surfaces the tension; it never resolves it.

Link types produced:
- uses_term            clause in doc B uses a term defined in doc A
- references_document  explicit mention of another policy by title or code
- potentially_conflicting  divergent quantities on the same topic across docs
  (same_topic edges are derived from the Topic face in topics.py)
"""
from __future__ import annotations

import re
from collections import defaultdict

from pydantic import BaseModel

from .models import EvidenceUnit, UnitType

# Generic terms that are defined in many policies but too common to link on.
_TERM_STOPLIST = {"policy", "document", "data", "information", "risk",
                  "process", "system", "staff", "employee", "customer"}

_POLICY_CODE_RE = re.compile(r"\b(?:POL|STD|PRC|GDL)-\d{2,6}\b")
_QUANTITY_RE = re.compile(
    r"(?<![\w.])(\d{1,3}(?:,\d{3})*(?:\.\d+)?)\s*"
    r"(%|percent|days?|months?|years?|hours?|GBP|EUR|USD)",
    re.IGNORECASE)
_CURRENCY_PREFIX_RE = re.compile(
    r"([£€$])\s?(\d{1,3}(?:,\d{3})*(?:\.\d+)?)")


class CrossDocLink(BaseModel):
    src_unit_key: str
    dst_unit_key: str
    link_type: str          # uses_term | references_document | potentially_conflicting
    evidence: str           # matched phrase / diverging values


def _doc_of(u: EvidenceUnit) -> str:
    return u.provenance.doc_slug


_ABBR_RE = re.compile(r"\b([A-Z][A-Za-z&/\- ]{3,60}?)\s*\(\s*([A-Z]{2,8})\s*\)")


def _is_abbreviation(term: str) -> bool:
    return term.isupper() and 2 <= len(term) <= 8


def _norm_def(text: str) -> str:
    return re.sub(r"\s+", " ", text.strip().lower())


def build_definition_index(units: list[EvidenceUnit]
                           ) -> dict[str, list[EvidenceUnit]]:
    """term (lowercased) -> ALL defining units across the corpus.

    With hundreds of policies the same term — especially the same
    abbreviation ('DPA' = Data Processing Agreement in one policy, Data
    Protection Act in another) — is defined repeatedly and differently.
    A flat term->unit map silently loses every collision; the consumer of
    this index must resolve scope explicitly (see link_term_usages)."""
    index: dict[str, list[EvidenceUnit]] = defaultdict(list)
    for u in units:
        if u.unit_type == UnitType.DEFINITION and u.term:
            term = u.term.strip().lower()
            min_len = 2 if _is_abbreviation(u.term.strip()) else 4
            if len(term) >= min_len and term not in _TERM_STOPLIST:
                index[term].append(u)
    return dict(index)


def build_abbreviation_table(units: list[EvidenceUnit]
                             ) -> dict[str, dict[str, str]]:
    """doc_slug -> {ABBR: normalized expansion}, from in-text patterns like
    'Data Processing Agreement (DPA)'. Each document carries its own
    expansions; an abbreviation is only meaningful within a document's
    scope unless the whole corpus agrees on it."""
    table: dict[str, dict[str, str]] = defaultdict(dict)
    for u in units:
        for m in _ABBR_RE.finditer(u.source_text):
            expansion, abbr = m.group(1).strip(), m.group(2)
            letters = "".join(w[0] for w in expansion.split() if w).upper()
            if letters.endswith(abbr) or letters == abbr:  # plausible match
                table[_doc_of(u)].setdefault(abbr, _norm_def(expansion))
    return dict(table)


def divergent_definitions(index: dict[str, list[EvidenceUnit]]
                          ) -> list[CrossDocLink]:
    """divergent_definition edges: the same term defined with materially
    different text in different documents. In a large estate this is one of
    the highest-value findings — flagged for review, never adjudicated."""
    links: list[CrossDocLink] = []
    for term, defs in index.items():
        by_doc: dict[str, EvidenceUnit] = {}
        for d in defs:
            by_doc.setdefault(_doc_of(d), d)
        docs = sorted(by_doc)
        for i, da in enumerate(docs):
            for db in docs[i + 1:]:
                a, b = by_doc[da], by_doc[db]
                if _norm_def(a.source_text) != _norm_def(b.source_text):
                    links.append(CrossDocLink(
                        src_unit_key=a.unit_key, dst_unit_key=b.unit_key,
                        link_type="divergent_definition",
                        evidence=f"'{a.term}' defined differently in "
                                 f"{da} and {db}"))
    return links


def _resolve_definition(term: str, using_doc: str,
                        defs: list[EvidenceUnit],
                        abbrs: dict[str, dict[str, str]]
                        ) -> EvidenceUnit | None:
    """Scope rules for 'which definition does this usage mean':
    1. The using document's own definition wins -> no cross-doc link.
    2. Bare abbreviations are linked only if unambiguous: either the using
       doc's own abbreviation table expands them to match a definition's
       text, or the entire corpus has exactly one (textually consistent)
       definition for them.
    3. Multi-word terms: link if all foreign definitions are textually
       identical; otherwise the term is contested -> no usage link
       (divergent_definitions flags the contest itself)."""
    if any(_doc_of(d) == using_doc for d in defs):
        return None                                # rule 1
    norm_texts = {_norm_def(d.source_text) for d in defs}
    if _is_abbreviation(term.upper()) or _is_abbreviation(
            defs[0].term.strip() if defs[0].term else ""):
        local = abbrs.get(using_doc, {}).get(term.upper())
        if local:
            matches = [d for d in defs
                       if local in _norm_def(d.source_text)
                       or _norm_def(d.term or "") == local]
            return matches[0] if matches else None # rule 2a
        if len(norm_texts) == 1:
            return defs[0]                         # rule 2b
        return None                                # ambiguous abbreviation
    if len(norm_texts) == 1:
        return defs[0]                             # rule 3
    return None


def link_term_usages(units: list[EvidenceUnit],
                     definitions: dict[str, list[EvidenceUnit]],
                     abbreviations: dict[str, dict[str, str]] | None = None,
                     max_links_per_term_doc: int = 3) -> list[CrossDocLink]:
    """uses_term edges: a unit in doc B contains a term defined elsewhere,
    resolved through scope rules (see _resolve_definition). Capped per
    (term, document) so a pervasive term doesn't explode the graph."""
    if not definitions:
        return []
    abbreviations = abbreviations or {}
    terms = sorted(definitions, key=len, reverse=True)
    pattern = re.compile(
        r"\b(" + "|".join(re.escape(t) for t in terms) + r")\b",
        re.IGNORECASE)
    links: list[CrossDocLink] = []
    per_term_doc: dict[tuple[str, str], int] = defaultdict(int)
    for u in units:
        if u.unit_type in (UnitType.DEFINITION, UnitType.HEADING,
                           UnitType.DOC_SUMMARY):
            continue
        seen_terms = {m.group(1).lower()
                      for m in pattern.finditer(u.source_text)}
        for term in seen_terms:
            d = _resolve_definition(term, _doc_of(u), definitions[term],
                                    abbreviations)
            if d is None:
                continue
            key = (term, _doc_of(u))
            if per_term_doc[key] >= max_links_per_term_doc:
                continue
            per_term_doc[key] += 1
            links.append(CrossDocLink(
                src_unit_key=u.unit_key, dst_unit_key=d.unit_key,
                link_type="uses_term",
                evidence=f"uses '{d.term}' defined in {_doc_of(d)}"))
    return links


def link_doc_references(units: list[EvidenceUnit],
                        doc_titles: dict[str, str],
                        doc_codes: dict[str, str] | None = None,
                        summary_key_by_doc: dict[str, str] | None = None
                        ) -> list[CrossDocLink]:
    """references_document edges: explicit mention of another policy by
    title ('see the Data Protection Policy') or code ('POL-123').

    Targets the referenced document's doc_summary unit so the edge lands on
    a stable, retrievable anchor."""
    doc_codes = doc_codes or {}
    summary_key_by_doc = summary_key_by_doc or {}
    by_title = {title.lower(): slug for slug, title in doc_titles.items()}
    title_pattern = re.compile(
        r"(" + "|".join(re.escape(t) for t in
                        sorted(by_title, key=len, reverse=True)) + r")",
        re.IGNORECASE) if by_title else None
    links: list[CrossDocLink] = []
    for u in units:
        if u.unit_type in (UnitType.HEADING, UnitType.DOC_SUMMARY):
            continue
        targets: dict[str, str] = {}  # slug -> matched phrase
        if title_pattern:
            for m in title_pattern.finditer(u.source_text):
                slug = by_title[m.group(1).lower()]
                if slug != _doc_of(u):
                    targets.setdefault(slug, m.group(1))
        for m in _POLICY_CODE_RE.finditer(u.source_text):
            slug = doc_codes.get(m.group(0))
            if slug and slug != _doc_of(u):
                targets.setdefault(slug, m.group(0))
        for slug, phrase in targets.items():
            dst = summary_key_by_doc.get(slug)
            if dst:
                links.append(CrossDocLink(
                    src_unit_key=u.unit_key, dst_unit_key=dst,
                    link_type="references_document",
                    evidence=f"mentions '{phrase}'"))
    return links


_CTX_STOP = {"the", "a", "an", "of", "to", "and", "or", "for", "from",
             "within", "after", "before", "than", "must", "shall", "may",
             "be", "is", "are", "with", "by", "all", "any", "no", "not",
             "least", "most", "maximum", "minimum", "up", "at", "in",
             # measure words: already captured as the unit dimension, so
             # they must not double as "shared context" (circular)
             "day", "days", "month", "months", "year", "years", "hour",
             "hours", "percent", "gbp", "eur", "usd"}
_WORD_RE = re.compile(r"[a-z]+")


def _context_words(text: str, start: int, end: int,
                   window: int = 40) -> frozenset[str]:
    """Content words around a quantity — what the number is *about*.
    The quantity expression itself is excised: its unit must match anyway,
    so letting it count as context would make every same-unit pair pass."""
    around = (text[max(0, start - window):start] + " "
              + text[end:end + window]).lower()
    return frozenset(w for w in _WORD_RE.findall(around)
                     if len(w) > 3 and w not in _CTX_STOP)


def extract_quantities(text: str) -> list[tuple[float, str]]:
    return [(v, u) for v, u, _ in extract_quantities_with_context(text)]


def extract_quantities_with_context(
        text: str) -> list[tuple[float, str, frozenset[str]]]:
    out = []
    for m in _QUANTITY_RE.finditer(text):
        value = float(m.group(1).replace(",", ""))
        unit = m.group(2).lower().rstrip("s")
        out.append((value, {"percent": "%"}.get(unit, unit),
                    _context_words(text, m.start(), m.end())))
    for m in _CURRENCY_PREFIX_RE.finditer(text):
        value = float(m.group(2).replace(",", ""))
        out.append((value, {"£": "gbp", "€": "eur", "$": "usd"}[m.group(1)],
                    _context_words(text, m.start(), m.end())))
    return out


def conflict_candidates(topic_members: list[EvidenceUnit],
                        min_shared_context: int = 1
                        ) -> list[CrossDocLink]:
    """potentially_conflicting edges within one topic: units from *different*
    documents whose quantities share unit of measure AND local context but
    differ in value. Same-unit alone is not enough — '7 days to appeal' vs
    '5 days to acknowledge' are about different things; the numbers must be
    *about the same words* to be a candidate. Candidates for human review —
    never a verdict; the shared context is included so the reviewer sees
    why the pair was flagged."""
    by_doc: dict[str, list[tuple[EvidenceUnit, list]]] = defaultdict(list)
    for u in topic_members:
        q = extract_quantities_with_context(u.source_text)
        if q:
            by_doc[_doc_of(u)].append((u, q))
    docs = sorted(by_doc)
    links: list[CrossDocLink] = []
    for i, da in enumerate(docs):
        for db in docs[i + 1:]:
            for ua, qa in by_doc[da]:
                for ub, qb in by_doc[db]:
                    best = None
                    for va, unit_a, ca in qa:
                        for vb, unit_b, cb in qb:
                            if unit_a != unit_b or va == vb:
                                continue
                            shared = ca & cb
                            if len(shared) >= min_shared_context:
                                cand = (len(shared), va, vb, unit_a, shared)
                                if best is None or cand[0] > best[0]:
                                    best = cand
                    if best:
                        _, va, vb, unit, shared = best
                        links.append(CrossDocLink(
                            src_unit_key=ua.unit_key,
                            dst_unit_key=ub.unit_key,
                            link_type="potentially_conflicting",
                            evidence=(f"{da}: {va:g} {unit} vs {db}: "
                                      f"{vb:g} {unit} (re: "
                                      f"{', '.join(sorted(shared)[:4])})")))
    return links
