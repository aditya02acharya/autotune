"""Deterministic PII detection, classification, and masking.

Regex + checksum validation first; an NER hook (e.g. Presidio) can be plugged
in behind `extra_detectors` for names/addresses. Findings record type, span,
and placeholder — never the raw value in a second location.
"""
from __future__ import annotations

import re
from typing import Callable

from pydantic import BaseModel
from stdnum import iban, luhn

from .config import PIIPolicy


class PIIFinding(BaseModel):
    pii_type: str
    start: int
    end: int
    placeholder: str


_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("email", re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")),
    ("uk_nino", re.compile(r"\b[A-CEGHJ-PR-TW-Z]{2}\s?\d{2}\s?\d{2}\s?\d{2}\s?[A-D]\b")),
    ("iban", re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b")),
    ("card_number", re.compile(r"\b(?:\d[ -]?){13,19}\b")),
    ("phone", re.compile(r"(?<!\d)(?:\+44\s?|0)(?:\d\s?){9,10}(?!\d)")),
    ("dob", re.compile(r"\b(?:DOB|date of birth)[:\s]+\d{1,2}[/.-]\d{1,2}[/.-]\d{2,4}\b", re.I)),
    ("employee_id", re.compile(r"\bEMP-?\d{4,8}\b")),
    ("customer_id", re.compile(r"\bCUST-?\d{4,10}\b")),
    ("account_number", re.compile(r"\b(?:account(?:\s+number)?|acct)[:\s#]+\d{6,12}\b", re.I)),
]


def _card_ok(value: str) -> bool:
    digits = re.sub(r"\D", "", value)
    return 13 <= len(digits) <= 19 and luhn.is_valid(digits)


# Checksum validation via python-stdnum (no hand-rolled algorithms).
# UK NINO has no check digit; its format rules live in the regex above.
_VALIDATORS: dict[str, Callable[[str], bool]] = {
    "card_number": _card_ok,
    "iban": iban.is_valid,
}

Detector = Callable[[str], list[tuple[str, int, int]]]  # -> (type, start, end)


def detect_pii(text: str, extra_detectors: list[Detector] | None = None) -> list[PIIFinding]:
    """Find PII spans. Placeholders are stable per type within the text."""
    raw: list[tuple[str, int, int]] = []
    for pii_type, pattern in _PATTERNS:
        for m in pattern.finditer(text):
            validator = _VALIDATORS.get(pii_type)
            if validator and not validator(m.group(0)):
                continue
            raw.append((pii_type, m.start(), m.end()))
    for det in extra_detectors or []:
        raw.extend(det(text))

    # resolve overlaps: longer span wins, then earlier
    raw.sort(key=lambda t: (t[1], -(t[2] - t[1])))
    resolved: list[tuple[str, int, int]] = []
    last_end = -1
    for t, s, e in raw:
        if s >= last_end:
            resolved.append((t, s, e))
            last_end = e

    counters: dict[str, dict[str, int]] = {}
    value_seen: dict[tuple[str, str], str] = {}
    findings = []
    for t, s, e in resolved:
        value = text[s:e]
        key = (t, value)
        if key not in value_seen:
            counters.setdefault(t, {"n": 0})["n"] += 1
            value_seen[key] = f"[{t.upper()}_{counters[t]['n']}]"
        findings.append(PIIFinding(pii_type=t, start=s, end=e,
                                    placeholder=value_seen[key]))
    return findings


def apply_pii_policy(text: str, findings: list[PIIFinding],
                     policy: PIIPolicy) -> tuple[str, list[str]]:
    """Return (masked_text, applied_types). 'preserve' types are left intact."""
    applied: set[str] = set()
    out, cursor = [], 0
    for f in sorted(findings, key=lambda f: f.start):
        action = policy.actions.get(f.pii_type, "mask")
        if action == "preserve":
            continue
        out.append(text[cursor:f.start])
        out.append("" if action == "drop" else f.placeholder)
        cursor = f.end
        applied.add(f.pii_type)
    out.append(text[cursor:])
    return "".join(out), sorted(applied)
