"""Document structure: section hierarchy detection and block classification.

Operates on pages of plain-text lines (after normalize.strip_page_furniture).
Heading detection is numbering-first (works with or without a TOC); layout
cues (font size) can be added by passing styled lines, but the heuristics
below are deliberately layout-independent so they survive bad PDFs.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

_HEADING_RE = re.compile(r"^(?P<num>\d+(?:\.\d+)*)\.?\s+(?P<title>[A-Z].{0,120})$")
_APPENDIX_RE = re.compile(r"^(?P<num>Appendix\s+[A-Z0-9]+)\s*[:.\-–]?\s*(?P<title>.*)$", re.I)
_BULLET_RE = re.compile(r"^\s*(?:[-•*▪◦]|\(?[a-z]\)|\(?[ivx]+\)|\d{1,2}[.)])\s+", re.I)
_DEFINITION_RE = re.compile(r'^[“"]?(?P<term>[A-Z][\w\s/-]{1,60}?)[”"]?\s+(?:means|refers to|is defined as)\s+', )
_FOOTNOTE_RE = re.compile(r"^\s*(?:\[\d+\]|\d{1,2}[.)]?\s)\s*(?=[A-Z])")
_TOC_LINE_RE = re.compile(r"\.{3,}\s*\d+\s*$")


@dataclass
class Block:
    kind: str                 # heading | appendix_heading | paragraph | list_block | definition | footnote
    text: str
    page_start: int
    page_end: int
    section_path: list[str] = field(default_factory=list)
    section_titles: list[str] = field(default_factory=list)
    term: str | None = None


def _is_toc_page(lines: list[str]) -> bool:
    dotted = sum(1 for ln in lines if _TOC_LINE_RE.search(ln))
    return dotted >= max(3, len([l for l in lines if l.strip()]) // 3)


def parse_blocks(pages: list[list[str]]) -> list[Block]:
    """Walk pages, maintain a section stack, group lines into typed blocks."""
    blocks: list[Block] = []
    stack: list[tuple[str, str]] = []  # (number, title)
    buf: list[str] = []
    buf_page_start: int | None = None
    in_appendix = False

    def flush(page_end: int) -> None:
        nonlocal buf, buf_page_start
        text = "\n".join(buf).strip()
        buf, start = [], buf_page_start
        buf_page_start = None
        if not text:
            return
        path = [n for n, _ in stack]
        titles = [t for _, t in stack]
        m = _DEFINITION_RE.match(text)
        if m:
            blocks.append(Block("definition", text, start, page_end, path, titles,
                                term=m.group("term").strip()))
        elif _BULLET_RE.match(text.splitlines()[0]) or (
                len(text.splitlines()) > 1
                and sum(bool(_BULLET_RE.match(l)) for l in text.splitlines()) >= 2):
            blocks.append(Block("list_block", text, start, page_end, path, titles))
        elif in_appendix and _FOOTNOTE_RE.match(text):
            blocks.append(Block("appendix_item" if in_appendix else "paragraph",
                                text, start, page_end, path, titles))
        else:
            kind = "appendix_item" if in_appendix else "paragraph"
            blocks.append(Block(kind, text, start, page_end, path, titles))

    for page_no, lines in enumerate(pages, start=1):
        if _is_toc_page(lines):
            continue
        for line in lines:
            stripped = line.strip()
            if not stripped:
                if buf:
                    flush(page_no)
                continue
            hm = _HEADING_RE.match(stripped)
            am = _APPENDIX_RE.match(stripped)
            if hm and not _BULLET_RE.match(stripped):
                num = hm.group("num")
                # numbered line is a heading only if it deepens/replaces the stack
                depth = num.count(".") + 1
                # Heuristic: short title-cased lines without trailing period
                title = hm.group("title").strip()
                if len(title) <= 90 and not title.endswith((".", ";", ",")):
                    flush(page_no)
                    while len(stack) >= depth:
                        stack.pop()
                    stack.append((num, title))
                    blocks.append(Block("heading", f"{num} {title}", page_no, page_no,
                                        [n for n, _ in stack], [t for _, t in stack]))
                    in_appendix = False
                    continue
            if am:
                flush(page_no)
                stack = [(am.group("num"), am.group("title").strip() or am.group("num"))]
                blocks.append(Block("appendix_heading", stripped, page_no, page_no,
                                    [stack[0][0]], [stack[0][1]]))
                in_appendix = True
                continue
            if buf_page_start is None:
                buf_page_start = page_no
            buf.append(stripped)
        # paragraph may continue across page break — do not flush here
    flush(len(pages))
    return blocks


def extract_section_refs(text: str) -> list[str]:
    """Cross-references like 'see section 3.1' / 'under §4.2.1'."""
    return re.findall(r"(?:section|§|clause)\s*(\d+(?:\.\d+)*)", text, re.I)
