"""Quality gates and ingestion metrics.

Hard failures abort the run (nothing persisted); soft failures quarantine the
unit (persisted, excluded from retrieval, surfaced in the run report).
"""
from __future__ import annotations

import re
import statistics
from dataclasses import dataclass, field

from .config import QualityGates
from .models import EMBEDDABLE_TYPES, EvidenceUnit, UnitStatus, UnitType
from .normalize import is_meaningful

_EXCESS_NL_RE = re.compile(r"\n{3,}")
_EXCESS_SP_RE = re.compile(r" {3,}")


@dataclass
class GateResult:
    hard_failures: list[dict] = field(default_factory=list)
    quarantined: list[dict] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.hard_failures


def run_gates(units: list[EvidenceUnit], gates: QualityGates,
              table_confidence: dict[str, float] | None = None) -> GateResult:
    res = GateResult()
    table_confidence = table_confidence or {}
    seen_keys: dict[str, str] = {}
    keys = {u.unit_key for u in units}

    def hard(u: EvidenceUnit, reason: str) -> None:
        res.hard_failures.append({"unit_key": u.unit_key, "type": u.unit_type.value,
                                  "reason": reason})

    def soft(u: EvidenceUnit, reason: str) -> None:
        u.status = UnitStatus.QUARANTINED
        res.quarantined.append({"unit_key": u.unit_key, "type": u.unit_type.value,
                                "reason": reason})

    for u in units:
        text = u.source_text
        if not text.strip():
            hard(u, "empty_or_whitespace_unit")
            continue
        if not u.provenance.doc_slug or not u.provenance.version_label:
            hard(u, "missing_document_or_version_identity")
        if u.unit_key in seen_keys:
            hard(u, "duplicate_unit_key")
        seen_keys[u.unit_key] = u.unit_id
        if u.parent_key and u.parent_key not in keys:
            hard(u, "broken_parent_link")

        if not is_meaningful(text, gates.min_alnum_ratio_noise):
            soft(u, "layout_noise")
        if _EXCESS_NL_RE.search(text) or _EXCESS_SP_RE.search(text):
            soft(u, "excessive_whitespace")
        if u.provenance.page_start is None:
            soft(u, "missing_page_provenance")
        if u.unit_type in (UnitType.TABLE_ROW, UnitType.TABLE_FACT):
            if u.table is None:
                soft(u, "table_unit_missing_table_context")
            elif u.unit_type == UnitType.TABLE_FACT and (
                    not u.table.row_header_path or not u.table.col_header_path):
                soft(u, "fact_missing_row_or_col_context")
        if u.table and u.table.table_key in table_confidence:
            if table_confidence[u.table.table_key] < gates.min_table_confidence:
                soft(u, "low_confidence_table_parse")
    return res


def compute_metrics(units: list[EvidenceUnit], n_pages: int,
                    gate: GateResult, llm_calls: int = 0,
                    llm_cost: float = 0.0) -> dict:
    sizes = [len(u.source_text) for u in units] or [0]
    by_type = {t.value: sum(1 for u in units if u.unit_type == t) for t in UnitType}

    def pct(p: float) -> int:
        s = sorted(sizes)
        return s[min(len(s) - 1, int(p * len(s)))]

    return {
        "pages": n_pages,
        "units_total": len(units),
        "units_by_type": {k: v for k, v in by_type.items() if v},
        "text_units": by_type["clause"] + by_type["list_block"],
        "section_units": by_type["heading"],
        "definition_units": by_type["definition"],
        "table_units": by_type["table"],
        "table_row_units": by_type["table_row"],
        "table_fact_units": by_type["table_fact"],
        "appendix_units": by_type["appendix_item"],
        "footnote_units": by_type["footnote"],
        "unit_size_min": min(sizes), "unit_size_max": max(sizes),
        "unit_size_avg": round(statistics.mean(sizes), 1),
        "unit_size_p50": pct(0.50), "unit_size_p95": pct(0.95),
        "empty_units": sum(1 for u in units if not u.source_text.strip()),
        "whitespace_only_units": sum(
            1 for u in units if u.source_text and not u.source_text.strip()),
        "excessive_whitespace_units": sum(
            1 for q in gate.quarantined if q["reason"] == "excessive_whitespace"),
        "units_missing_doc_provenance": sum(
            1 for f in gate.hard_failures
            if f["reason"] == "missing_document_or_version_identity"),
        "units_missing_page_provenance": sum(
            1 for q in gate.quarantined if q["reason"] == "missing_page_provenance"),
        "units_missing_section_context": sum(
            1 for u in units if u.unit_type != UnitType.DOC_SUMMARY
            and not u.provenance.section_path),
        "table_units_missing_metadata": sum(
            1 for q in gate.quarantined
            if q["reason"] == "table_unit_missing_table_context"),
        "table_rows_missing_context": sum(
            1 for q in gate.quarantined
            if q["reason"] == "fact_missing_row_or_col_context"),
        "duplicate_units": sum(
            1 for f in gate.hard_failures if f["reason"] == "duplicate_unit_key"),
        "orphaned_units": sum(
            1 for f in gate.hard_failures if f["reason"] == "broken_parent_link"),
        "failed_validation_checks": len(gate.hard_failures),
        "quarantined_units": len(gate.quarantined),
        "low_confidence_table_parses": len({
            q["unit_key"] for q in gate.quarantined
            if q["reason"] == "low_confidence_table_parse"}),
        "llm_calls": llm_calls,
        "llm_cost_estimate_usd": round(llm_cost, 4),
        "units_with_pii": sum(1 for u in units if u.contains_pii),
        "embeddable_units": sum(1 for u in units if u.unit_type in EMBEDDABLE_TYPES),
    }
