"""Deterministic text normalization and layout-noise removal."""
from __future__ import annotations

import re
from collections import Counter

import ftfy

_FTFY_CONFIG = ftfy.TextFixerConfig(normalization="NFKC", uncurl_quotes=True)

_PAGE_NUM_RE = re.compile(r"^\s*(page\s+)?\d+(\s+of\s+\d+)?\s*$", re.I)
_HYPHEN_BREAK_RE = re.compile(r"(\w)-\n(\w)")


def fix_unicode(text: str) -> str:
    """Repair mojibake, expand ligatures (NFKC), uncurl quotes — via ftfy."""
    return ftfy.fix_text(text, config=_FTFY_CONFIG)


def dehyphenate(text: str) -> str:
    """Join words hyphenated at line breaks: 'noti-\\nfication' -> 'notification'."""
    return _HYPHEN_BREAK_RE.sub(r"\1\2", text)


def collapse_whitespace(text: str) -> str:
    """Collapse runs of spaces/tabs; cap blank-line runs at one blank line."""
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r" ?\n ?", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def normalize_text(text: str) -> str:
    return collapse_whitespace(dehyphenate(fix_unicode(text)))


def is_meaningful(text: str, min_alnum_ratio: float = 0.25) -> bool:
    """Reject empty, whitespace-only, and layout-noise strings."""
    stripped = text.strip()
    if not stripped:
        return False
    alnum = sum(c.isalnum() for c in stripped)
    return alnum / len(stripped) >= min_alnum_ratio


def detect_repeated_lines(pages: list[list[str]], ratio: float = 0.6) -> set[str]:
    """Lines appearing on >= ratio of pages are headers/footers/page furniture."""
    if len(pages) < 2:
        return set()
    counts: Counter[str] = Counter()
    for lines in pages:
        for ln in {ln.strip() for ln in lines if ln.strip()}:
            counts[ln] += 1
    threshold = max(2, int(len(pages) * ratio))
    return {ln for ln, c in counts.items() if c >= threshold}


def strip_page_furniture(pages: list[list[str]], ratio: float = 0.6) -> list[list[str]]:
    """Remove repeated headers/footers and bare page numbers from each page."""
    repeated = detect_repeated_lines(pages, ratio)
    out = []
    for lines in pages:
        kept = [ln for ln in lines
                if ln.strip() not in repeated and not _PAGE_NUM_RE.match(ln)]
        out.append(kept)
    return out
