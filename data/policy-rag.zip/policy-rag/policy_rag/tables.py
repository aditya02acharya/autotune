"""Table semantics: layout grid -> canonical model -> orientation-neutral facts.

Input: raw table fragments as extracted per page (e.g. pdfplumber
`extract_table` output, with merged cells appearing as None in covered
positions). Output: ParsedTable with column/row header paths and notes.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .models import ParsedTable

_NUMERIC_RE = re.compile(r"^[\s£$€]*-?[\d,]+(\.\d+)?\s*(%|bp|bps|days?|months?|years?)?\s*$", re.I)
_UNIT_IN_HEADER_RE = re.compile(r"\(([^)]+)\)\s*$")
_NOTE_RE = re.compile(r"^\s*(\*|†|‡|note[s]?\b|\d\))", re.I)


@dataclass
class RawTableFragment:
    page: int
    rows: list[list[str | None]]   # None = covered by a merge / empty
    col_x: list[float] | None = None  # column x-positions when available


def resolve_grid(rows: list[list[str | None]]) -> list[list[str]]:
    """Expand merged cells: a None inherits left (same row) for header-ish
    horizontal merges and above (same column) for vertical merges/grouping.

    Strategy: copy-down within a column when the cell above is non-empty and
    the row is otherwise populated (grouped rows); copy-right within header
    rows is handled later via span fill in header-path derivation. Here we
    just replace None with "" so every cell is addressable; semantic fills
    happen in path derivation where direction is known.
    """
    width = max((len(r) for r in rows), default=0)
    return [[(c or "").strip() for c in r] + [""] * (width - len(r)) for r in rows]


def _row_is_headerish(row: list[str]) -> bool:
    cells = [c for c in row if c]
    if not cells:
        return False
    numeric = sum(bool(_NUMERIC_RE.match(c)) for c in cells)
    return numeric / len(cells) < 0.34 and all(len(c) <= 60 for c in cells)


def detect_header_rows(grid: list[list[str]], max_header_rows: int = 3) -> int:
    """Leading rows that look like headers. 0 means no clear header row.

    A row beyond the first counts as an *additional* header level only when
    there is structural evidence of a multi-row header: the row above has
    merge gaps (empty cells from spans) or this row's leading cell is blank
    (row-header column left empty under a spanned header). Without that
    check, text-heavy data rows get swallowed into the header.
    """
    n = 0
    for i, row in enumerate(grid[:max_header_rows]):
        if not _row_is_headerish(row):
            break
        if i == 0:
            n = 1
            continue
        prev = grid[i - 1]
        if "" in prev or (row and row[0] == ""):
            n += 1
        else:
            break
    # all-headerish tiny tables: keep at least one data row
    return min(n, max(0, len(grid) - 1))


def detect_header_cols(grid: list[list[str]], n_header_rows: int,
                       max_header_cols: int = 2) -> int:
    """Leading columns that act as row headers in the data region."""
    data = grid[n_header_rows:]
    if not data:
        return 0
    n = 0
    for ci in range(min(max_header_cols, len(grid[0]))):
        col = [r[ci] for r in data]
        non_empty = [c for c in col if c]
        if not non_empty:
            break
        numeric = sum(bool(_NUMERIC_RE.match(c)) for c in non_empty)
        if numeric / len(non_empty) < 0.34:
            n += 1
        else:
            break
    return max(n, 1) if len(grid[0]) > 1 and n == 0 else n


def derive_col_paths(grid: list[list[str]], n_header_rows: int,
                     n_header_cols: int) -> list[list[str]]:
    """Per data-column header path. Horizontal merges -> forward fill within
    each header row; vertical repetition collapsed."""
    width = len(grid[0]) if grid else 0
    if n_header_rows == 0:
        return [[f"col_{i + 1}"] for i in range(n_header_cols, width)]
    filled: list[list[str]] = []
    for k, hr in enumerate(grid[:n_header_rows]):
        row, last = [], ""
        for ci, c in enumerate(hr):
            if c:
                last = c
            elif k > 0:
                # Sub-header rows: only fill across a horizontal merge if this
                # column shares the same parent span as the previous column,
                # otherwise the fill would leak under a different parent.
                same_parent = ci > 0 and all(
                    filled[j][ci] == filled[j][ci - 1] for j in range(k)
                )
                if not same_parent:
                    last = ""
            row.append(last)
        filled.append(row)
    paths = []
    for ci in range(n_header_cols, width):
        path, prev = [], None
        for hr in filled:
            label = hr[ci]
            if label and label != prev:
                path.append(label)
            prev = label
        paths.append(path or [f"col_{ci + 1}"])
    return paths


def derive_row_paths(grid: list[list[str]], n_header_rows: int,
                     n_header_cols: int) -> list[list[str]]:
    """Per data-row header path with fill-down for grouped rows."""
    data = grid[n_header_rows:]
    carried = [""] * max(n_header_cols, 0)
    paths = []
    for r in data:
        path = []
        for ci in range(n_header_cols):
            cell = r[ci]
            if cell:
                carried[ci] = cell
                carried[ci + 1:n_header_cols] = [""] * (n_header_cols - ci - 1) or []
            if carried[ci]:
                path.append(carried[ci])
        paths.append(path or [f"row_{len(paths) + 1}"])
    return paths


def split_notes(rows: list[list[str | None]]) -> tuple[list[list[str | None]], list[str]]:
    """Trailing single-cell rows matching note markers become table notes."""
    notes: list[str] = []
    body = list(rows)
    while body:
        last = [c for c in body[-1] if c and str(c).strip()]
        if len(last) == 1 and _NOTE_RE.match(str(last[0])):
            notes.insert(0, str(last[0]).strip())
            body.pop()
        else:
            break
    return body, notes


def _header_signature(rows: list[list[str | None]], n: int) -> tuple:
    return tuple(tuple((c or "").strip().lower() for c in r) for r in rows[:n])


def stitch_fragments(fragments: list[RawTableFragment]) -> tuple[list[list[str | None]], int]:
    """Merge multi-page fragments; drop repeated headers. Returns (rows, n_pages)."""
    if not fragments:
        return [], 0
    base = list(fragments[0].rows)
    head_n = detect_header_rows(resolve_grid(base))
    sig = _header_signature(base, head_n) if head_n else None
    for frag in fragments[1:]:
        rows = list(frag.rows)
        if sig and _header_signature(rows, head_n) == sig:
            rows = rows[head_n:]          # repeated header on new page
        base.extend(rows)
    return base, len(fragments)


def extract_unit(label: str) -> tuple[str, str | None]:
    """Pull a unit of measure out of a header label: 'Limit (GBP)' -> GBP."""
    m = _UNIT_IN_HEADER_RE.search(label)
    return (label[:m.start()].strip(), m.group(1)) if m else (label, None)


def score_confidence(grid: list[list[str]], n_header_rows: int) -> float:
    if not grid:
        return 0.0
    width = len(grid[0])
    ragged = sum(1 for r in grid if len([c for c in r if c]) == 0)
    empty_ratio = (sum(1 for r in grid for c in r if not c)
                   / max(1, len(grid) * width))
    score = 1.0
    if n_header_rows == 0:
        score -= 0.4
    score -= 0.3 * empty_ratio
    score -= 0.1 * (ragged / max(1, len(grid)))
    return max(0.0, min(1.0, score))


def parse_table(fragments: list[RawTableFragment], table_key: str,
                section_path: list[str], caption: str | None = None) -> ParsedTable:
    body_rows, n_pages = stitch_fragments(fragments)
    body_rows, notes = split_notes(body_rows)
    grid = resolve_grid(body_rows)
    n_hr = detect_header_rows(grid)
    n_hc = detect_header_cols(grid, n_hr)
    return ParsedTable(
        table_key=table_key, caption=caption, section_path=section_path,
        page_start=fragments[0].page, page_end=fragments[-1].page,
        grid=grid, n_header_rows=n_hr, n_header_cols=n_hc,
        col_paths=derive_col_paths(grid, n_hr, n_hc),
        row_paths=derive_row_paths(grid, n_hr, n_hc),
        notes=notes, confidence=score_confidence(grid, n_hr),
        stitched_pages=n_pages,
    )


def iter_facts(t: ParsedTable):
    """Yield orientation-neutral facts: (row_idx, col_idx, row_path, col_path,
    value, unit). Pivot-invariant: a transposed table yields the same
    (row_path, col_path) pairs with roles swapped, which fact consumers treat
    as an unordered pair when comparing."""
    for ri, row in enumerate(t.grid[t.n_header_rows:]):
        for cj, value in enumerate(row[t.n_header_cols:]):
            if not value:
                continue
            col_label_path = t.col_paths[cj]
            clean_path, unit = [], None
            for label in col_label_path:
                lbl, u = extract_unit(label)
                clean_path.append(lbl)
                unit = u or unit
            yield ri, cj, t.row_paths[ri], clean_path, value, unit
