"""Guarded LLM access and PII-safe logging.

Every LLM call passes through GuardedLLMClient: the configured PII policy is
applied to the prompt, the call is audited (purpose, model, token & cost
estimates, pii_present), and prompts are not stored unless explicitly
enabled. If masking would destroy required meaning and raw PII is forbidden,
the call is refused with `requires_elevation`.
"""
from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Callable, Protocol

from tenacity import retry, stop_after_attempt, wait_exponential

from .config import Config
from .pii import apply_pii_policy, detect_pii

_RETRY = retry(stop=stop_after_attempt(4),
               wait=wait_exponential(multiplier=0.5, max=8), reraise=True)


class LLMBackend(Protocol):
    def complete(self, prompt: str, system: str | None = None) -> str: ...


class AnthropicBackend:
    """Cloud-hosted Claude via the official `anthropic` SDK."""

    def __init__(self, model: str, max_tokens: int = 1024):
        from anthropic import Anthropic  # lazy: optional at runtime
        self._client = Anthropic()       # ANTHROPIC_API_KEY from env
        self._model = model
        self._max_tokens = max_tokens

    @_RETRY
    def complete(self, prompt: str, system: str | None = None) -> str:
        resp = self._client.messages.create(
            model=self._model, max_tokens=self._max_tokens,
            system=system or "", 
            messages=[{"role": "user", "content": prompt}])
        return "".join(b.text for b in resp.content if b.type == "text")


class OpenAICompatibleBackend:
    """Any OpenAI-compatible chat endpoint (cloud LLM or vLLM-hosted)."""

    def __init__(self, model: str, base_url: str | None = None,
                 api_key: str | None = None, max_tokens: int = 1024):
        from openai import OpenAI  # lazy: optional at runtime
        self._client = OpenAI(base_url=base_url, api_key=api_key or "EMPTY")
        self._model = model
        self._max_tokens = max_tokens

    @_RETRY
    def complete(self, prompt: str, system: str | None = None) -> str:
        messages = ([{"role": "system", "content": system}] if system else [])
        messages.append({"role": "user", "content": prompt})
        resp = self._client.chat.completions.create(
            model=self._model, max_tokens=self._max_tokens, messages=messages)
        return resp.choices[0].message.content or ""


def make_backend(config: Config) -> LLMBackend:
    if config.llm_provider == "anthropic":
        return AnthropicBackend(config.llm_model)
    return OpenAICompatibleBackend(config.llm_model,
                                   base_url=config.llm_base_url)


@dataclass
class LLMCallRecord:
    purpose: str
    model: str
    input_kind: str
    token_estimate: int
    cost_estimate: float
    pii_present: bool
    prompt_stored: bool
    prompt_text: str | None = None


class ElevationRequired(Exception):
    """Masking would destroy required meaning and raw PII is not allowed."""


@dataclass
class GuardedLLMClient:
    config: Config
    backend: LLMBackend
    audit_sink: Callable[[LLMCallRecord], None] = lambda rec: None
    calls: list[LLMCallRecord] = field(default_factory=list)

    def complete(self, prompt: str, *, purpose: str,
                 pii_required_for_meaning: bool = False,
                 system: str | None = None) -> str:
        findings = detect_pii(prompt)
        pii_present = bool(findings)
        send_text = prompt
        input_kind = "raw"
        if pii_present and not self.config.pii.allow_raw_pii_to_llm:
            if pii_required_for_meaning:
                raise ElevationRequired(
                    f"LLM call '{purpose}' needs raw PII; policy forbids it.")
            send_text, _ = apply_pii_policy(prompt, findings, self.config.pii)
            input_kind = "masked"

        tokens = max(1, len(send_text) // 4)
        rec = LLMCallRecord(
            purpose=purpose, model=self.config.llm_model, input_kind=input_kind,
            token_estimate=tokens,
            cost_estimate=tokens / 1000 * self.config.llm_cost_per_1k_tokens,
            pii_present=pii_present,
            prompt_stored=self.config.pii.store_llm_prompts,
            prompt_text=send_text if self.config.pii.store_llm_prompts else None,
        )
        self.calls.append(rec)
        self.audit_sink(rec)
        return self.backend.complete(send_text, system=system)

    @property
    def total_cost(self) -> float:
        return sum(c.cost_estimate for c in self.calls)


class PIISafeLogger:
    """Structured logging that never emits document text or PII by default.

    Callers log IDs, hashes, counts, and metadata; the `text` kwarg is dropped
    unless config.pii.log_text_debug is explicitly enabled.
    """

    def __init__(self, config: Config, name: str = "policy_rag"):
        self._cfg = config
        self._log = logging.getLogger(name)

    def event(self, msg: str, **fields) -> None:
        if not self._cfg.pii.log_text_debug:
            fields.pop("text", None)
            fields.pop("source_text", None)
        self._log.info("%s %s", msg, fields)
