"""Configuration (Pydantic). Everything privacy- or cost-relevant is explicit
here; deployment values (endpoints, models) can be overridden via environment
variables with the POLICY_RAG_ prefix, e.g. POLICY_RAG_VLLM_BASE_URL.
"""
from __future__ import annotations

from pydantic import BaseModel, Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class PIIPolicy(BaseModel):
    """What to do with each detected PII type before embedding/LLM/logging."""
    # action per type: 'mask' | 'drop' | 'preserve'
    actions: dict[str, str] = Field(default_factory=lambda: {
        "email": "mask", "phone": "mask", "uk_nino": "mask",
        "card_number": "mask", "iban": "mask", "account_number": "mask",
        "employee_id": "mask", "customer_id": "mask", "dob": "mask",
        "name": "mask", "address": "mask",
    })
    allow_raw_pii_to_llm: bool = False
    embed_masked: bool = True          # embeddings built from masked text
    store_llm_prompts: bool = False
    log_text_debug: bool = False       # raw text in logs requires opt-in


class TableFactPolicy(BaseModel):
    """Cell-level facts are powerful but a 60x40 table is 2,400 rows of
    fact units; explicit thresholds instead of unbounded generation.
    Rows are ALWAYS stored regardless; empty cells never produce facts."""
    max_fact_cells: int = 400          # rows*cols above this: rows only
    min_fact_confidence: float = 0.7   # below: header paths too unreliable
    # facts are unembedded by default (FTS/trgm still finds them); small,
    # high-confidence tables get fact embeddings for semantic cell lookup
    embed_fact_max_cells: int = 80
    embed_fact_min_confidence: float = 0.85


class QualityGates(BaseModel):
    max_unit_chars: int = 1800
    min_unit_chars: int = 1
    max_consecutive_newlines: int = 2
    min_alnum_ratio_noise: float = 0.25   # below this → layout noise
    min_table_confidence: float = 0.55    # below this → quarantine table
    header_footer_page_ratio: float = 0.6 # line on >=60% pages → strip


class Config(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="POLICY_RAG_",
                                      env_nested_delimiter="__")

    embedding_dim: int = 768
    embedding_model: str = "stub-hash-768"
    vllm_base_url: str = "http://localhost:8000/v1"  # vLLM OpenAI-compatible
    vllm_api_key: str = "EMPTY"                      # vLLM default
    pii: PIIPolicy = Field(default_factory=PIIPolicy)
    facts: TableFactPolicy = Field(default_factory=TableFactPolicy)
    gates: QualityGates = Field(default_factory=QualityGates)
    llm_provider: str = "anthropic"                  # 'anthropic' | 'openai_compatible'
    llm_base_url: str | None = None                  # for openai-compatible hosts
    llm_model: str = "claude-sonnet-4-20250514"
    llm_cost_per_1k_tokens: float = 0.003
    allow_llm_table_header_inference: bool = False  # default: quarantine instead
