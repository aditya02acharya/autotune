"""Topic face: a single cross-corpus abstraction layer (RAPTOR, adapted).

Full RAPTOR builds a recursive LLM-summary tree over chunks. Two properties
of this corpus argue against importing it wholesale:

1. *Within* a document the section tree is already a human-authored
   abstraction hierarchy — recursive clustering there rediscovers, at LLM
   cost, structure we ingest for free.
2. The conservative-LLM constraint: per-chunk or per-node summarisation is
   O(corpus) LLM calls on every refresh.

What survives, and what this module implements, is the layer that does not
exist anywhere in the documents: *cross-document* topics ("data retention
as treated across the estate"). One flat clustering over active embeddable
units, with:

- deterministic 'medoid' summaries by default (the most central unit's text
  — extractive, zero LLM calls), or
- one guarded LLM call per topic when `llm` mode is chosen, gated by
  member_hash so summaries regenerate only when membership actually changes.

Topics yield `same_topic` edges (co-membership above a similarity floor)
and feed `conflict_candidates` in linking.py.
"""
from __future__ import annotations

import hashlib
import math
from collections import Counter

import numpy as np
from pydantic import BaseModel, Field
from sklearn.cluster import AgglomerativeClustering, MiniBatchKMeans

from .embeddings import Embedder
from .models import EMBEDDABLE_TYPES, EvidenceUnit


class Topic(BaseModel):
    label: str
    summary_text: str
    summary_method: str                     # 'medoid' | 'llm'
    member_hash: str                        # sha256 of sorted member unit_keys
    member_keys: list[str]
    similarities: list[float]               # cosine sim to centroid, aligned
    n_documents: int
    centroid: list[float] = Field(repr=False)


_LABEL_STOPWORDS = {"the", "a", "an", "of", "to", "and", "or", "in", "for",
                    "is", "are", "be", "by", "on", "with", "shall", "must",
                    "may", "all", "any", "this", "that", "as", "at", "its"}


def _label_from_texts(texts: list[str], k: int = 4) -> str:
    """Deterministic label: most frequent content words across members."""
    counts: Counter[str] = Counter()
    for t in texts:
        for w in t.lower().split():
            w = w.strip(".,;:()[]'\"")
            if len(w) > 3 and w not in _LABEL_STOPWORDS and not w.isdigit():
                counts[w] += 1
    return " ".join(w for w, _ in counts.most_common(k)) or "untitled topic"


def _member_hash(keys: list[str]) -> str:
    return hashlib.sha256("|".join(sorted(keys)).encode()).hexdigest()


def build_topics(units: list[EvidenceUnit], embedder: Embedder,
                 distance_threshold: float = 0.65,
                 min_members: int = 2,
                 guarded_llm=None) -> list[Topic]:
    """Cluster active embeddable units into cross-corpus topics.

    Agglomerative clustering with a cosine-distance threshold rather than a
    fixed k: corpus growth adds topics instead of diluting them. Topics
    spanning a single document are kept only if large — single-doc topics
    mostly duplicate the Structure face.

    `guarded_llm`: optional GuardedLLMClient; when given, each topic gets
    one audited summarisation call (purpose='topic_summary'). Otherwise the
    medoid unit's text is the summary — zero LLM calls.
    """
    cands = [u for u in units
             if u.unit_type in EMBEDDABLE_TYPES and u.retrieval_text]
    if len(cands) < min_members:
        return []
    X = np.array(embedder.embed([u.retrieval_text for u in cands]))
    X = X / np.maximum(np.linalg.norm(X, axis=1, keepdims=True), 1e-12)

    if len(cands) <= 2000:
        labels = AgglomerativeClustering(
            n_clusters=None, metric="cosine", linkage="average",
            distance_threshold=distance_threshold).fit_predict(X)
    else:
        # Agglomerative is O(n^2) memory/time — fine for small estates,
        # impossible at hundreds of documents. Beyond the threshold use
        # MiniBatchKMeans with k scaled to corpus size; low-coherence
        # clusters are dropped below rather than tuned for.
        k = max(8, len(cands) // 40)
        labels = MiniBatchKMeans(n_clusters=k, n_init=3,
                                 random_state=0).fit_predict(X)

    topics: list[Topic] = []
    for cl in sorted(set(labels)):
        idx = np.where(labels == cl)[0]
        members = [cands[i] for i in idx]
        docs = {m.provenance.doc_slug for m in members}
        if len(members) < min_members:
            continue
        if len(docs) < 2 and len(members) < 2 * min_members:
            continue  # single-doc and small: the section tree covers it
        centroid = X[idx].mean(axis=0)
        centroid = centroid / max(float(np.linalg.norm(centroid)), 1e-12)
        sims = (X[idx] @ centroid).tolist()
        if sum(sims) / len(sims) < 0.35:
            continue  # incoherent grab-bag cluster: not a topic
        medoid = members[int(np.argmax(sims))]

        if guarded_llm is not None:
            joined = "\n---\n".join(m.retrieval_text[:400] for m in members[:12])
            summary = guarded_llm.complete(
                "Summarise, in 3 neutral sentences, what these policy "
                "excerpts collectively govern. Do not resolve any "
                "disagreements between them; note them.\n\n" + joined,
                purpose="topic_summary")
            method = "llm"
        else:
            summary, method = medoid.retrieval_text, "medoid"

        topics.append(Topic(
            label=_label_from_texts([m.source_text for m in members]),
            summary_text=summary, summary_method=method,
            member_hash=_member_hash([m.unit_key for m in members]),
            member_keys=[m.unit_key for m in members],
            similarities=[float(s) for s in sims],
            n_documents=len(docs),
            centroid=[float(x) for x in centroid]))
    return topics


def same_topic_edges(topic: Topic, sim_floor: float = 0.5,
                     max_edges: int = 50) -> list[tuple[str, str]]:
    """Co-membership edges between the topic's most central members,
    capped so dense topics don't produce quadratic edge counts."""
    ranked = [k for s, k in sorted(
        zip(topic.similarities, topic.member_keys), reverse=True)
        if s >= sim_floor]
    edges = []
    for i, a in enumerate(ranked):
        for b in ranked[i + 1:]:
            if len(edges) >= max_edges:
                return edges
            edges.append((a, b))
    return edges
