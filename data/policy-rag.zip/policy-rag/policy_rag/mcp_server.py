"""MCP server: three tools instead of sixteen.

The earlier surface exposed one tool per face per grain; tool selection
became the consumer's hardest problem. Now layered:

- `research_policy`  agent-as-a-tool: a guarded LLM orchestrates the full
                     action registry in a bounded, audited loop and returns
                     a cited answer PLUS the complete trajectory.
- `find_evidence`    deterministic search, optionally expanding top hits.
- `navigate`         one dispatcher over every deterministic primitive
                     (the former individual tools live on as actions).

Only `research_policy` invokes the LLM.
"""
from __future__ import annotations

import os
from typing import Any

from mcp.server.fastmcp import FastMCP

from .config import Config
from .embeddings import make_embedder
from .llm import GuardedLLMClient, make_backend
from .orchestrator import build_registry, run_research
from .storage import Storage

mcp = FastMCP("policy-rag")
_config = Config()
_storage = Storage(os.environ.get("POLICY_RAG_DSN",
                                  "postgresql://localhost/policy_rag"),
                   _config, make_embedder(_config))
_registry = build_registry(_storage)


def _hit(row: dict) -> dict:
    from .answer import source_of
    h = {k: row.get(k) for k in (
        "unit_id", "unit_type", "retrieval_text", "context_header",
        "status", "contains_pii", "row_header_path", "col_header_path",
        "cell_value", "unit_of_measure", "score")}
    h["source"] = source_of(row)   # doc_slug/title/version/section/pages
    return h


@mcp.tool()
def research_policy(question: str, max_steps: int = 6) -> dict:
    """Answer a complex policy question end-to-end. A guarded LLM
    orchestrates the evidence store (orient -> search -> expand -> tables ->
    cross-document conflicts) in at most `max_steps` audited steps, then
    synthesizes a citation-enforced answer. Returns the answer AND the full
    trajectory of actions and observations — nothing is hidden. The only
    tool that calls the LLM; cost is bounded by max_steps + 1 calls."""
    llm = GuardedLLMClient(_config, make_backend(_config))
    return run_research(question, _storage, llm, max_steps).as_dict()


@mcp.tool()
def find_evidence(query: str, mode: str = "hybrid", k: int = 10,
                  unit_types: list[str] | None = None,
                  doc_slugs: list[str] | None = None,
                  section_prefix: list[str] | None = None,
                  expand_top: int = 0) -> list[dict]:
    """Deterministic evidence search (no LLM). mode: hybrid | exact.
    unit_types filters grain, e.g. ['definition'] for terms,
    ['table_row','table_fact'] for limits. expand_top=N additionally returns
    full context (neighbors, parent, links) for the N best hits."""
    if mode == "exact":
        hits = _storage.exact_term_search(query, k)
    else:
        hits = _storage.hybrid_search(query, k, unit_types=unit_types,
                                      section_prefix=section_prefix)
    out = [_hit(r) for r in hits]
    for h in out[:max(0, expand_top)]:
        h["context"] = _storage.expand_unit(str(h["unit_id"]))
    return out


@mcp.tool()
def navigate(action: str, params: dict[str, Any] | None = None) -> Any:
    """Deterministic navigation over the corpus's faces (no LLM). Actions:
    documents() | overview(doc_slug, version?) | section(doc_slug, section) |
    expand(unit_id, before?, after?) | table(table_key, doc_slug?) |
    fact(table_key, row_path, col_path) | topics(query?) |
    topic_members(topic_id) | related(unit_id) | conflicts() |
    versions(doc_slug, version_a, version_b) | search(query, k?, unit_types?).
    Example: navigate('overview', {'doc_slug': 'credit-risk'})."""
    if action not in _registry:
        return {"error": f"unknown action '{action}'",
                "actions": {a.name: a.description
                            for a in _registry.values()}}
    try:
        return _registry[action].run(**(params or {}))
    except TypeError as e:
        return {"error": str(e), "usage": _registry[action].description}


if __name__ == "__main__":
    mcp.run()
