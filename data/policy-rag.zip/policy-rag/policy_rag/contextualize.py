"""Build context headers and retrieval text — deterministic, no LLM.

retrieval_text = breadcrumb + body, so every unit is understandable in
isolation and citable. Table rows are serialized with their header paths.
"""
from __future__ import annotations

from .models import EvidenceUnit, ParsedTable, Provenance, UnitType
from .tables import iter_facts


def build_context_header(prov: Provenance, extra: list[str] | None = None) -> str:
    parts = [f"{prov.doc_title} {prov.version_label}"]
    parts += [f"{n} {t}".strip() for n, t in
              zip(prov.section_path, prov.section_titles)]
    parts += extra or []
    return " › ".join(p for p in parts if p)


def contextualize(unit: EvidenceUnit, masked_body: str) -> None:
    """Set context_header and retrieval_text on a prose-like unit."""
    extra = []
    if unit.unit_type == UnitType.DEFINITION and unit.term:
        extra.append(f"Definition: {unit.term}")
    if unit.table and unit.table.caption:
        extra.append(unit.table.caption)
    unit.context_header = build_context_header(unit.provenance, extra)
    unit.retrieval_text = f"{unit.context_header}\n{masked_body}".strip()


def serialize_row(t: ParsedTable, row_idx: int) -> str:
    """One logical row as 'path | Col (unit): value | ...' for embedding."""
    cells = []
    for ri, cj, row_path, col_path, value, unit in iter_facts(t):
        if ri != row_idx:
            continue
        label = " › ".join(col_path)
        cells.append(f"{label}{f' ({unit})' if unit else ''}: {value}")
    head = " › ".join(t.row_paths[row_idx]) if row_idx < len(t.row_paths) else ""
    body = " | ".join([head] + cells) if head else " | ".join(cells)
    if t.notes:
        body += f" | notes: {' '.join(t.notes)}"
    return body


def serialize_table(t: ParsedTable) -> str:
    """Whole-table text: caption + header structure + rows + notes."""
    lines = []
    if t.caption:
        lines.append(t.caption)
    lines.append("Columns: " + "; ".join(" › ".join(p) for p in t.col_paths))
    for ri in range(len(t.row_paths)):
        lines.append(serialize_row(t, ri))
    return "\n".join(lines)
