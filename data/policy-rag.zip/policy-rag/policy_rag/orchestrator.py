"""Agent-as-a-tool: one research entry point instead of sixteen tools.

The MCP surface had grown a tool per face per grain. Consumers (人 or agent)
faced sixteen schemas; tool selection itself became the hard problem. The
fix is layering, not deletion:

- Primitives become an internal **action registry** (this module) — same
  deterministic Storage methods, no longer individually exposed.
- A guarded LLM **orchestrates** them in a bounded loop: it sees the
  question + action catalog, emits one JSON action per step, observes
  compacted results, and decides the next pivot (search -> expand -> table
  -> conflicts ...).
- Final synthesis goes through the existing citation-enforced `synthesize`,
  so the orchestrator cannot launder unsupported claims, and the full
  **trajectory is returned** — the caller sees every action, argument, and
  observation. Orchestration must not hide the hard parts of the task.

Cost discipline: <= max_steps + 1 LLM calls per question, every call through
GuardedLLMClient (PII-guarded, audited). Deterministic failure modes:
malformed JSON or unknown actions become error observations the LLM can
recover from; the step cap forces synthesis from whatever evidence exists.
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any, Callable

from .answer import GroundedAnswer, synthesize
from .llm import GuardedLLMClient

# ---------------------------------------------------------------- actions

@dataclass
class Action:
    name: str
    description: str                 # shown to the orchestrator LLM
    run: Callable[..., Any]


def build_registry(storage) -> dict[str, Action]:
    """Internal actions = the former MCP tools, over the same Storage."""
    acts = [
        Action("documents", "() corpus inventory: slug, title, version, pages",
               lambda: storage.list_documents()),
        Action("overview", "(doc_slug, version?) summary + section outline + table index",
               lambda doc_slug, version=None:
               storage.document_overview(doc_slug, version)),
        Action("search", "(query, k?, unit_types?, section_prefix?) hybrid search; "
               "unit_types e.g. ['definition'] or ['table_row','clause']",
               lambda query, k=8, unit_types=None, section_prefix=None:
               storage.hybrid_search(query, k, unit_types=unit_types,
                                     section_prefix=section_prefix)),
        Action("section", "(doc_slug, section) all units under a clause number e.g. '4.2'",
               lambda doc_slug, section:
               storage.section_lookup(doc_slug, str(section).split("."))),
        Action("expand", "(unit_id, before?, after?) unit + surroundings + parent + links",
               lambda unit_id, before=2, after=2:
               storage.expand_unit(unit_id, before, after)),
        Action("table", "(table_key, doc_slug?) whole table: rows, header paths, notes",
               lambda table_key, doc_slug=None:
               storage.table_bundle(table_key, doc_slug)),
        Action("fact", "(table_key, row_path, col_path) single cell fact",
               lambda table_key, row_path, col_path:
               storage.table_fact(table_key, row_path, col_path)),
        Action("topics", "(query?) cross-document themes",
               lambda query=None: storage.browse_topics(query)),
        Action("topic_members", "(topic_id) units in a theme across documents",
               lambda topic_id: storage.topic_members(topic_id)),
        Action("related", "(unit_id) cross-doc pivots: term definitions, cited "
               "docs, same-topic peers, conflict candidates",
               lambda unit_id: storage.get_related(unit_id)),
        Action("conflicts", "() divergent-quantity pairs across documents",
               lambda: storage.list_conflict_candidates()),
        Action("versions", "(doc_slug, version_a, version_b) unit-level diff",
               lambda doc_slug, version_a, version_b:
               storage.compare_versions(doc_slug, version_a, version_b)),
    ]
    return {a.name: a for a in acts}


# ------------------------------------------------------------ harvesting

def harvest_units(obj: Any, pool: dict[str, dict]) -> None:
    """Collect anything that looks like an evidence unit (unit_id +
    retrieval_text) from arbitrarily nested action results."""
    if isinstance(obj, dict):
        if obj.get("unit_id") and obj.get("retrieval_text"):
            pool[str(obj["unit_id"])] = {
                "unit_id": str(obj["unit_id"]),
                "unit_type": obj.get("unit_type", "clause"),
                "retrieval_text": obj["retrieval_text"],
                "context_header": obj.get("context_header", ""),
                "doc_slug": obj.get("doc_slug"),
                "doc_title": obj.get("doc_title"),
                "version_label": obj.get("version_label"),
                "section_path": obj.get("section_path"),
                "page_start": obj.get("page_start"),
                "page_end": obj.get("page_end"),
                "status": obj.get("status", "active")}
        for v in obj.values():
            harvest_units(v, pool)
    elif isinstance(obj, (list, tuple)):
        for v in obj:
            harvest_units(v, pool)


def compact(obj: Any, text_limit: int = 240, list_limit: int = 8) -> Any:
    """Shrink an observation before it re-enters the LLM context."""
    if isinstance(obj, dict):
        return {k: compact(v, text_limit, list_limit)
                for k, v in obj.items() if k not in ("embedding", "tsv")}
    if isinstance(obj, (list, tuple)):
        out = [compact(v, text_limit, list_limit) for v in obj[:list_limit]]
        if len(obj) > list_limit:
            out.append(f"... ({len(obj) - list_limit} more)")
        return out
    if isinstance(obj, str) and len(obj) > text_limit:
        return obj[:text_limit] + "…"
    return obj


# ---------------------------------------------------------------- loop

_JSON_RE = re.compile(r"\{.*\}", re.DOTALL)

ORCH_SYSTEM = (
    "You are a research orchestrator over a policy-document evidence store. "
    "Each turn, respond with ONLY one JSON object, no prose:\n"
    '  {"action": "<name>", "args": {...}}   to gather evidence, or\n'
    '  {"action": "finish"}                  when evidence suffices.\n'
    "Strategy: orient (documents/overview/topics) before drilling in; expand "
    "the units you will rely on; check 'related' for conflicting policies "
    "when documents may disagree; prefer table/fact for numeric limits. "
    "Gather evidence for ALL parts of the question before finishing.")


def _parse_action(raw: str) -> tuple[str, dict] | None:
    m = _JSON_RE.search(raw.replace("```json", "").replace("```", ""))
    if not m:
        return None
    try:
        obj = json.loads(m.group(0))
        return str(obj.get("action", "")), dict(obj.get("args") or {})
    except (json.JSONDecodeError, TypeError, ValueError):
        return None


@dataclass
class ResearchResult:
    answer: GroundedAnswer
    trajectory: list[dict] = field(default_factory=list)
    n_llm_calls: int = 0
    n_evidence_units: int = 0

    def as_dict(self) -> dict:
        return {**self.answer.__dict__, "trajectory": self.trajectory,
                "n_llm_calls": self.n_llm_calls,
                "n_evidence_units": self.n_evidence_units}


def run_research(question: str, storage, llm: GuardedLLMClient,
                 max_steps: int = 6) -> ResearchResult:
    registry = build_registry(storage)
    catalog = "\n".join(f"- {a.name}{a.description}"
                        for a in registry.values())
    pool: dict[str, dict] = {}
    trajectory: list[dict] = []
    observations: list[str] = []
    n_calls = 0

    for step in range(max_steps):
        prompt = (f"Question: {question}\n\nActions:\n{catalog}\n\n"
                  + ("Observations so far:\n" + "\n".join(observations)
                     if observations else "No observations yet.")
                  + f"\n\nEvidence units gathered: {len(pool)}. "
                    f"Steps remaining: {max_steps - step}. Next JSON:")
        raw = llm.complete(prompt, purpose="research_orchestration",
                           system=ORCH_SYSTEM)
        n_calls += 1
        parsed = _parse_action(raw)
        if parsed is None:
            trajectory.append({"step": step, "error": "unparseable_action",
                               "raw": raw[:200]})
            observations.append(f"[{step}] ERROR: respond with one JSON object only.")
            continue
        name, args = parsed
        if name == "finish":
            trajectory.append({"step": step, "action": "finish"})
            break
        if name not in registry:
            trajectory.append({"step": step, "error": "unknown_action",
                               "action": name})
            observations.append(f"[{step}] ERROR: unknown action '{name}'.")
            continue
        try:
            result = registry[name].run(**args)
        except TypeError as e:           # bad args: recoverable observation
            trajectory.append({"step": step, "action": name, "args": args,
                               "error": str(e)})
            observations.append(f"[{step}] {name} ERROR: {e}")
            continue
        harvest_units(result, pool)
        obs = compact(result)
        trajectory.append({"step": step, "action": name, "args": args,
                           "observation": obs})
        observations.append(f"[{step}] {name}({args}) -> "
                            f"{json.dumps(obs, default=str)[:800]}")

    answer = synthesize(question, list(pool.values()), llm,
                        trace=trajectory)
    return ResearchResult(answer=answer, trajectory=trajectory,
                          n_llm_calls=n_calls + (1 if pool else 0),
                          n_evidence_units=len(pool))
