"""Grounded answering: evidence in, cited answer out — or an honest refusal.

The synthesizer never answers from model memory: it receives only retrieved
units, must cite their IDs, and an answer whose citations fall outside the
retrieved set is rejected. Missing/weak evidence -> explicit "insufficient
evidence" with what was found.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field

from .llm import GuardedLLMClient

_CITE_RE = re.compile(r"\[\[(?P<uid>[0-9a-f-]{8,})\]\]")

SYNTH_SYSTEM = (
    "You answer questions about policy documents using ONLY the evidence "
    "units provided. Every claim must cite a unit as [[unit_id]]. Preserve "
    "units of measure, caveats, notes, and conditions. If the evidence is "
    "missing, incomplete, ambiguous, or conflicting, say so explicitly "
    "instead of guessing. Attribute each claim to its source document when "
    "evidence spans multiple documents; never merge documents into one claim."
)


@dataclass
class GroundedAnswer:
    answer: str
    citations: list[str]
    confidence: str                       # high | medium | low | insufficient
    sources: list[dict] = field(default_factory=list)  # resolved per citation:
    # {unit_id, doc_slug, doc_title, version, section_path, page_start, page_end}
    limitations: list[str] = field(default_factory=list)
    used_llm: bool = False
    pii_accessed: bool = False
    versions_used: list[str] = field(default_factory=list)
    retrieval_trace: list[dict] = field(default_factory=list)


def source_of(h: dict) -> dict:
    """Structured provenance for one hit — the citation contract."""
    return {"unit_id": str(h.get("unit_id", "")),
            "doc_slug": h.get("doc_slug"),
            "doc_title": h.get("doc_title"),
            "version": h.get("version_label"),
            "section_path": list(h.get("section_path") or []),
            "page_start": h.get("page_start"),
            "page_end": h.get("page_end")}


def format_evidence(hits: list[dict]) -> str:
    blocks = []
    for h in hits:
        blocks.append(
            f"[[{h['unit_id']}]] (source: {h.get('doc_title') or h.get('doc_slug')} "
            f"{h.get('version_label') or ''}, "
            f"section {'.'.join(h.get('section_path') or []) or '-'}, "
            f"pages {h.get('page_start')}–{h.get('page_end')}, "
            f"{h['unit_type']}, status={h.get('status', 'active')})\n"
            f"{h['retrieval_text']}")
    return "\n\n".join(blocks)


def synthesize(question: str, hits: list[dict], llm: GuardedLLMClient,
               trace: list[dict] | None = None) -> GroundedAnswer:
    if not hits:
        return GroundedAnswer(
            answer="Insufficient evidence: no relevant evidence units were "
                   "retrieved for this question.",
            citations=[], confidence="insufficient",
            limitations=["no_evidence_retrieved"],
            retrieval_trace=trace or [])

    prompt = (f"Question: {question}\n\nEvidence units:\n"
              f"{format_evidence(hits)}\n\nAnswer with [[unit_id]] citations.")
    raw = llm.complete(prompt, purpose="answer_synthesis", system=SYNTH_SYSTEM)

    cited = _CITE_RE.findall(raw)
    valid = {str(h["unit_id"]) for h in hits}
    bad = [c for c in cited if c not in valid]
    limitations = []
    if bad or not cited:
        return GroundedAnswer(
            answer="Insufficient evidence: the retrieved material does not "
                   "support a grounded answer to this question. "
                   f"Closest evidence found: "
                   f"{'; '.join(h.get('context_header', '') for h in hits[:3])}",
            citations=[], confidence="insufficient",
            limitations=["citation_validation_failed" if bad else "no_citations"],
            used_llm=True, retrieval_trace=trace or [])

    used = [h for h in hits if str(h["unit_id"]) in set(cited)]
    if any(h.get("status") == "superseded" for h in used):
        limitations.append("answer_uses_historical_versions")
    if any(h.get("status") == "quarantined" for h in used):
        limitations.append("answer_uses_low_confidence_parse")
    return GroundedAnswer(
        answer=raw,
        citations=sorted(set(cited)),
        sources=[source_of(h) for h in used],
        confidence="high" if len(used) >= 2 else "medium",
        limitations=limitations,
        used_llm=True,
        pii_accessed=any(h.get("contains_pii") for h in used),
        versions_used=sorted({h.get("version_label", "current") for h in used}),
        retrieval_trace=trace or [])
