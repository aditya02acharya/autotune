"""Core data models (Pydantic v2). No DB or framework coupling."""
from __future__ import annotations

import hashlib
import uuid
from enum import Enum

from pydantic import BaseModel, Field


class UnitType(str, Enum):
    HEADING = "heading"
    CLAUSE = "clause"
    LIST_BLOCK = "list_block"
    DEFINITION = "definition"
    FOOTNOTE = "footnote"
    APPENDIX_ITEM = "appendix_item"
    TABLE = "table"
    TABLE_REGION = "table_region"
    TABLE_ROW = "table_row"
    TABLE_FACT = "table_fact"
    TABLE_NOTES = "table_notes"
    DOC_SUMMARY = "doc_summary"


EMBEDDABLE_TYPES = {
    UnitType.CLAUSE, UnitType.LIST_BLOCK, UnitType.DEFINITION,
    UnitType.FOOTNOTE, UnitType.APPENDIX_ITEM, UnitType.TABLE,
    UnitType.TABLE_ROW, UnitType.TABLE_NOTES, UnitType.DOC_SUMMARY,
}


class UnitStatus(str, Enum):
    ACTIVE = "active"
    SUPERSEDED = "superseded"
    QUARANTINED = "quarantined"


def sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def make_unit_key(doc_slug: str, unit_type: UnitType, section_path: list[str],
                  table_key: str | None, ordinal_in_scope: int) -> str:
    """Structural identity, stable across versions (see DESIGN.md §2/§6)."""
    raw = "|".join([
        doc_slug, unit_type.value, "/".join(section_path),
        table_key or "", str(ordinal_in_scope),
    ])
    return sha256(raw)


class Provenance(BaseModel):
    doc_slug: str
    doc_title: str
    version_label: str
    source_file_hash: str
    page_start: int | None
    page_end: int | None
    section_path: list[str] = Field(default_factory=list)
    section_titles: list[str] = Field(default_factory=list)


class TableContext(BaseModel):
    table_key: str
    caption: str | None = None
    row_idx: int | None = None
    col_idx: int | None = None
    row_header_path: list[str] | None = None
    col_header_path: list[str] | None = None
    cell_value: str | None = None
    unit_of_measure: str | None = None


class EvidenceUnit(BaseModel):
    unit_type: UnitType
    source_text: str
    provenance: Provenance
    ordinal: int
    unit_key: str = ""
    text_hash: str = ""
    retrieval_text: str = ""
    context_header: str = ""
    parent_key: str | None = None
    table: TableContext | None = None
    term: str | None = None
    contains_pii: bool = False
    pii_types: list[str] = Field(default_factory=list)
    embedding_source: str = "none"
    status: UnitStatus = UnitStatus.ACTIVE
    force_embed: bool = False          # transient: opt a unit into embedding
    unit_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    links: list[tuple[str, str]] = Field(default_factory=list)  # (link_type, dst_key)

    def finalize_hashes(self) -> None:
        self.text_hash = sha256(self.source_text)


class ParsedTable(BaseModel):
    """Canonical table model after grid resolution + stitching (tables.py)."""
    table_key: str
    caption: str | None
    section_path: list[str]
    page_start: int
    page_end: int
    grid: list[list[str]]                 # merged cells expanded
    n_header_rows: int
    n_header_cols: int
    col_paths: list[list[str]]            # per data column
    row_paths: list[list[str]]            # per data row
    notes: list[str]
    confidence: float
    stitched_pages: int = 1
