"""Version diffing with dual identity — pure functions, no DB.

The structural key (`unit_key` = doc|type|section_path|table|ordinal) is
deliberate but brittle alone: insert a clause above, rename a heading, or
renumber a section, and identity breaks even though, in policy-management
reality, *the same obligation simply moved*. So diffing uses two identities:

- **structural**: the stored unit_key (where the unit sits), plus text_hash
  (exact content).
- **lineage**: content similarity (64-bit SimHash over token shingles for
  cheap candidate pairing, token Jaccard/containment for the decision) plus
  nearby structure (unit_type, parent heading titles). Computed at diff
  time from text — no stored column, no schema churn; per-document diff
  sets are small after exact matching, so this stays cheap.

Classification, in resolution order (each unit consumed once):
  unchanged          same key, same hash            -> carry forward
  wording_changed    same key, different hash
  renumbered         different key, SAME hash, same parent heading titles
  moved              different key, SAME hash, different parent
  moved_and_changed  different key, similar content + structure
  split              one old unit -> >=2 new units, each contained in it
  merged             >=2 old units -> one new unit containing them
  added / removed    what remains

"What changed between v3.1 and v3.2?" then gets a faithful answer instead
of a misleading wall of deletes and adds.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass, field

_TOKEN_RE = re.compile(r"[a-z0-9]+")


@dataclass(frozen=True)
class UnitRecord:
    """What the differ needs to know about one unit in one version."""
    text_hash: str
    unit_type: str
    section_titles: tuple[str, ...]
    text: str

    @property
    def tokens(self) -> frozenset[str]:
        return frozenset(_TOKEN_RE.findall(self.text.lower()))

    @property
    def parent_titles(self) -> tuple[str, ...]:
        return tuple(t.lower() for t in self.section_titles if t)


def simhash(text: str, shingle: int = 3) -> int:
    toks = _TOKEN_RE.findall(text.lower())
    grams = [" ".join(toks[i:i + shingle])
             for i in range(max(1, len(toks) - shingle + 1))]
    v = [0] * 64
    for g in grams:
        h = int(hashlib.md5(g.encode()).hexdigest()[:16], 16)
        for b in range(64):
            v[b] += 1 if (h >> b) & 1 else -1
    return sum(1 << b for b in range(64) if v[b] > 0)


def hamming(a: int, b: int) -> int:
    return (a ^ b).bit_count()


def jaccard(a: frozenset, b: frozenset) -> float:
    return len(a & b) / len(a | b) if a or b else 1.0


def containment(part: frozenset, whole: frozenset) -> float:
    return len(part & whole) / len(part) if part else 0.0


@dataclass
class DiffPlan:
    carry_forward: list[str] = field(default_factory=list)
    wording_changed: list[str] = field(default_factory=list)   # same key
    renumbered: dict[str, str] = field(default_factory=dict)   # old -> new key
    moved: dict[str, str] = field(default_factory=dict)        # old -> new key
    moved_and_changed: dict[str, str] = field(default_factory=dict)
    split: dict[str, list[str]] = field(default_factory=dict)  # old -> new keys
    migrated: dict[str, list[str]] = field(default_factory=dict)
    # partial split: an old unit kept its key (wording_changed) but part of
    # its content moved into newly added unit(s); old_key -> new keys
    merged: dict[str, list[str]] = field(default_factory=dict) # new -> old keys
    added: list[str] = field(default_factory=list)
    removed: list[str] = field(default_factory=list)

    # ---- compatibility / persistence helpers ----
    @property
    def changed(self) -> list[str]:                 # legacy alias
        return self.wording_changed

    @property
    def moved_hint(self) -> dict[str, str]:         # legacy alias
        return {**self.renumbered, **self.moved}

    def lineage_pairs(self) -> list[tuple[str, str, str]]:
        """(old_key, new_key, classification) for every traced lineage."""
        out = [(o, n, "renumbered") for o, n in self.renumbered.items()]
        out += [(o, n, "moved") for o, n in self.moved.items()]
        out += [(o, n, "moved_and_changed")
                for o, n in self.moved_and_changed.items()]
        out += [(o, n, "split") for o, ns in self.split.items() for n in ns]
        out += [(o, n, "content_migrated")
                for o, ns in self.migrated.items() for n in ns]
        out += [(o, n, "merged") for n, os_ in self.merged.items() for o in os_]
        out += [(k, k, "wording_changed") for k in self.wording_changed]
        return out

    def stale_old_keys(self) -> list[str]:
        """Old units to supersede (everything not carried forward)."""
        return (self.wording_changed + list(self.renumbered)
                + list(self.moved) + list(self.moved_and_changed)
                + list(self.split)
                + [o for os_ in self.merged.values() for o in os_]
                + self.removed)

    def fresh_new_keys(self) -> set[str]:
        """New units to insert (everything not carried forward)."""
        return (set(self.wording_changed) | set(self.renumbered.values())
                | set(self.moved.values()) | set(self.moved_and_changed.values())
                | {n for ns in self.split.values() for n in ns}
                | set(self.merged) | set(self.added))

    @property
    def is_noop(self) -> bool:
        return not (self.stale_old_keys() or self.added)

    def summary(self) -> dict:
        return {"carried_forward": len(self.carry_forward),
                "wording_changed": len(self.wording_changed),
                "renumbered": len(self.renumbered),
                "moved": len(self.moved),
                "moved_and_changed": len(self.moved_and_changed),
                "split": len(self.split), "merged": len(self.merged),
                "content_migrated": len(self.migrated),
                "added": len(self.added), "removed": len(self.removed)}


def diff_versions(old: dict[str, UnitRecord],
                  new: dict[str, UnitRecord],
                  sim_threshold: float = 0.55,
                  max_hamming: int = 18,
                  containment_threshold: float = 0.7,
                  wording_floor: float = 0.3) -> DiffPlan:
    plan = DiffPlan()
    old_keys, new_keys = set(old), set(new)

    # structural identity: same key — but a key match with *dissimilar*
    # content is an ordinal collision (a different clause now occupies the
    # slot, e.g. after a move), not a rewording. Those defer to lineage.
    for k in old_keys & new_keys:
        if old[k].text_hash == new[k].text_hash:
            plan.carry_forward.append(k)
        elif jaccard(old[k].tokens, new[k].tokens) >= wording_floor:
            plan.wording_changed.append(k)
    structurally_resolved = set(plan.carry_forward) | set(plan.wording_changed)
    rem = {k: old[k] for k in old_keys - structurally_resolved}
    add = {k: new[k] for k in new_keys - structurally_resolved}

    # exact content under a different key: renumbered vs moved
    by_hash: dict[str, list[str]] = {}
    for k, r in rem.items():
        by_hash.setdefault(r.text_hash, []).append(k)
    for nk in sorted(add):
        cands = by_hash.get(add[nk].text_hash)
        if not cands:
            continue
        ok = cands.pop(0)
        if old[ok].parent_titles == add[nk].parent_titles:
            plan.renumbered[ok] = nk
        else:
            plan.moved[ok] = nk
        del rem[ok]
    for nk in list(plan.renumbered.values()) + list(plan.moved.values()):
        add.pop(nk, None)

    # split/merge resolve BEFORE fuzzy 1-1: containment with >=2 parts is
    # the more specific hypothesis; the greedy 1-1 matcher would otherwise
    # claim old->first_part as moved_and_changed and orphan the rest.
    # split: one old covers >=2 new units
    for ok in sorted(rem):
        parts = [nk for nk in add
                 if rem[ok].unit_type == add[nk].unit_type
                 and containment(add[nk].tokens, rem[ok].tokens)
                     >= containment_threshold]
        if len(parts) >= 2:
            covered = frozenset().union(*(add[nk].tokens for nk in parts))
            if containment(rem[ok].tokens, covered) >= containment_threshold:
                plan.split[ok] = sorted(parts)
                del rem[ok]
                for nk in parts:
                    del add[nk]

    # merged: >=2 old covered by one new unit
    for nk in sorted(add):
        parts = [ok for ok in rem
                 if rem[ok].unit_type == add[nk].unit_type
                 and containment(rem[ok].tokens, add[nk].tokens)
                     >= containment_threshold]
        if len(parts) >= 2:
            plan.merged[nk] = sorted(parts)
            del add[nk]
            for ok in parts:
                del rem[ok]

    # lineage identity: fuzzy 1-1 (moved_and_changed), greedy best-first
    sh_old = {k: simhash(r.text) for k, r in rem.items()}
    sh_new = {k: simhash(r.text) for k, r in add.items()}
    scored = []
    for ok, orec in rem.items():
        for nk, nrec in add.items():
            if orec.unit_type != nrec.unit_type:
                continue
            if hamming(sh_old[ok], sh_new[nk]) > max_hamming:
                continue
            sim = jaccard(orec.tokens, nrec.tokens)
            if orec.parent_titles == nrec.parent_titles:
                sim += 0.15                       # nearby-structure bonus
            if sim >= sim_threshold:
                scored.append((sim, ok, nk))
    for _, ok, nk in sorted(scored, reverse=True):
        if ok in rem and nk in add:
            plan.moved_and_changed[ok] = nk
            del rem[ok], add[nk]

    plan.removed = sorted(rem)
    plan.added = sorted(add)

    # partial split: tokens that LEFT a wording_changed unit reappearing
    # nearly intact in an added unit — content migrated, slot retained.
    # (The added unit is still inserted as new; this only adds lineage.)
    for k in plan.wording_changed:
        residual = old[k].tokens - new[k].tokens
        if len(residual) < 5:
            continue
        dests = [nk for nk in plan.added
                 if old[k].unit_type == new[nk].unit_type
                 and containment(residual, new[nk].tokens)
                     >= containment_threshold]
        if dests:
            plan.migrated[k] = sorted(dests)
    return plan
