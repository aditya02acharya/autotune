"""Postgres/pgvector storage layer.

Owns persistence, the incremental version diff application, and the hybrid
(RRF) search SQL. Requires psycopg + a database with schema.sql applied.
All other modules are DB-free so the logic is testable without Postgres.
"""
from __future__ import annotations

import json
from contextlib import contextmanager
from typing import Any, Iterable

import psycopg
from pgvector import Vector
from pgvector.psycopg import register_vector
from psycopg.rows import dict_row

from . import PARSER_VERSION
from .config import Config
from .embeddings import Embedder
from .ingest import ExtractedDocument, IngestionResult
from .models import EMBEDDABLE_TYPES, EvidenceUnit
from .versioning import UnitRecord, diff_versions

HYBRID_SEARCH_SQL = """
WITH params AS (
  SELECT %(query)s::text AS q, %(embedding)s AS e
),
semantic AS (
  SELECT unit_id, row_number() OVER (ORDER BY embedding <=> (SELECT e FROM params)) AS r
  FROM evidence_units
  WHERE status = 'active' AND embedding IS NOT NULL
    AND (%(doc_filter)s::uuid[] IS NULL OR doc_id = ANY(%(doc_filter)s))
    AND (%(type_filter)s::text[] IS NULL OR unit_type = ANY(%(type_filter)s))
    AND (%(section_prefix)s::text[] IS NULL OR section_path[1:cardinality(%(section_prefix)s::text[])] = %(section_prefix)s)
    AND (%(allow_pii)s OR NOT contains_pii)
  ORDER BY embedding <=> (SELECT e FROM params) LIMIT 50
),
keyword AS (
  SELECT unit_id, row_number() OVER (
    ORDER BY ts_rank_cd(tsv, websearch_to_tsquery('english', (SELECT q FROM params))) DESC) AS r
  FROM evidence_units
  WHERE status = 'active'
    AND tsv @@ websearch_to_tsquery('english', (SELECT q FROM params))
    AND (%(doc_filter)s::uuid[] IS NULL OR doc_id = ANY(%(doc_filter)s))
    AND (%(type_filter)s::text[] IS NULL OR unit_type = ANY(%(type_filter)s))
    AND (%(section_prefix)s::text[] IS NULL OR section_path[1:cardinality(%(section_prefix)s::text[])] = %(section_prefix)s)
    AND (%(allow_pii)s OR NOT contains_pii)
  LIMIT 50
),
fused AS (
  SELECT unit_id, SUM(1.0 / (60 + r)) AS score
  FROM (SELECT * FROM semantic UNION ALL SELECT * FROM keyword) hits
  GROUP BY unit_id
)
SELECT eu.*, f.score
FROM fused f JOIN evidence_units_v eu USING (unit_id)
ORDER BY f.score DESC
LIMIT %(k)s;
"""


class Storage:
    def __init__(self, dsn: str, config: Config, embedder: Embedder):
        self.dsn = dsn
        self.config = config
        self.embedder = embedder

    @contextmanager
    def conn(self):
        with psycopg.connect(self.dsn, row_factory=dict_row) as c:
            register_vector(c)  # official pgvector type adapter
            yield c

    @staticmethod
    def _vec(emb: list[float] | None) -> Vector | None:
        return Vector(emb) if emb is not None else None

    # ---------- ingestion persistence (steps 8–10) ----------

    def persist_ingestion(self, doc: ExtractedDocument,
                          result: IngestionResult) -> dict:
        with self.conn() as c:
            doc_id = self._upsert_document(c, doc)
            current = c.execute(
                "SELECT * FROM document_versions WHERE doc_id=%s AND is_current",
                (doc_id,)).fetchone()
            if current and current["source_file_hash"] == doc.file_bytes_hash:
                run_id = self._record_run(c, current["doc_version_id"], "noop",
                                          {"reason": "unchanged_file_hash"}, result)
                c.commit()
                return {"status": "noop", "run_id": str(run_id)}
            if result.status == "failed":
                run_id = self._record_run(c, None, "failed", None, result)
                c.commit()
                return {"status": "failed", "run_id": str(run_id),
                        "gate_failures": result.gate.hard_failures}

            ver_id = c.execute(
                """INSERT INTO document_versions
                   (doc_id, version_label, source_file_hash, page_count)
                   VALUES (%s,%s,%s,%s) RETURNING doc_version_id""",
                (doc_id, doc.version_label, doc.file_bytes_hash,
                 result.metrics["pages"])).fetchone()["doc_version_id"]
            run_id = self._record_run(c, ver_id, "running", None, result)

            old, old_ids = {}, {}
            if current:
                for r in c.execute(
                    """SELECT eu.unit_id, eu.unit_key, eu.text_hash,
                              eu.unit_type, eu.section_titles, eu.source_text
                       FROM evidence_units eu
                       JOIN version_membership vm ON vm.unit_id = eu.unit_id
                       WHERE vm.doc_version_id = %s AND eu.status='active'""",
                        (current["doc_version_id"],)):
                    old[r["unit_key"]] = UnitRecord(
                        text_hash=r["text_hash"], unit_type=r["unit_type"],
                        section_titles=tuple(r["section_titles"] or ()),
                        text=r["source_text"])
                    old_ids[r["unit_key"]] = r["unit_id"]
            new = {u.unit_key: UnitRecord(
                       text_hash=u.text_hash, unit_type=u.unit_type.value,
                       section_titles=tuple(u.provenance.section_titles),
                       text=u.source_text)
                   for u in result.units}
            plan = diff_versions(old, new)

            # carry forward unchanged units: extend membership, no rewrite
            if plan.carry_forward and current:
                c.execute(
                    """INSERT INTO version_membership (unit_id, doc_version_id)
                       SELECT eu.unit_id, %s FROM evidence_units eu
                       JOIN version_membership vm ON vm.unit_id=eu.unit_id
                       WHERE vm.doc_version_id=%s AND eu.unit_key = ANY(%s)
                         AND eu.status='active'""",
                    (ver_id, current["doc_version_id"], plan.carry_forward))
            # supersede everything not carried forward
            stale = plan.stale_old_keys()
            if stale:
                c.execute(
                    """UPDATE evidence_units SET status='superseded',
                       superseded_at=now()
                       WHERE unit_key = ANY(%s) AND status='active'
                         AND doc_id=%s""", (stale, doc_id))
            # tables_meta for this version (overview/table_bundle read this)
            table_ids = self._insert_tables_meta(c, result, ver_id)
            # insert changed + added (only these get fresh embeddings)
            fresh = plan.fresh_new_keys()
            to_insert = [u for u in result.units if u.unit_key in fresh]
            key_to_id = self._insert_units(c, to_insert, doc_id, ver_id,
                                           run_id, table_ids)
            # lineage edges: new unit -> its superseded predecessor, so
            # "what happened to clause 4.2" is a graph walk, not a guess
            for old_key, new_key, kind in plan.lineage_pairs():
                src = key_to_id.get(new_key)
                dst = old_ids.get(old_key)
                if src and dst and src != dst:
                    c.execute(
                        """INSERT INTO unit_links VALUES (%s,%s,'lineage_of',%s)
                           ON CONFLICT DO NOTHING""", (src, dst, kind))

            if current:
                c.execute("UPDATE document_versions SET is_current=false "
                          "WHERE doc_version_id=%s", (current["doc_version_id"],))
            c.execute("UPDATE document_versions SET is_current=true "
                      "WHERE doc_version_id=%s", (ver_id,))
            c.execute("UPDATE ingestion_runs SET status='succeeded', "
                      "finished_at=now(), metrics=%s WHERE run_id=%s",
                      (json.dumps(result.metrics), run_id))
            c.commit()
            return {"status": "succeeded", "run_id": str(run_id),
                    "inserted": len(to_insert),
                    "carried_forward": len(plan.carry_forward),
                    "superseded": len(stale),
                    "diff": plan.summary(),
                    "quarantined": result.gate.quarantined}

    def _insert_tables_meta(self, c, result: IngestionResult,
                            ver_id) -> dict[str, Any]:
        """One tables_meta row per parsed table; returns table_key -> table_id."""
        out: dict[str, Any] = {}
        for t in result.parsed_tables:
            row = c.execute(
                """INSERT INTO tables_meta
                   (doc_version_id, table_key, caption, section_path,
                    page_start, page_end, n_rows, n_cols, header_struct,
                    parse_confidence, stitched_pages, fact_skip_reason)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   RETURNING table_id""",
                (ver_id, t.table_key, t.caption, t.section_path,
                 t.page_start, t.page_end, len(t.grid), 
                 len(t.grid[0]) if t.grid else 0,
                 json.dumps({"col_paths": t.col_paths,
                             "row_paths": t.row_paths,
                             "n_header_rows": t.n_header_rows,
                             "n_header_cols": t.n_header_cols}),
                 t.confidence, t.stitched_pages,
                 result.fact_skip_reasons.get(t.table_key))).fetchone()
            out[t.table_key] = row["table_id"]
        return out

    def _insert_units(self, c, units: list[EvidenceUnit], doc_id, ver_id,
                      run_id, table_ids: dict[str, Any] | None = None):
        table_ids = table_ids or {}
        key_to_id: dict[str, Any] = {}
        embeddable = [u for u in units
                      if (u.unit_type in EMBEDDABLE_TYPES or u.force_embed)
                      and u.status.value == "active"]
        vectors = dict(zip(
            (u.unit_key for u in embeddable),
            self.embedder.embed([u.retrieval_text for u in embeddable]),
        )) if embeddable else {}
        for u in sorted(units, key=lambda u: u.ordinal):  # parents first not guaranteed; resolve after
            row = c.execute(
                """INSERT INTO evidence_units
                   (unit_key, text_hash, doc_id, doc_version_id, unit_type,
                    source_text, retrieval_text, context_header, section_path,
                    section_titles, page_start, page_end, ordinal,
                    row_idx, col_idx, row_header_path, col_header_path,
                    cell_value, unit_of_measure, term, contains_pii, pii_types,
                    embedding_source, status, parser_version, ingestion_run_id,
                    embedding, embedding_model, table_id)
                   VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,
                           %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                   RETURNING unit_id""",
                (u.unit_key, u.text_hash, doc_id, ver_id, u.unit_type.value,
                 u.source_text, u.retrieval_text, u.context_header,
                 u.provenance.section_path, u.provenance.section_titles,
                 u.provenance.page_start, u.provenance.page_end, u.ordinal,
                 u.table.row_idx if u.table else None,
                 u.table.col_idx if u.table else None,
                 u.table.row_header_path if u.table else None,
                 u.table.col_header_path if u.table else None,
                 u.table.cell_value if u.table else None,
                 u.table.unit_of_measure if u.table else None,
                 u.term, u.contains_pii, u.pii_types,
                 u.embedding_source, u.status.value, PARSER_VERSION, run_id,
                 self._vec(vectors.get(u.unit_key)), self.embedder.model_name,
                 table_ids.get(u.table.table_key) if u.table else None,
                 )).fetchone()
            key_to_id[u.unit_key] = row["unit_id"]
            c.execute("INSERT INTO version_membership VALUES (%s,%s)",
                      (row["unit_id"], ver_id))
        # second pass: parent links (parents may be carried-forward rows)
        for u in units:
            if not u.parent_key:
                continue
            c.execute(
                """UPDATE evidence_units SET parent_unit_id = COALESCE(
                     %s, (SELECT unit_id FROM evidence_units
                          WHERE unit_key=%s AND status='active' LIMIT 1))
                   WHERE unit_id=%s""",
                (key_to_id.get(u.parent_key), u.parent_key,
                 key_to_id[u.unit_key]))
        return key_to_id

    def _upsert_document(self, c, doc: ExtractedDocument):
        return c.execute(
            """INSERT INTO documents (slug, title) VALUES (%s,%s)
               ON CONFLICT (slug) DO UPDATE SET title=EXCLUDED.title
               RETURNING doc_id""",
            (doc.doc_slug, doc.doc_title)).fetchone()["doc_id"]

    def _record_run(self, c, ver_id, status, extra, result: IngestionResult):
        return c.execute(
            """INSERT INTO ingestion_runs
               (doc_version_id, parser_version, status, metrics, gate_failures)
               VALUES (%s,%s,%s,%s,%s) RETURNING run_id""",
            (ver_id, PARSER_VERSION, status,
             json.dumps({**result.metrics, **(extra or {})}),
             json.dumps({"hard": result.gate.hard_failures,
                         "quarantined": result.gate.quarantined}),
             )).fetchone()["run_id"]

    # ---------- retrieval primitives ----------

    def hybrid_search(self, query: str, k: int = 10, *,
                      doc_ids: list[str] | None = None,
                      unit_types: list[str] | None = None,
                      section_prefix: list[str] | None = None,
                      allow_pii: bool = False) -> list[dict]:
        emb = self.embedder.embed([query])[0]
        with self.conn() as c:
            return c.execute(HYBRID_SEARCH_SQL, {
                "query": query, "embedding": Vector(emb), "k": k,
                "doc_filter": doc_ids, "type_filter": unit_types,
                "section_prefix": section_prefix, "allow_pii": allow_pii,
            }).fetchall()

    def exact_term_search(self, term: str, k: int = 10) -> list[dict]:
        with self.conn() as c:
            return c.execute(
                """SELECT *, similarity(source_text, %s) AS score
                   FROM evidence_units_v
                   WHERE status='active' AND source_text %% %s
                   ORDER BY score DESC LIMIT %s""", (term, term, k)).fetchall()

    def section_lookup(self, doc_slug: str, section_path: list[str],
                       version_label: str | None = None) -> list[dict]:
        with self.conn() as c:
            return c.execute(
                """SELECT eu.* FROM evidence_units_v eu
                   JOIN version_membership vm ON vm.unit_id = eu.unit_id
                   JOIN document_versions dv ON dv.doc_version_id = vm.doc_version_id
                   WHERE eu.doc_slug=%s
                     AND eu.section_path[1:cardinality(%s::text[])] = %s
                     AND eu.status != 'quarantined'
                     AND (%s::text IS NULL AND dv.is_current
                          OR dv.version_label = %s)
                   ORDER BY eu.ordinal""",
                (doc_slug, section_path, section_path,
                 version_label, version_label)).fetchall()

    def neighbors(self, unit_id: str, before: int = 1, after: int = 1) -> list[dict]:
        with self.conn() as c:
            return c.execute(
                """WITH anchor AS (SELECT doc_version_id, ordinal
                                   FROM evidence_units WHERE unit_id=%s)
                   SELECT eu.* FROM evidence_units_v eu, anchor a
                   WHERE eu.doc_version_id=a.doc_version_id
                     AND eu.ordinal BETWEEN a.ordinal-%s AND a.ordinal+%s
                     AND eu.status='active'
                   ORDER BY eu.ordinal""", (unit_id, before, after)).fetchall()

    def table_fact(self, table_key: str, row_path: list[str],
                   col_path: list[str]) -> list[dict]:
        with self.conn() as c:
            return c.execute(
                """SELECT * FROM evidence_units_v
                   WHERE unit_type='table_fact' AND status='active'
                     AND row_header_path @> %s AND col_header_path @> %s
                     AND retrieval_text LIKE '%%' || %s || '%%'
                   LIMIT 20""",
                (row_path, col_path, table_key.split(":")[-1])).fetchall()

    def compare_versions(self, doc_slug: str, v_a: str, v_b: str) -> dict:
        with self.conn() as c:
            rows = c.execute(
                """SELECT dv.version_label, eu.unit_key, eu.text_hash,
                          eu.unit_id, eu.unit_type, eu.section_titles,
                          eu.source_text, eu.context_header
                   FROM evidence_units eu
                   JOIN version_membership vm ON vm.unit_id = eu.unit_id
                   JOIN document_versions dv ON dv.doc_version_id = vm.doc_version_id
                   JOIN documents d ON d.doc_id = dv.doc_id
                   WHERE d.slug=%s AND dv.version_label IN (%s, %s)""",
                (doc_slug, v_a, v_b)).fetchall()

        def recs(label):
            return {r["unit_key"]: UnitRecord(
                        text_hash=r["text_hash"], unit_type=r["unit_type"],
                        section_titles=tuple(r["section_titles"] or ()),
                        text=r["source_text"])
                    for r in rows if r["version_label"] == label}
        ctx = {r["unit_key"]: r["context_header"] for r in rows}
        plan = diff_versions(recs(v_a), recs(v_b))

        def loc(keys):
            return [{"unit_key": k, "where": ctx.get(k, "")} for k in keys]
        return {"summary": plan.summary(),
                "wording_changed": loc(plan.wording_changed),
                "renumbered": [{"from": ctx.get(o, o), "to": ctx.get(n, n)}
                               for o, n in plan.renumbered.items()],
                "moved": [{"from": ctx.get(o, o), "to": ctx.get(n, n)}
                          for o, n in plan.moved.items()],
                "moved_and_changed": [{"from": ctx.get(o, o),
                                       "to": ctx.get(n, n)}
                                      for o, n in plan.moved_and_changed.items()],
                "split": [{"from": ctx.get(o, o),
                           "into": [ctx.get(n, n) for n in ns]}
                          for o, ns in plan.split.items()],
                "merged": [{"into": ctx.get(n, n),
                            "from": [ctx.get(o, o) for o in os_]}
                           for n, os_ in plan.merged.items()],
                "content_migrated": [{"from": ctx.get(o, o),
                                      "to": [ctx.get(n, n) for n in ns]}
                                     for o, ns in plan.migrated.items()],
                "added": loc(plan.added), "removed": loc(plan.removed)}

    # ---------- agent navigation (orientation & expansion) ----------

    def list_documents(self) -> list[dict]:
        with self.conn() as c:
            return c.execute(
                """SELECT d.slug, d.title, d.classification,
                          dv.version_label AS current_version,
                          dv.effective_date, dv.page_count, dv.ingested_at,
                          count(vm.unit_id) AS n_units
                   FROM documents d
                   JOIN document_versions dv
                        ON dv.doc_id = d.doc_id AND dv.is_current
                   LEFT JOIN version_membership vm
                        ON vm.doc_version_id = dv.doc_version_id
                   GROUP BY d.slug, d.title, d.classification,
                            dv.version_label, dv.effective_date,
                            dv.page_count, dv.ingested_at
                   ORDER BY d.slug""").fetchall()

    def document_overview(self, doc_slug: str,
                          version_label: str | None = None) -> dict | None:
        """Doc summary + section outline — lets an agent orient in a document
        before searching within it."""
        with self.conn() as c:
            ver = c.execute(
                """SELECT dv.doc_version_id, dv.version_label, d.title,
                          dv.page_count
                   FROM document_versions dv JOIN documents d USING (doc_id)
                   WHERE d.slug=%s
                     AND (%s::text IS NULL AND dv.is_current
                          OR dv.version_label = %s)""",
                (doc_slug, version_label, version_label)).fetchone()
            if not ver:
                return None
            summary = c.execute(
                """SELECT eu.retrieval_text FROM evidence_units eu
                   JOIN version_membership vm USING (unit_id)
                   WHERE vm.doc_version_id=%s AND eu.unit_type='doc_summary'
                     AND eu.status='active' LIMIT 1""",
                (ver["doc_version_id"],)).fetchone()
            outline = c.execute(
                """SELECT eu.unit_id, eu.section_path, eu.section_titles,
                          eu.page_start, eu.ordinal,
                          eu.doc_slug, eu.doc_title, eu.version_label
                   FROM evidence_units_v eu
                   JOIN version_membership vm USING (unit_id)
                   WHERE vm.doc_version_id=%s AND eu.unit_type='heading'
                     AND eu.status != 'quarantined'
                   ORDER BY eu.ordinal""",
                (ver["doc_version_id"],)).fetchall()
            tables = c.execute(
                """SELECT table_key, caption, section_path, page_start,
                          page_end, n_rows, n_cols, parse_confidence
                   FROM tables_meta WHERE doc_version_id=%s
                   ORDER BY page_start""",
                (ver["doc_version_id"],)).fetchall()
        return {"doc_slug": doc_slug, "title": ver["title"],
                "version": ver["version_label"], "page_count": ver["page_count"],
                "summary": summary["retrieval_text"] if summary else None,
                "outline": outline, "tables": tables}

    def expand_unit(self, unit_id: str, before: int = 2, after: int = 2,
                    include_parent: bool = True,
                    include_links: bool = True) -> dict | None:
        """One-call context expansion around a hit/citation: the unit, its
        reading-order neighbors, its parent (e.g. section heading or table),
        and linked units (footnotes, notes, continuations, references)."""
        with self.conn() as c:
            unit = c.execute(
                "SELECT * FROM evidence_units_v WHERE unit_id=%s",
                (unit_id,)).fetchone()
            if not unit:
                return None
            parent = None
            if include_parent and unit["parent_unit_id"]:
                parent = c.execute(
                    "SELECT * FROM evidence_units_v WHERE unit_id=%s",
                    (unit["parent_unit_id"],)).fetchone()
            links = []
            if include_links:
                links = c.execute(
                    """SELECT ul.link_type, ul.dst_unit_id AS unit_id,
                              'out' AS direction, eu.unit_type,
                              eu.retrieval_text, eu.context_header,
                              eu.doc_slug, eu.doc_title, eu.version_label,
                              eu.section_path, eu.page_start, eu.page_end
                       FROM unit_links ul
                       JOIN evidence_units_v eu ON eu.unit_id = ul.dst_unit_id
                       WHERE ul.src_unit_id=%s
                       UNION ALL
                       SELECT ul.link_type, ul.src_unit_id AS unit_id,
                              'in' AS direction, eu.unit_type,
                              eu.retrieval_text, eu.context_header,
                              eu.doc_slug, eu.doc_title, eu.version_label,
                              eu.section_path, eu.page_start, eu.page_end
                       FROM unit_links ul
                       JOIN evidence_units_v eu ON eu.unit_id = ul.src_unit_id
                       WHERE ul.dst_unit_id=%s""",
                    (unit_id, unit_id)).fetchall()
        return {"unit": unit, "parent": parent,
                "neighbors": self.neighbors(unit_id, before, after),
                "links": links}

    def table_bundle(self, table_key: str,
                     doc_slug: str | None = None) -> dict | None:
        """A whole table as one bundle: metadata + header structure + row
        units + notes, for questions a single cell fact can't answer."""
        with self.conn() as c:
            meta = c.execute(
                """SELECT tm.*, d.slug, dv.version_label
                   FROM tables_meta tm
                   JOIN document_versions dv USING (doc_version_id)
                   JOIN documents d USING (doc_id)
                   WHERE tm.table_key=%s AND dv.is_current
                     AND (%s::text IS NULL OR d.slug=%s)""",
                (table_key, doc_slug, doc_slug)).fetchone()
            if not meta:
                return None
            rows = c.execute(
                """SELECT unit_id, unit_type, retrieval_text, row_idx,
                          row_header_path, page_start, page_end,
                          doc_slug, doc_title, version_label, section_path
                   FROM evidence_units_v
                   WHERE table_id=%s AND status='active'
                     AND unit_type IN ('table_row','table_notes')
                   ORDER BY unit_type, row_idx NULLS LAST""",
                (meta["table_id"],)).fetchall()
        return {"meta": meta,
                "rows": [r for r in rows if r["unit_type"] == "table_row"],
                "notes": [r for r in rows if r["unit_type"] == "table_notes"]}

    # ---------- Topic & Reference faces (corpus-level, run after ingests) ----------

    def rebuild_corpus_faces(self, guarded_llm=None) -> dict:
        """Rebuild the cross-document layers over all active units:
        topics (Topic face), then uses_term / references_document /
        same_topic / potentially_conflicting edges (Reference face).

        Topic summaries are regenerated only when a topic's member_hash
        changed — with `guarded_llm=None` this is entirely LLM-free."""
        from .linking import (build_abbreviation_table,
                              build_definition_index, conflict_candidates,
                              divergent_definitions, link_doc_references,
                              link_term_usages)
        from .topics import build_topics, same_topic_edges

        with self.conn() as c:
            rows = c.execute(
                """SELECT eu.*, d.slug, d.title FROM evidence_units eu
                   JOIN documents d USING (doc_id)
                   JOIN document_versions dv ON dv.doc_version_id = eu.doc_version_id
                   WHERE eu.status='active' AND dv.is_current""").fetchall()
        units = [self._row_to_unit(r) for r in rows]
        id_by_key = {r["unit_key"]: r["unit_id"] for r in rows}
        doc_titles = {r["slug"]: r["title"] for r in rows}
        summary_by_doc = {r["slug"]: r["unit_key"] for r in rows
                          if r["unit_type"] == "doc_summary"}

        defs = build_definition_index(units)
        abbrs = build_abbreviation_table(units)
        links = link_term_usages(units, defs, abbreviations=abbrs)
        links += divergent_definitions(defs)
        links += link_doc_references(units, doc_titles,
                                     summary_key_by_doc=summary_by_doc)

        old_hashes = {}
        with self.conn() as c:
            old_hashes = {r["member_hash"]: r["topic_id"] for r in
                          c.execute("SELECT topic_id, member_hash FROM topics")}
        topics = build_topics(units, self.embedder, guarded_llm=None)
        units_by_key = {u.unit_key: u for u in units}
        n_summarized = 0
        for t in topics:
            if guarded_llm is not None and t.member_hash not in old_hashes:
                joined = "\n---\n".join(
                    units_by_key[k].retrieval_text[:400]
                    for k in t.member_keys[:12])
                t.summary_text = guarded_llm.complete(
                    "Summarise, in 3 neutral sentences, what these policy "
                    "excerpts collectively govern. Do not resolve any "
                    "disagreements between them; note them.\n\n" + joined,
                    purpose="topic_summary")
                t.summary_method = "llm"
                n_summarized += 1

        # same_topic + conflicts derived from topic membership
        from .linking import CrossDocLink
        for t in topics:
            for a, b in same_topic_edges(t):
                links.append(CrossDocLink(
                    src_unit_key=a, dst_unit_key=b, link_type="same_topic",
                    evidence=f"topic: {t.label}"))
            links += conflict_candidates(
                [units_by_key[k] for k in t.member_keys])

        with self.conn() as c:
            c.execute("DELETE FROM topic_membership")
            c.execute("DELETE FROM topics")
            for t in topics:
                tid = c.execute(
                    """INSERT INTO topics (label, summary_text, summary_method,
                         member_hash, n_members, n_documents, embedding)
                       VALUES (%s,%s,%s,%s,%s,%s,%s) RETURNING topic_id""",
                    (t.label, t.summary_text, t.summary_method, t.member_hash,
                     len(t.member_keys), t.n_documents,
                     Vector(t.centroid))).fetchone()["topic_id"]
                for k, sim in zip(t.member_keys, t.similarities):
                    c.execute("INSERT INTO topic_membership VALUES (%s,%s,%s)",
                              (tid, id_by_key[k], sim))
            c.execute("""DELETE FROM unit_links WHERE link_type IN
                         ('uses_term','references_document','same_topic',
                          'potentially_conflicting','divergent_definition')""")
            n_links = 0
            for l in links:
                src, dst = id_by_key.get(l.src_unit_key), id_by_key.get(l.dst_unit_key)
                if src and dst:
                    c.execute(
                        """INSERT INTO unit_links VALUES (%s,%s,%s,%s)
                           ON CONFLICT DO NOTHING""",
                        (src, dst, l.link_type, l.evidence))
                    n_links += 1
            c.commit()
        return {"topics": len(topics), "links": n_links,
                "llm_summaries": n_summarized,
                "by_type": dict(__import__("collections").Counter(
                    l.link_type for l in links))}

    def _row_to_unit(self, r: dict) -> "EvidenceUnit":
        from .models import Provenance, UnitStatus, UnitType
        return EvidenceUnit(
            unit_type=UnitType(r["unit_type"]), source_text=r["source_text"],
            retrieval_text=r["retrieval_text"],
            context_header=r["context_header"], ordinal=r["ordinal"],
            unit_key=r["unit_key"], text_hash=r["text_hash"],
            term=r["term"], status=UnitStatus(r["status"]),
            unit_id=str(r["unit_id"]),
            provenance=Provenance(
                doc_slug=r["slug"], doc_title=r["title"],
                version_label="", source_file_hash="",
                page_start=r["page_start"], page_end=r["page_end"],
                section_path=list(r["section_path"] or []),
                section_titles=list(r["section_titles"] or [])))

    def browse_topics(self, query: str | None = None, k: int = 20) -> list[dict]:
        with self.conn() as c:
            if query:
                emb = self.embedder.embed([query])[0]
                return c.execute(
                    """SELECT topic_id, label, summary_text, summary_method,
                              n_members, n_documents,
                              1 - (embedding <=> %s) AS score
                       FROM topics ORDER BY embedding <=> %s LIMIT %s""",
                    (Vector(emb), Vector(emb), k)).fetchall()
            return c.execute(
                """SELECT topic_id, label, summary_text, summary_method,
                          n_members, n_documents
                   FROM topics ORDER BY n_documents DESC, n_members DESC
                   LIMIT %s""", (k,)).fetchall()

    def topic_members(self, topic_id: str, k: int = 30) -> list[dict]:
        with self.conn() as c:
            return c.execute(
                """SELECT eu.unit_id, eu.unit_type, eu.retrieval_text,
                          eu.context_header, eu.section_path,
                          eu.doc_slug, eu.doc_title, eu.version_label,
                          eu.page_start, eu.page_end, tm.similarity
                   FROM topic_membership tm
                   JOIN evidence_units_v eu USING (unit_id)
                   WHERE tm.topic_id=%s
                   ORDER BY tm.similarity DESC LIMIT %s""",
                (topic_id, k)).fetchall()

    def get_related(self, unit_id: str,
                    link_types: list[str] | None = None) -> list[dict]:
        """Pivot through the Reference face from one unit: term definitions
        it uses, documents it cites, same-topic peers, conflict candidates."""
        with self.conn() as c:
            return c.execute(
                """SELECT ul.link_type, ul.evidence, eu.unit_id,
                          eu.unit_type, eu.retrieval_text, eu.context_header,
                          eu.doc_slug, eu.doc_title, eu.version_label,
                          eu.section_path, eu.page_start, eu.page_end,
                          CASE WHEN ul.src_unit_id=%s THEN 'out' ELSE 'in' END
                            AS direction
                   FROM unit_links ul
                   JOIN evidence_units_v eu
                     ON eu.unit_id = CASE WHEN ul.src_unit_id=%s
                                          THEN ul.dst_unit_id
                                          ELSE ul.src_unit_id END
                   WHERE (ul.src_unit_id=%s OR ul.dst_unit_id=%s)
                     AND (%s::text[] IS NULL OR ul.link_type = ANY(%s))
                   ORDER BY ul.link_type""",
                (unit_id, unit_id, unit_id, unit_id,
                 link_types, link_types)).fetchall()

    def list_conflict_candidates(self) -> list[dict]:
        with self.conn() as c:
            return c.execute(
                """SELECT ul.link_type, ul.evidence,
                          a.unit_id AS src_id, a.doc_slug AS src_doc,
                          a.version_label AS src_version,
                          a.section_path AS src_section,
                          a.page_start AS src_page,
                          a.retrieval_text AS src_text,
                          b.unit_id AS dst_id, b.doc_slug AS dst_doc,
                          b.version_label AS dst_version,
                          b.section_path AS dst_section,
                          b.page_start AS dst_page,
                          b.retrieval_text AS dst_text
                   FROM unit_links ul
                   JOIN evidence_units_v a ON a.unit_id = ul.src_unit_id
                   JOIN evidence_units_v b ON b.unit_id = ul.dst_unit_id
                   WHERE ul.link_type IN ('potentially_conflicting',
                                          'divergent_definition')""").fetchall()

    def trace_citation(self, unit_id: str) -> dict | None:
        with self.conn() as c:
            return c.execute(
                """SELECT eu.unit_id, eu.unit_key, eu.unit_type, eu.status,
                          eu.section_path, eu.section_titles,
                          eu.page_start, eu.page_end, eu.ordinal,
                          eu.row_header_path, eu.col_header_path,
                          d.slug, d.title, dv.version_label,
                          dv.source_file_hash, eu.parser_version,
                          eu.ingestion_run_id, eu.created_at
                   FROM evidence_units eu
                   JOIN documents d USING (doc_id)
                   JOIN document_versions dv ON dv.doc_version_id = eu.doc_version_id
                   WHERE eu.unit_id=%s""", (unit_id,)).fetchone()

    def audit_access(self, principal: str, unit_ids: Iterable[str],
                     action: str = "retrieved") -> None:
        with self.conn() as c:
            for uid in unit_ids:
                c.execute("INSERT INTO access_audit (principal, unit_id, action)"
                          " VALUES (%s,%s,%s)", (principal, uid, action))
            c.commit()
