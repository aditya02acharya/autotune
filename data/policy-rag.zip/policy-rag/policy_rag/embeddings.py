"""Embedding interface.

Production path: `VLLMEmbedder` talks to a vLLM-hosted embedding model over
its OpenAI-compatible `/v1/embeddings` endpoint, using the official `openai`
client with `tenacity` retries — suitable for air-gapped deployments where
the vLLM server is the only embedding dependency.

Dev/CI path: `HashEmbedder` is a deterministic local stub with no network
or model dependency, so the pipeline and tests run anywhere.
"""
from __future__ import annotations

import hashlib
import math
import re
from typing import Protocol

from tenacity import retry, stop_after_attempt, wait_exponential


class Embedder(Protocol):
    model_name: str
    dim: int
    def embed(self, texts: list[str]) -> list[list[float]]: ...


class VLLMEmbedder:
    """Embeddings from a vLLM server's OpenAI-compatible endpoint."""

    def __init__(self, base_url: str, model: str, dim: int,
                 api_key: str = "EMPTY", batch_size: int = 64):
        from openai import OpenAI  # lazy: not needed for local dev/tests
        self._client = OpenAI(base_url=base_url, api_key=api_key)
        self.model_name = model
        self.dim = dim
        self._batch_size = batch_size

    @retry(stop=stop_after_attempt(4),
           wait=wait_exponential(multiplier=0.5, max=8), reraise=True)
    def _call(self, batch: list[str]) -> list[list[float]]:
        resp = self._client.embeddings.create(model=self.model_name,
                                              input=batch)
        # API may return out of order; sort by index.
        ordered = sorted(resp.data, key=lambda d: d.index)
        return [d.embedding for d in ordered]

    def embed(self, texts: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        for i in range(0, len(texts), self._batch_size):
            vectors = self._call(texts[i:i + self._batch_size])
            for v in vectors:
                if len(v) != self.dim:
                    raise ValueError(
                        f"Embedding dim {len(v)} != configured {self.dim}")
            out.extend(vectors)
        return out


class HashEmbedder:
    """Deterministic bag-of-hashed-ngrams embedding. Not semantically strong —
    a stand-in for local dev/CI with stable cosine behaviour for overlap."""

    def __init__(self, dim: int = 768):
        self.model_name = f"stub-hash-{dim}"
        self.dim = dim

    def _tokens(self, text: str) -> list[str]:
        return re.findall(r"[a-z0-9]+", text.lower())

    def embed(self, texts: list[str]) -> list[list[float]]:
        out = []
        for text in texts:
            v = [0.0] * self.dim
            for tok in self._tokens(text):
                h = int(hashlib.md5(tok.encode()).hexdigest(), 16)
                v[h % self.dim] += 1.0
            norm = math.sqrt(sum(x * x for x in v)) or 1.0
            out.append([x / norm for x in v])
        return out


def make_embedder(config) -> Embedder:
    """Build the configured embedder: vLLM endpoint, or stub for dev/CI."""
    if config.embedding_model.startswith("stub-hash"):
        return HashEmbedder(config.embedding_dim)
    return VLLMEmbedder(base_url=config.vllm_base_url,
                        model=config.embedding_model,
                        dim=config.embedding_dim,
                        api_key=config.vllm_api_key)
