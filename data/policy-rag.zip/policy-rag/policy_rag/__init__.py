"""policy_rag — structure-aware RAG for policy documents on Postgres/pgvector."""

PARSER_VERSION = "1.0.0"
