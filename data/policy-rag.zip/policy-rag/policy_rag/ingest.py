"""Ingestion pipeline: PDF -> Evidence Units -> gates -> diff -> persist.

PDF extraction uses pdfplumber when available; the rest of the pipeline takes
plain pages/lines + table fragments, so tests and other extractors can feed
it directly.
"""
from __future__ import annotations

import hashlib
from dataclasses import dataclass, field

from . import PARSER_VERSION
from .config import Config
from .contextualize import contextualize, serialize_row, serialize_table
from .models import (EMBEDDABLE_TYPES, EvidenceUnit, ParsedTable, Provenance,
                     TableContext, UnitType, make_unit_key)
from .normalize import normalize_text, strip_page_furniture
from .pii import apply_pii_policy, detect_pii
from .quality import GateResult, compute_metrics, run_gates
from .structure import Block, parse_blocks
from .tables import RawTableFragment, iter_facts, parse_table

_KIND_TO_TYPE = {
    "heading": UnitType.HEADING, "appendix_heading": UnitType.HEADING,
    "paragraph": UnitType.CLAUSE, "list_block": UnitType.LIST_BLOCK,
    "definition": UnitType.DEFINITION, "footnote": UnitType.FOOTNOTE,
    "appendix_item": UnitType.APPENDIX_ITEM,
}


@dataclass
class ExtractedDocument:
    """Extractor-agnostic intermediate: pages of lines + table fragments."""
    doc_slug: str
    doc_title: str
    version_label: str
    file_bytes_hash: str
    pages: list[list[str]]
    tables: list[tuple[list[str], str | None, list[RawTableFragment]]] = field(
        default_factory=list)  # (section_path, caption, fragments)


def extract_pdf(path: str, doc_slug: str, doc_title: str,
                version_label: str) -> ExtractedDocument:
    """Real-PDF entry point (requires pdfplumber)."""
    import pdfplumber  # local import: optional dependency

    with open(path, "rb") as f:
        file_hash = hashlib.sha256(f.read()).hexdigest()
    pages, tables = [], []
    with pdfplumber.open(path) as pdf:
        for pno, page in enumerate(pdf.pages, start=1):
            text = page.extract_text() or ""
            pages.append(text.splitlines())
            for ti, raw in enumerate(page.extract_tables() or []):
                tables.append(([], None, [RawTableFragment(page=pno, rows=raw)]))
    # NOTE: production extraction also stitches cross-page fragments by
    # x-position alignment; see tables.stitch_fragments.
    return ExtractedDocument(doc_slug, doc_title, version_label, file_hash,
                             pages, tables)


def _split_oversized(text: str, limit: int) -> list[str]:
    if len(text) <= limit:
        return [text]
    parts, buf = [], ""
    for sent in text.replace("\n", " ").split(". "):
        candidate = f"{buf}. {sent}".strip(". ") if buf else sent
        if len(candidate) > limit and buf:
            parts.append(buf.strip() + ".")
            buf = sent
        else:
            buf = candidate
    if buf.strip():
        parts.append(buf.strip())
    return parts


def build_units(doc: ExtractedDocument, config: Config
                ) -> tuple[list[EvidenceUnit], dict[str, float], list[ParsedTable]]:
    """Steps 2–6: de-noise, structure, tables, PII, unitize, contextualize."""
    pages = strip_page_furniture(
        doc.pages, config.gates.header_footer_page_ratio)
    pages = [[normalize_text(ln) for ln in lines] for lines in pages]
    blocks = parse_blocks(pages)

    units: list[EvidenceUnit] = []
    ordinal = 0
    scope_counters: dict[tuple, int] = {}
    heading_key_by_path: dict[tuple, str] = {}

    def new_unit(utype: UnitType, text: str, block_prov: Provenance,
                 scope_extra: str = "", **kw) -> EvidenceUnit:
        nonlocal ordinal
        scope = (utype.value, tuple(block_prov.section_path), scope_extra)
        scope_counters[scope] = scope_counters.get(scope, 0) + 1
        key = make_unit_key(doc.doc_slug, utype, block_prov.section_path,
                            scope_extra or None, scope_counters[scope])
        u = EvidenceUnit(unit_type=utype, source_text=text,
                         provenance=block_prov, ordinal=ordinal,
                         unit_key=key, **kw)
        ordinal += 1
        u.finalize_hashes()
        units.append(u)
        return u

    def prov(section_path, section_titles, p_start, p_end) -> Provenance:
        return Provenance(doc_slug=doc.doc_slug, doc_title=doc.doc_title,
                          version_label=doc.version_label,
                          source_file_hash=doc.file_bytes_hash,
                          page_start=p_start, page_end=p_end,
                          section_path=list(section_path),
                          section_titles=list(section_titles))

    def attach_pii_and_context(u: EvidenceUnit) -> None:
        findings = detect_pii(u.source_text)
        if findings:
            u.contains_pii = True
            u.pii_types = sorted({f.pii_type for f in findings})
        masked, _ = apply_pii_policy(u.source_text, findings, config.pii)
        contextualize(u, masked if config.pii.embed_masked else u.source_text)
        if u.unit_type in EMBEDDABLE_TYPES:
            u.embedding_source = ("masked" if config.pii.embed_masked
                                  and findings else
                                  "raw" if findings else "masked")

    # prose blocks
    for b in blocks:
        utype = _KIND_TO_TYPE[b.kind]
        p = prov(b.section_path, b.section_titles, b.page_start, b.page_end)
        if utype == UnitType.HEADING:
            u = new_unit(utype, b.text, p)
            heading_key_by_path[tuple(b.section_path)] = u.unit_key
            attach_pii_and_context(u)
            continue
        for piece in _split_oversized(b.text, config.gates.max_unit_chars):
            u = new_unit(utype, piece, p, term=b.term)
            u.parent_key = heading_key_by_path.get(tuple(b.section_path))
            attach_pii_and_context(u)

    # tables: whole table + rows + facts + notes, all linked
    table_conf: dict[str, float] = {}
    fact_skip_reasons: dict[str, str | None] = {}
    parsed_tables: list[ParsedTable] = []
    for tidx, (section_path, caption, fragments) in enumerate(doc.tables, start=1):
        table_key = f"table:{'/'.join(section_path)}:{tidx}"
        t: ParsedTable = parse_table(fragments, table_key, list(section_path),
                                     caption)
        table_conf[table_key] = t.confidence
        parsed_tables.append(t)
        titles = [""] * len(section_path)
        p = prov(section_path, titles, t.page_start, t.page_end)
        tu = new_unit(UnitType.TABLE, serialize_table(t), p,
                      scope_extra=table_key,
                      table=TableContext(table_key=table_key, caption=caption))
        tu.parent_key = heading_key_by_path.get(tuple(section_path))
        attach_pii_and_context(tu)
        if t.notes:
            nu = new_unit(UnitType.TABLE_NOTES, "\n".join(t.notes), p,
                          scope_extra=table_key,
                          table=TableContext(table_key=table_key, caption=caption))
            nu.parent_key = tu.unit_key
            attach_pii_and_context(nu)
        for ri in range(len(t.row_paths)):
            row_text = serialize_row(t, ri)
            if not row_text.strip():
                continue
            ru = new_unit(UnitType.TABLE_ROW, row_text, p,
                          scope_extra=table_key,
                          table=TableContext(table_key=table_key, caption=caption,
                                             row_idx=ri,
                                             row_header_path=t.row_paths[ri]))
            ru.parent_key = tu.unit_key
            attach_pii_and_context(ru)
        n_cells = max(0, (len(t.grid) - t.n_header_rows)) * \
            max(0, (len(t.grid[0]) - t.n_header_cols) if t.grid else 0)
        fp = config.facts
        skip_reason = None
        if t.confidence < fp.min_fact_confidence:
            skip_reason = f"low_confidence:{t.confidence:.2f}"
        elif n_cells > fp.max_fact_cells:
            skip_reason = f"too_large:{n_cells}_cells"
        fact_skip_reasons[table_key] = skip_reason
        embed_facts = (skip_reason is None
                       and n_cells <= fp.embed_fact_max_cells
                       and t.confidence >= fp.embed_fact_min_confidence)
        for ri, cj, row_path, col_path, value, uom in \
                ([] if skip_reason else iter_facts(t)):
            fu = new_unit(
                UnitType.TABLE_FACT,
                f"{' › '.join(row_path)} | {' › '.join(col_path)}"
                f"{f' ({uom})' if uom else ''} = {value}",
                p, scope_extra=f"{table_key}:r{ri}c{cj}",
                table=TableContext(table_key=table_key, caption=caption, row_idx=ri,
                                   col_idx=cj, row_header_path=row_path,
                                   col_header_path=col_path, cell_value=value,
                                   unit_of_measure=uom))
            fu.parent_key = tu.unit_key
            fu.force_embed = embed_facts
            attach_pii_and_context(fu)

    # deterministic document summary (no LLM): title, top-level sections,
    # table captions — enough for an agent to orient without reading the doc.
    # NB: version-invariant on purpose (the context header carries the
    # version), so an unchanged document still diffs as a clean noop.
    top = [b for b in blocks
           if b.kind == "heading" and len(b.section_path) == 1]
    lines = [f"{doc.doc_title}: {len(doc.pages)} pages, "
             f"{len(top)} top-level sections."]
    if top:
        lines.append("Sections: " + "; ".join(
            f"{'.'.join(b.section_path)} {b.text}".strip() for b in top))
    if parsed_tables:
        lines.append("Tables: " + "; ".join(
            t.caption or t.table_key for t in parsed_tables))
    su = new_unit(UnitType.DOC_SUMMARY, "\n".join(lines),
                  prov([], [], 1, len(doc.pages)))
    attach_pii_and_context(su)

    return units, table_conf, parsed_tables, fact_skip_reasons


@dataclass
class IngestionResult:
    status: str                    # succeeded | failed | noop
    units: list[EvidenceUnit]
    metrics: dict
    gate: GateResult
    parsed_tables: list[ParsedTable] = field(default_factory=list)
    fact_skip_reasons: dict = field(default_factory=dict)
    parser_version: str = PARSER_VERSION


def ingest(doc: ExtractedDocument, config: Config,
           llm_calls: int = 0, llm_cost: float = 0.0) -> IngestionResult:
    """Steps 2–7. Diff (8) and persist (9–10) live in storage.persist_ingestion."""
    units, table_conf, parsed_tables, fact_skips = build_units(doc, config)
    gate = run_gates(units, config.gates, table_conf)
    metrics = compute_metrics(units, len(doc.pages), gate, llm_calls, llm_cost)
    status = "failed" if not gate.ok else "succeeded"
    if status == "failed":
        units = []  # nothing persisted on hard failure
    metrics["fact_generation_skipped"] = {
        k: v for k, v in fact_skips.items() if v}
    return IngestionResult(status, units, metrics, gate, parsed_tables,
                           fact_skips)
