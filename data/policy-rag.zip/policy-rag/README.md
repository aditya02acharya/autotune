# policy-rag

Production-oriented RAG system for policy documents on PostgreSQL + pgvector.

The atomic unit is a typed, contextualized **Evidence Unit** (EU) — not a fixed-size
chunk. Each EU carries a deterministic context header (document › version › section
path › table headers), full provenance, a structural identity key for cross-version
diffing, and a content hash for change detection. Tables are parsed into a canonical
model (header forest → row/column header paths) and emitted as whole tables, rows,
notes, and orientation-neutral facts, so pivoted and multi-level-header tables retain
their meaning.

See `DESIGN.md` for the full design: data model, ingestion pipeline, table strategy,
versioning, PII handling, retrieval strategies, MCP tools, API contracts, quality
gates, test plan, example flows, and production checklist.

## Layout

```
schema.sql                  Postgres/pgvector schema (documents, versions, units,
                            membership, links, PII findings, LLM audit, access audit)
policy_rag/
  models.py                 EvidenceUnit, Provenance, TableContext, unit_key
  config.py                 PIIPolicy, QualityGates, Config
  normalize.py              Text normalization, noise stripping, meaningfulness
  pii.py                    Detection (regex + checksums), masking policy
  structure.py              Heading/clause/list/definition/footnote parsing
  tables.py                 Header detection, header paths, stitching, facts
  contextualize.py          Context headers and retrieval-text serialization
  quality.py                Hard-fail gates, quarantine, metrics
  versioning.py             unit_key/text_hash diff -> DiffPlan
  embeddings.py             Embedder protocol (+ deterministic stub)
  llm.py                    GuardedLLMClient, PIISafeLogger, ElevationRequired
  ingest.py                 PDF extraction -> units -> gates -> result
  linking.py                Reference face: cross-doc term/citation/conflict links
  topics.py                 Topic face: cross-corpus clustering (RAPTOR, adapted)
  storage.py                psycopg persistence, hybrid RRF search, lookups,
                            corpus face rebuild
  answer.py                 Citation-enforced synthesis ([[unit_id]] grounding)
  orchestrator.py           agent-as-a-tool: bounded guarded-LLM loop over the
                            action registry, full trajectory returned
  mcp_server.py             FastMCP surface: research_policy / find_evidence /
                            navigate (3 tools; primitives live on as actions)
tests/                      47 tests covering normalization, structure, tables,
                            PII, ingestion, versioning, quality, answering
examples/example_metrics.json
```

## Quickstart

```bash
pip install -e ".[dev]"
pytest tests/ -q

# Database (requires Postgres with the pgvector extension)
psql "$DATABASE_URL" -f schema.sql
```

Ingest and serve:

```python
from policy_rag.config import Config
from policy_rag.ingest import ingest
from policy_rag.storage import Storage

cfg = Config()
result = ingest("policy.pdf", doc_slug="credit-risk-approval-policy",
                version_label="v3.2", config=cfg)
Storage(dsn).persist_ingestion(result)
```

```bash
python -m policy_rag.mcp_server   # exposes search/lookup/compare/answer tools
```

## Libraries

Established libraries are used wherever a wheel existed; custom code remains only
where it is the actual differentiator (table header-path derivation, structural
versioning, quality gates).

| Concern | Library |
|---|---|
| Data models & validation | pydantic v2 |
| Config (env-overridable, `POLICY_RAG_` prefix) | pydantic-settings |
| Unicode repair, ligatures, mojibake | ftfy |
| Checksum validation (Luhn cards, IBAN mod-97) | python-stdnum |
| PDF extraction | pdfplumber |
| Postgres driver / vector type adapter | psycopg 3 / pgvector |
| Embeddings (vLLM-hosted, OpenAI-compatible API) | openai SDK |
| LLM backends (Claude / OpenAI-compatible) | anthropic / openai SDKs |
| Clustering (Topic face) | scikit-learn |
| Retry with exponential backoff | tenacity |
| MCP server | mcp (FastMCP) |

All of these are pure-Python/API clients with **no bundled or downloaded ML
models**, so the package is air-gap friendly: the only external calls are to
your vLLM embedding endpoint (`POLICY_RAG_VLLM_BASE_URL`) and your chosen
cloud LLM. PII detection is deterministic (regex + stdnum checksums) rather
than NER-based for the same reason; an NER engine can be plugged in via
`detect_pii(extra_detectors=...)` if one is ever permitted in the environment.

## Notes

- PostgreSQL + pgvector is the only datastore: vectors (HNSW), full-text (tsvector
  GIN), and fuzzy match (pg_trgm) are fused with reciprocal-rank fusion in one SQL CTE.
- LLM usage is conservative: ingestion uses zero LLM calls; only `answer_question`
  calls the (guarded, audited) LLM, and only when evidence exists.
- PII is masked before embedding and logging by default; raw text lives only in the
  controlled `source_text` column.
