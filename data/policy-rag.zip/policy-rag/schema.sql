-- Policy RAG schema. PostgreSQL >= 15, pgvector >= 0.7, pg_trgm.
CREATE EXTENSION IF NOT EXISTS vector;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

CREATE TABLE documents (
    doc_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug            TEXT NOT NULL UNIQUE,
    title           TEXT NOT NULL,
    classification  TEXT NOT NULL DEFAULT 'internal',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE document_versions (
    doc_version_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doc_id           UUID NOT NULL REFERENCES documents(doc_id),
    version_label    TEXT NOT NULL,              -- e.g. 'v3.1' (declared or derived)
    source_file_hash TEXT NOT NULL,              -- sha256 of the PDF bytes
    effective_date   DATE,
    page_count       INT,
    is_current       BOOLEAN NOT NULL DEFAULT false,
    ingested_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (doc_id, source_file_hash)
);
CREATE UNIQUE INDEX one_current_version
    ON document_versions(doc_id) WHERE is_current;

CREATE TABLE ingestion_runs (
    run_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doc_version_id UUID REFERENCES document_versions(doc_version_id),
    parser_version TEXT NOT NULL,
    status         TEXT NOT NULL CHECK (status IN
                     ('running','succeeded','failed','quarantined','noop')),
    metrics        JSONB,
    gate_failures  JSONB,
    started_at     TIMESTAMPTZ NOT NULL DEFAULT now(),
    finished_at    TIMESTAMPTZ
);

CREATE TABLE tables_meta (
    table_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doc_version_id  UUID NOT NULL REFERENCES document_versions(doc_version_id),
    table_key       TEXT NOT NULL,              -- stable key: section_path + table ordinal
    caption         TEXT,
    section_path    TEXT[] NOT NULL DEFAULT '{}',
    page_start      INT NOT NULL,
    page_end        INT NOT NULL,
    n_rows          INT NOT NULL,
    n_cols          INT NOT NULL,
    header_struct   JSONB NOT NULL,             -- column/row header trees
    parse_confidence REAL NOT NULL,
    stitched_pages  INT NOT NULL DEFAULT 1,
    fact_skip_reason TEXT,                      -- why cell facts were not generated
    UNIQUE (doc_version_id, table_key)
);

CREATE TABLE evidence_units (
    unit_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_key         TEXT NOT NULL,             -- structural identity across versions
    text_hash        TEXT NOT NULL,             -- sha256(source_text)
    doc_id           UUID NOT NULL REFERENCES documents(doc_id),
    doc_version_id   UUID NOT NULL REFERENCES document_versions(doc_version_id),
    unit_type        TEXT NOT NULL CHECK (unit_type IN
                       ('heading','clause','list_block','definition','footnote',
                        'appendix_item','table','table_region','table_row',
                        'table_fact','table_notes','doc_summary')),
    source_text      TEXT NOT NULL,             -- raw normalized text (controlled)
    retrieval_text   TEXT NOT NULL,             -- contextualized, PII-masked per policy
    context_header   TEXT NOT NULL,
    section_path     TEXT[] NOT NULL DEFAULT '{}',
    section_titles   TEXT[] NOT NULL DEFAULT '{}',
    page_start       INT,
    page_end         INT,
    ordinal          INT NOT NULL,
    parent_unit_id   UUID REFERENCES evidence_units(unit_id),
    -- table semantics
    table_id         UUID REFERENCES tables_meta(table_id),
    row_idx          INT,
    col_idx          INT,
    row_header_path  TEXT[],
    col_header_path  TEXT[],
    cell_value       TEXT,
    unit_of_measure  TEXT,
    -- definitions
    term             TEXT,
    -- pii
    contains_pii     BOOLEAN NOT NULL DEFAULT false,
    pii_types        TEXT[] NOT NULL DEFAULT '{}',
    embedding_source TEXT NOT NULL DEFAULT 'masked'
                       CHECK (embedding_source IN ('raw','masked','redacted','none')),
    -- lifecycle
    status           TEXT NOT NULL DEFAULT 'active'
                       CHECK (status IN ('active','superseded','quarantined')),
    parser_version   TEXT NOT NULL,
    ingestion_run_id UUID NOT NULL REFERENCES ingestion_runs(run_id),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    superseded_at    TIMESTAMPTZ,
    -- search
    embedding        vector(768),
    embedding_model  TEXT,
    tsv              tsvector GENERATED ALWAYS AS
                       (to_tsvector('english', retrieval_text)) STORED,
    UNIQUE (doc_version_id, unit_key)
);

-- carry-forward membership: a physical unit row can belong to several versions
CREATE TABLE version_membership (
    unit_id        UUID NOT NULL REFERENCES evidence_units(unit_id),
    doc_version_id UUID NOT NULL REFERENCES document_versions(doc_version_id),
    PRIMARY KEY (unit_id, doc_version_id)
);

CREATE TABLE unit_links (
    src_unit_id UUID NOT NULL REFERENCES evidence_units(unit_id),
    dst_unit_id UUID NOT NULL REFERENCES evidence_units(unit_id),
    link_type   TEXT NOT NULL CHECK (link_type IN
                  -- intra-document
                  ('footnote_of','references_section','continues','note_of',
                  -- cross-document (the Reference face)
                   'uses_term','references_document','same_topic',
                   'potentially_conflicting','divergent_definition',
                  -- version lineage (new unit -> superseded predecessor)
                   'lineage_of')),
    evidence    TEXT,                          -- e.g. matched phrase / diverging values
    PRIMARY KEY (src_unit_id, dst_unit_id, link_type)
);

-- ---------- Topic face: cross-corpus semantic clusters ----------
CREATE TABLE topics (
    topic_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    label           TEXT NOT NULL,             -- short human-readable label
    summary_text    TEXT NOT NULL,             -- extractive medoid or guarded-LLM summary
    summary_method  TEXT NOT NULL CHECK (summary_method IN ('medoid','llm')),
    member_hash     TEXT NOT NULL,             -- sha256 of sorted member unit_keys:
                                               -- summary regenerated only when this changes
    n_members       INT NOT NULL,
    n_documents     INT NOT NULL,
    embedding       vector(768),
    built_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    stale           BOOLEAN NOT NULL DEFAULT false
);

CREATE TABLE topic_membership (
    topic_id   UUID NOT NULL REFERENCES topics(topic_id) ON DELETE CASCADE,
    unit_id    UUID NOT NULL REFERENCES evidence_units(unit_id),
    similarity REAL NOT NULL,                  -- cosine sim to topic centroid
    PRIMARY KEY (topic_id, unit_id)
);
CREATE INDEX tm_unit ON topic_membership (unit_id);

CREATE TABLE pii_findings (
    finding_id  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id     UUID NOT NULL REFERENCES evidence_units(unit_id),
    pii_type    TEXT NOT NULL,
    placeholder TEXT NOT NULL,                  -- e.g. [EMAIL_1]
    span_start  INT NOT NULL,                   -- span into source_text
    span_end    INT NOT NULL
);

CREATE TABLE llm_calls (
    call_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    purpose        TEXT NOT NULL,               -- 'answer_synthesis', 'table_header_inference', ...
    model          TEXT NOT NULL,
    input_kind     TEXT NOT NULL,               -- 'masked_evidence', 'raw_evidence', ...
    token_estimate INT NOT NULL,
    cost_estimate  NUMERIC(10,6) NOT NULL,
    pii_present    BOOLEAN NOT NULL,
    prompt_stored  BOOLEAN NOT NULL DEFAULT false,
    prompt_text    TEXT,                        -- only if explicitly enabled
    run_id         UUID REFERENCES ingestion_runs(run_id),
    created_at     TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE access_audit (
    audit_id   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    principal  TEXT NOT NULL,
    unit_id    UUID NOT NULL REFERENCES evidence_units(unit_id),
    action     TEXT NOT NULL,                   -- 'retrieved','pii_revealed'
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Indexes
CREATE INDEX eu_tsv_gin        ON evidence_units USING gin(tsv);
CREATE INDEX eu_trgm           ON evidence_units USING gin(source_text gin_trgm_ops);
CREATE INDEX eu_embedding_hnsw ON evidence_units USING hnsw (embedding vector_cosine_ops);
CREATE INDEX eu_section        ON evidence_units USING gin(section_path);
CREATE INDEX eu_order          ON evidence_units (doc_version_id, ordinal);
CREATE INDEX eu_key            ON evidence_units (unit_key, status);
CREATE INDEX eu_table          ON evidence_units (table_id, row_idx, col_idx);
CREATE INDEX eu_term           ON evidence_units (term) WHERE term IS NOT NULL;
CREATE INDEX eu_rowpath        ON evidence_units USING gin(row_header_path);
CREATE INDEX eu_colpath        ON evidence_units USING gin(col_header_path);

-- Every unit-returning query reads this view: a unit is NEVER returned
-- without its source document, title, and version attached.
CREATE VIEW evidence_units_v AS
SELECT eu.*,
       d.slug            AS doc_slug,
       d.title           AS doc_title,
       d.classification  AS doc_classification,
       dv0.version_label AS version_introduced,
       COALESCE(dvc.version_label, dv0.version_label) AS version_label
FROM evidence_units eu
JOIN documents d USING (doc_id)
JOIN document_versions dv0 ON dv0.doc_version_id = eu.doc_version_id
LEFT JOIN document_versions dvc ON dvc.doc_id = d.doc_id AND dvc.is_current;
